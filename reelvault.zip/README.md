# ReelVault - AI Video Content Intelligence Platform

ReelVault is an executive, AI-powered video vault and intelligence platform that organizes, analyzes, and extracts key takeaways from video content (YouTube, Instagram Reels, Shorts, Vimeo, etc.).

## 📖 Complete Documentation
For an exhaustive **A-to-Z breakdown of every file**, code architecture, data flows, and power-user keyboard shortcuts, please see:
👉 **[`PROJECT_DOCUMENTATION.md`](./PROJECT_DOCUMENTATION.md)**

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

Visit `http://localhost:3000` in your browser.
