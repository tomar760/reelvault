# ReelVault - Complete A-to-Z Project Documentation & Code Architecture

Welcome to the comprehensive documentation for **ReelVault**, an AI-powered Video Content Intelligence & Vault Platform. This document explains the full project concept, architecture, data flow, and provides an **A-to-Z breakdown of every single file** in the codebase.

---

## 🎯 Project Concept & Core Value Proposition

**ReelVault** is designed as an executive, intelligent workspace for bookmarking, organizing, analyzing, and processing video content (YouTube, Instagram Reels, Shorts, Vimeo, direct streams, etc.). 

Key capabilities include:
1. **Instant AI Video Ingestion**: Extracting metadata, key takeaways, automatic categorizations, Hindi/English ratings (`Bahut Kaam Ki`, `Kaam Ki`, `Timepass`), and auto-generated action points.
2. **Interactive Return-to-Work Dashboard**: Quick-return flow for the last 5 accessed videos with progress bars and key takeaway markers.
3. **Power-User Global Shortcuts**: Instant search with `⌘K`, quick URL add with `⌘N`, view switching with `⌘1`–`⌘4`, theme toggling with `⌘Shift+T`, and cheat sheet popover with `?`.
4. **Enhanced Video Player & Poster Mode**: Interactive video canvas that renders embed players or an interactive poster fallback with timeline scrubbers and chapter markers synced to AI key takeaways.
5. **D3.js Data Visualizations**: Real-time activity charts and category distribution metrics.
6. **Automation Workflows**: Executing batch AI pipelines (e.g., auto-tagging, duplicate detection, sentiment scoring).
7. **Offline-First Resilience**: Persistent client-side storage (`localStorage`) with full JSON backup & restore capabilities.

---

## 🏗️ System Architecture & Data Flow

```
┌──────────────────────────────────────────────────────────────────────────┐
│                             BROWSER CLIENT                               │
│                                                                          │
│   ┌──────────────────────────────────────────────────────────────────┐   │
│   │                         React 18 + Vite                          │   │
│   │                                                                  │   │
│   │  ┌──────────────┐   ┌─────────────────┐   ┌──────────────────┐  │   │
│   │  │    Header    │   │     Sidebar     │   │ Keyboard Shortcuts│  │   │
│   │  └──────┬───────┘   └────────┬────────┘   └─────────┬────────┘  │   │
│   │         │                    │                      │           │   │
│   │         ▼                    ▼                      ▼           │   │
│   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │   │                         App.tsx                          │   │   │
│   │   │       (Global State: Vault Items, Workflows, Settings)   │   │   │
│   │   └──────────────────────────┬───────────────────────────────┘   │   │
│   │                              │                                   │   │
│   │     ┌────────────────────────┼─────────────────────────┐         │   │
│   │     ▼                        ▼                         ▼         │   │
│   │┌──────────────┐    ┌──────────────────┐     ┌──────────────────┐ │   │
│   ││DashboardView │    │   LibraryView    │     │VaultItemDetail   │ │   │
│   │└──────────────┘    └──────────────────┘     └──────────────────┘ │   │
│   └──────────────────────────────┬───────────────────────────────────┘   │
│                                  │                                       │
│                                  ▼                                       │
│                       ┌────────────────────┐                             │
│                       │ StorageService.ts  │                             │
│                       │  (localStorage)    │                             │
│                       └────────────────────┘                             │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## 📁 A-to-Z File-by-File Detailed Breakdown

Below is the exhaustive list and deep dive into every file in the project workspace:

---

### 1. Root Configuration & Server Files

#### `/.env.example`
* **Purpose**: Environment variable template listing required keys.
* **Details**: Documents configuration flags such as server ports or optional API integration parameters without exposing real secrets.

#### `/.gitignore`
* **Purpose**: Git exclusion rules.
* **Details**: Ignores `node_modules/`, `dist/`, `.env`, and build artifacts to keep version control clean.

#### `/index.html`
* **Purpose**: Main HTML entry point served by Vite/Express.
* **Details**: Sets up viewport meta tags, document title ("ReelVault - AI Video Content Intelligence"), web font imports (Inter, Plus Jakarta Sans), and mounts `<div id="root"></div>`.

#### `/metadata.json`
* **Purpose**: AI Studio application metadata.
* **Details**: Configures applet name, description, frame permissions, and major capabilities (`MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API`).

#### `/package.json`
* **Purpose**: Project dependencies, scripts, and package management.
* **Details**:
  * **Dependencies**: React 18, Lucide React icons, Motion (Framer Motion replacement), D3.js, Recharts, Tailwind CSS v4, Express, tsx, esbuild.
  * **Scripts**:
    * `"dev"`: Runs `tsx server.ts` for full-stack dev server on port 3000.
    * `"build"`: Compiles Vite frontend and esbuild server backend into `dist/server.cjs`.
    * `"start"`: Launches production node server `node dist/server.cjs`.

#### `/server.ts`
* **Purpose**: Full-stack Express backend server integrated with Vite middleware.
* **Details**:
  * Listens on host `0.0.0.0` and port `3000`.
  * Serves health check API endpoints (`/api/health`).
  * Mounts Vite development middleware in dev mode, and static file serving for `dist/` in production mode.

#### `/tsconfig.json`
* **Purpose**: TypeScript configuration.
* **Details**: Configures strict type-checking rules, JSX parsing for React 18, module resolution (Bundler/Node), and target ESNext features.

#### `/vite.config.ts`
* **Purpose**: Vite build tool and plugin configuration.
* **Details**: Configures React plugin, Tailwind CSS v4 plugin, server port binding (`3000`), and path aliases.

---

### 2. Core Application Logic (`/src`)

#### `/src/main.tsx`
* **Purpose**: Client-side entry point.
* **Details**: Mounts the main React `<App />` component into the DOM element `#root` wrapped in `React.StrictMode`.

#### `/src/index.css`
* **Purpose**: Global CSS styling entry point.
* **Details**: Imports Tailwind CSS (`@import "tailwindcss";`), custom scrollbars, animations (`@keyframes fadeIn`), glassmorphism utility classes, and custom variables for dark/light themes.

#### `/src/types.ts`
* **Purpose**: Global TypeScript type definitions and interfaces.
* **Details**: Defines core domain models:
  * `VaultItem`: ID, title, URL, platform, rating (`Bahut Kaam Ki`, `Kaam Ki`, `Timepass`), category, duration, key takeaways, action points, thumbnail URL, watch progress.
  * `WorkflowItem`: Automation workflow status, steps, execution logs.
  * `AppSettings`: Auto-pilot mode, theme mode (`dark` | `light`), notifications preferences.
  * `NavigationTab`: Navigation tabs (`dashboard` | `library` | `analytics` | `workflows` | `detail`).

#### `/src/data/initialData.ts`
* **Purpose**: Mock and seed dataset for initial vault state.
* **Details**: Provides high-quality initial video entries across AI development, system architecture, design systems, and business strategy with realistic thumbnails, durations, and key takeaways.

#### `/src/services/storage.ts`
* **Purpose**: Client-side persistence engine using `localStorage`.
* **Details**:
  * Manages reading, writing, and clearing vault items (`reelvault_items_v1`), workflow states, app settings, and recently viewed history IDs (`reelvault_recently_viewed_v1`).
  * Provides backup export (`exportBackupJSON`) and restore (`importBackupJSON`) capabilities.

---

### 3. Component Hierarchy (`/src/components`)

#### `/src/App.tsx`
* **Purpose**: Root application component & central state coordinator.
* **Details**:
  * Manages primary state: `vaultItems`, `workflows`, `settings`, `recentlyViewedIds`, `activeTab`, `selectedItem`, and active modal popovers.
  * **Global Keyboard Shortcut Listener**: Listens for `⌘K` (Global Search), `⌘N` (Quick Add), `⌘1`–`⌘4` (Tab switching), `⌘,` (Settings), `⌘Shift+T` (Theme toggle), `?` (Shortcuts help modal), and `Esc` (Close overlays).
  * Renders `Header`, `Sidebar`, `BottomNav`, main view routes (`DashboardView`, `LibraryView`, `AnalyticsView`, `WorkflowsView`, `VaultItemDetailView`), and popover modals.

#### `/src/components/Header.tsx`
* **Purpose**: Global top navigation header.
* **Details**:
  * Contains real-time global search with instant video auto-complete dropdown.
  * Displays quick keybindings (`⌘K`), network status indicator (Online/Offline), CSV export button, Keyboard Shortcuts popover launcher (`?`), Settings button, and Notifications drawer trigger.

#### `/src/components/Sidebar.tsx`
* **Purpose**: Desktop navigation drawer.
* **Details**:
  * Features the **Quick Add Link** button (`⌘N`).
  * Displays navigation links (`Dashboard`, `Library`, `Analytics`, `Workflows`) with count badges and keyboard shortcut hints (`⌘1`–`⌘4`).

#### `/src/components/BottomNav.tsx`
* **Purpose**: Mobile responsive bottom navigation bar.
* **Details**: Offers touch-optimized navigation tabs for smaller screens with 44px+ touch targets.

#### `/src/components/BackgroundShader.tsx`
* **Purpose**: Interactive WebGL grid canvas.
* **Details**: Renders a subtle, animated geometric matrix grid in the background to elevate visual depth.

#### `/src/components/DashboardView.tsx`
* **Purpose**: Executive Dashboard & Quick Intake hub.
* **Details**:
  * **Top Header Banner**: Includes a floating **Dark/Light Mode Quick-Toggle Switch** for instant theme feedback.
  * **Quick Add Panel**: URL input for pasting YouTube/Instagram links to simulate AI ingestion.
  * **Recently Viewed Flow**: Displays a 5-card grid of the last 5 accessed videos with watch progress bars and return-to-work actions.
  * **Real-time Metrics**: Video counts, high-value content breakdown, and system status.

#### `/src/components/LibraryView.tsx`
* **Purpose**: Full video vault library view.
* **Details**:
  * Search, filtering by category (AI, System Design, Productivity, etc.), and sorting by rating/date.
  * Multi-select batch actions: Batch edit categories, batch delete, or export selected entries.
  * Grid view & List view toggles.

#### `/src/components/VaultItemDetailView.tsx`
* **Purpose**: Single video intelligence detail page.
* **Details**:
  * **Enhanced Video Player Placeholder**: Embedded YouTube/direct player or an interactive poster placeholder using `thumbnailUrl` with timeline scrubber and chapter markers mapped to AI key takeaways.
  * AI Key Takeaways checklist, actionable next steps, rating badge editor, category tagger, and custom remarks editor.

#### `/src/components/AnalyticsView.tsx`
* **Purpose**: Data analytics & metrics dashboard.
* **Details**: Displays total watch time, category distribution pie charts, rating breakdowns, and activity trends over time.

#### `/src/components/D3DailyActivityChart.tsx`
* **Purpose**: Custom D3.js daily activity chart.
* **Details**: Renders a custom SVG bar chart displaying video ingestion and study frequency per day.

#### `/src/components/WorkflowsView.tsx`
* **Purpose**: Automation workflow pipeline manager.
* **Details**: Allows users to run background tasks like "Auto-Categorize Unsorted Videos", "Extract Key Takeaways", "Duplicate Detection", and "Generate Action Plans".

#### `/src/components/QuickAddPanel.tsx`
* **Purpose**: Embedded URL intake panel on the Dashboard.
* **Details**: Fast input box for pasting video URLs with automated platform detection (YouTube, Instagram, Shorts).

#### `/src/components/QuickAddModal.tsx`
* **Purpose**: Fullscreen modal for video URL ingestion.
* **Details**: Triggered via `⌘N` or Quick Add buttons; provides interactive progress states while AI metadata is generated.

#### `/src/components/SettingsModal.tsx`
* **Purpose**: Application preferences & data management modal.
* **Details**:
  * Dark/Light mode selection.
  * Auto-Pilot AI processing toggles.
  * Full JSON Backup Export & JSON File Import to restore complete vault states.
  * Storage reset utility.

#### `/src/components/NotificationsModal.tsx`
* **Purpose**: System notification slide-over drawer.
* **Details**: Shows recent system logs, AI workflow completions, and storage updates.

#### `/src/components/KeyboardShortcutsModal.tsx`
* **Purpose**: Power-user keyboard shortcuts cheatsheet modal.
* **Details**: Triggered via `?` or header button. Displays categorized shortcuts (`⌘K`, `⌘N`, `⌘1-4`, `⌘,`, `⌘Shift+T`, `Esc`) with interactive click-to-trigger testing.

---

## ⌨️ Power-User Keyboard Shortcuts Reference

| Shortcut | Action | Description |
| :--- | :--- | :--- |
| **`⌘K` / `Ctrl+K`** | Focus Search | Focuses global search input in the header |
| **`⌘N` / `Ctrl+N`** | Quick Add | Opens AI video ingestion modal |
| **`⌘1`** | Dashboard | Navigates to Executive Dashboard |
| **`⌘2`** | Vault Library | Navigates to Video Vault Library |
| **`⌘3`** | Analytics | Navigates to Analytics & D3 Charts |
| **`⌘4`** | Workflows | Navigates to Automation Workflows |
| **`⌘,`** | Settings | Opens Settings & JSON Backup Modal |
| **`⌘Shift+T`** | Toggle Theme | Switches between Dark & Light Mode |
| **`?` or `⌘/`** | Shortcuts Help | Opens Keyboard Shortcuts Cheat Sheet |
| **`Esc`** | Close | Dismisses active modals, popovers, or search |

---

## 🚀 How to Run & Build

1. **Development Mode**:
   ```bash
   npm run dev
   ```
   Runs `tsx server.ts` on port 3000 with Vite middleware.

2. **Linting & Code Verification**:
   ```bash
   npm run lint
   ```
   Runs TypeScript type checks (`tsc --noEmit`).

3. **Production Build**:
   ```bash
   npm run build
   ```
   Compiles Vite frontend assets and bundles Express server into `dist/server.cjs`.

4. **Production Start**:
   ```bash
   npm run start
   ```
   Launches the bundled production server on `http://0.0.0.0:3000`.

---
*Documentation generated for ReelVault AI Video Content Intelligence Platform.*
