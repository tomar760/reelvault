import { VaultItem, WorkflowItem, AnalyticsData, AppSettings } from '../types';

export const INITIAL_VAULT_ITEMS: VaultItem[] = [
  {
    id: 'vault-1',
    title: 'Advanced Figma Prototyping Tricks 2024',
    url: 'https://youtube.com/watch?v=figma-proto-2024',
    category: 'UI/UX/Figma Prototyping',
    rating: 'Bahut Kaam Ki',
    duration: '12:45',
    date: 'Oct 24, 2023',
    addedAt: '2023-10-24T10:30:00Z',
    summary: 'This session covers advanced techniques for building scalable design systems in Figma, focusing on nested variants, boolean properties, and component-level auto-layout structures for enterprise UI development.',
    keyTakeaways: [
      'Utilize boolean properties to drastically reduce component variant count.',
      'Implement slot components for highly flexible card architectures.',
      'Leverage local variables for semantic color and spacing tokens.'
    ],
    tags: ['UI/UX', 'Figma', 'Tutorial', 'Design Systems'],
    sentimentTag: 'Technical Deep-Dive',
    detectedLinks: [
      { label: 'github.com/ui-architecture', url: 'https://github.com' },
      { label: 'figma.com/file/enterprise-ds', url: 'https://figma.com' }
    ],
    remarks: 'Auto-categorized under "Design Toolkit" based on visual assets detected. Excellent for complex UI systems.',
    thumbnailUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD7XDHZ70uUueJ4pLZ4EdyjITt9Gm94BaUDJprkZw9FxbHEfmhoIwpSOSCxZmR3tNyye5Aox0MFCXLNwW4eSK7DCfxUh9V3xfqcjNR58xo98CmKjFDsPoLlMpwTsh9thOXfpI2kcWRcfkVcj8cJ4qblEqzFz4TXGcRcMpy-iGzU-LI2sfqYmb0OObE_AJCYlM5pg3DhkqCxgj8pXErGYDl7TqcxiLD6eoA_a3asMhknvttrEl9N4ajycQ',
    favorite: true,
    watchProgress: 85,
  },
  {
    id: 'vault-2',
    title: 'Microservices Architecture Explained',
    url: 'https://youtube.com/watch?v=microservices-arch',
    category: 'Backend/Microservices',
    rating: 'Kaam Ki',
    duration: '45:20',
    date: 'Yesterday',
    addedAt: '2023-10-23T14:15:00Z',
    summary: 'An architectural deep dive into event-driven microservices, service mesh communication via gRPC, and resilient circuit breaker patterns in cloud-native Node and Go services.',
    keyTakeaways: [
      'Decouple inter-service state using Kafka event topics.',
      'Enforce strict idempotency keys on payment & data mutation endpoints.',
      'Use open-telemetry traces for cross-boundary latency debugging.'
    ],
    tags: ['Backend', 'Microservices', 'Distributed Systems', 'Node.js'],
    sentimentTag: 'Architecture Masterclass',
    detectedLinks: [
      { label: 'github.com/microservices-demo', url: 'https://github.com' }
    ],
    remarks: 'Crucial reference video for distributed system state consistency.',
    thumbnailUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCuPjIrNtrQqBFqRjRLoQGwn7SxZ4bUHGT377nEawZKMgfJAQ3s4j18VRLyyQ6m8lYmNwHS8utH7mdk-OdEzzmyiL3hXzWisZWjdaCGesHsS6rogH8DAjItveBEsGTzPiqUbsmBq1_3XzoAgOrdYF5fvf1RVzhjiUXLO0E_oUiG19g4PczrbkyafLo__QIgA6Hc3xe-9cihnUwE16pcI0uAtQAD5OsfnPTdoiYwldMD2XVQ42EpwKvPJw',
    favorite: false,
    watchProgress: 40,
  },
  {
    id: 'vault-3',
    title: 'FastAPI Microservices & Async Pipelines',
    url: 'https://youtube.com/watch?v=fastapi-async',
    category: 'Backend/FastAPI',
    rating: 'Kaam Ki',
    duration: '08:22',
    date: 'Yesterday',
    addedAt: '2023-10-23T18:00:00Z',
    summary: 'Rapid prototyping of async Python web APIs with Pydantic validation, dependency injection, and automatic OpenAPI documentation generation.',
    keyTakeaways: [
      'Use async def route handlers with asyncpg for high throughput.',
      'Enforce strict request payload schemas with Pydantic v2.',
      'Configure automatic CORS and rate-limiting middleware.'
    ],
    tags: ['Backend', 'FastAPI', 'Python', 'Async'],
    sentimentTag: 'Hands-on Guide',
    detectedLinks: [
      { label: 'fastapi.tiangolo.com/tutorial', url: 'https://fastapi.tiangolo.com' }
    ],
    remarks: 'Quick implementation recipe for Python microservices.',
    thumbnailUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDhnxO7krgMymaQNXMkfF3P_vBJOjsC0IAe4jQO8RQ9Nx9BfBo3LPxAA-W37kec8hG3S-Yo9gaPTNFCRfM5_AcVX939HjXvocgt6Szv0TTNSxV3jgD-Kf8r--FmU6_KG24vBMys7x0YBViAfEqxAgKwkwMunM_fqFRcfNaHHlLhzzbjmK3WsffMusChkSaJzseCOcZvSFtv2DzQzGHpJZurqMO9cbi0gfJEH-CwI19m63uFEGrAJUn5zQ',
    favorite: true,
    watchProgress: 100,
  },
  {
    id: 'vault-4',
    title: 'PostgreSQL Indexing & Query Tuning Explained',
    url: 'https://youtube.com/watch?v=postgres-indexing',
    category: 'Tech Tips/Databases',
    rating: 'Bahut Kaam Ki',
    duration: '15:30',
    date: '3 days ago',
    addedAt: '2023-10-21T09:00:00Z',
    summary: 'Demystifying B-Tree, GIN, and GiST indexes in PostgreSQL. Learn how EXPLAIN ANALYZE helps locate slow sequential scans and eliminate database bottlenecks.',
    keyTakeaways: [
      'Create GIN indexes for JSONB and array search performance.',
      'Avoid over-indexing write-heavy OLTP tables.',
      'Analyze index bloat using pg_stat_user_indexes queries.'
    ],
    tags: ['Tech Tips', 'PostgreSQL', 'Databases', 'SQL'],
    sentimentTag: 'Quick Tip',
    detectedLinks: [
      { label: 'postgresql.org/docs/indexes', url: 'https://postgresql.org' }
    ],
    remarks: 'Auto-tagged database optimization guide.',
    thumbnailUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAtacU3lJzQHG1CKu-X5NAonoKRLNKowimmELcjMD6vOs6YDkpS36PZ54W87qNTYpjI4TunJTUH6e3uYPthTx1CaH3f_mcy4tzG3wDqjcWdYJQec9ef0kYrlu7xXfyD9r2-v8VewSCCzIcBI4iFjAMpW8_qrQHlXo71SS5EiBucH7zS_eI-2nyVP6_IfEEQm211RpfOqWMBVnQgYACxSZTdJmTkIcdhaoHLwTsnrMY7J7r30p3sM5OveQ',
    favorite: true,
    watchProgress: 60,
  },
  {
    id: 'vault-5',
    title: '10 UI Animation Ideas with Framer Motion',
    url: 'https://youtube.com/watch?v=10-ui-animations',
    category: 'UI/UX/Animations',
    rating: 'Theek-Thaak',
    duration: '05:15',
    date: '1 week ago',
    addedAt: '2023-10-17T11:45:00Z',
    summary: 'A curated showcase of high-end micro-interactions, layout transitions, and spring physics for React web applications.',
    keyTakeaways: [
      'Use AnimatePresence for clean unmounting animations.',
      'Leverage layoutId for effortless shared element transitions.',
      'Keep spring damping ratio near 0.8 for crisp cursor feedback.'
    ],
    tags: ['UI/UX', 'Inspiration', 'React', 'Motion'],
    sentimentTag: 'Inspiration Showcase',
    detectedLinks: [
      { label: 'motion.dev/docs', url: 'https://motion.dev' }
    ],
    remarks: 'Inspirational micro-interaction catalog.',
    thumbnailUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAEw-4hUiLE9Nd9Ampvnr7qk83Jpci19IzG_d-WO6-Jmf27EZZ2uKnby_0FTzIxm8Yewgjm6whk8hzmKEjoyUU0EZRuljewHXgSv3VHCVznXYmP7LKVSUIQ7RPDEy54fceX373HCgqxW9imyMpwB0uHCVIf0ySElI2at43OW-r02fDb3GSbYXjDnTrVxqq-7dwlgBBYwOXBJoWVFBNpCFoYkImQ2um-bPZskHREKM4Ax85XuC5ySE6z2w',
    favorite: false,
    watchProgress: 15,
  }
];

export const INITIAL_WORKFLOWS: WorkflowItem[] = [
  {
    id: 'wf-1',
    name: 'Auto-Download & Sort',
    status: 'Running',
    source: 'YouTube',
    target: 'Drive/Archive',
    progress: 72,
    description: 'Processing 4/12 items • Downloading 1080p @ 2.4 MB/s'
  },
  {
    id: 'wf-2',
    name: 'AI Meta-Tagging',
    status: 'Scheduled',
    model: 'Gemini 3.6 Flash',
    nextRun: '15 mins',
    description: 'Auto-extracts key takeaways, sentiment, and tags from incoming bookmarks'
  },
  {
    id: 'wf-3',
    name: 'Social Sync',
    status: 'Idle',
    source: 'Multi-platform',
    lastRun: '2 hours ago',
    description: 'Syncs saved video links across Twitter bookmarks and Chrome extension'
  },
  {
    id: 'wf-4',
    name: 'Vault Backup & Excel Export',
    status: 'Completed',
    lastRun: '1 day ago',
    description: 'Generates offline CSV & JSON snapshots for instant recovery'
  }
];

export const INITIAL_ANALYTICS: AnalyticsData = {
  totalVideos: 1204,
  thisWeekAdded: 42,
  highValueCount: 386,
  pendingFailedCount: 3,
  storageUsedPercent: 84,
  storageUsedTB: 1.8,
  totalStorageTB: 2.0,
  contentDistribution: [
    { category: 'UI/UX', count: 450, percent: 100, colorClass: 'bg-primary' },
    { category: 'Backend', count: 320, percent: 71, colorClass: 'bg-secondary' },
    { category: 'Tech Tips', count: 280, percent: 62, colorClass: 'bg-primary-container' },
    { category: 'AI/ML', count: 154, percent: 34, colorClass: 'bg-secondary-container' }
  ],
  avgProcessingTimeSeconds: 42,
  successRatePercent: 99.8,
  weeklyGrowth: [
    { day: 'Mon', count: 70 },
    { day: 'Tue', count: 100 },
    { day: 'Wed', count: 60 },
    { day: 'Thu', count: 130 },
    { day: 'Fri', count: 110 },
    { day: 'Sat', count: 170 },
    { day: 'Sun', count: 210 }
  ]
};

export const DEFAULT_SETTINGS: AppSettings = {
  autoPilot: true,
  offlineSync: true,
  theme: 'dark',
  notificationsEnabled: true,
  autoParseActive: true
};
