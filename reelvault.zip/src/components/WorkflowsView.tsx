import React, { useState } from 'react';
import { GitFork, Play, Pause, RefreshCw, CheckCircle2, Clock, Plus, Zap, AlertCircle } from 'lucide-react';
import { WorkflowItem } from '../types';

interface WorkflowsViewProps {
  workflows: WorkflowItem[];
  autoPilot: boolean;
  onToggleAutoPilot: () => void;
  onRunWorkflow: (id: string) => void;
}

export const WorkflowsView: React.FC<WorkflowsViewProps> = ({
  workflows,
  autoPilot,
  onToggleAutoPilot,
  onRunWorkflow,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newWfName, setNewWfName] = useState('');

  const getStatusBadge = (status: WorkflowItem['status']) => {
    switch (status) {
      case 'Running':
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono bg-primary/15 text-primary border border-primary/30">
            <RefreshCw className="w-3 h-3 animate-spin" />
            Running
          </span>
        );
      case 'Scheduled':
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono bg-amber-500/15 text-amber-400 border border-amber-500/30">
            <Clock className="w-3 h-3" />
            Scheduled
          </span>
        );
      case 'Completed':
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono bg-tertiary/15 text-tertiary border border-tertiary/30">
            <CheckCircle2 className="w-3 h-3" />
            Completed
          </span>
        );
      default:
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono bg-surface-variant text-on-surface-variant border border-outline-variant">
            Idle
          </span>
        );
    }
  };

  return (
    <div className="flex flex-col gap-6 max-w-7xl mx-auto w-full pb-16">
      {/* Header Banner */}
      <section className="bg-surface/80 backdrop-blur-2xl border border-white/10 rounded-2xl p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <GitFork className="w-6 h-6 text-primary" />
            <h1 className="font-display-lg text-2xl font-bold text-on-surface">Workflow Automation</h1>
          </div>
          <p className="font-body-md text-sm text-on-surface-variant mt-1 max-w-xl">
            Configure automated background ingestion, auto-tagging, storage synchronization, and backup pipelines.
          </p>
        </div>

        {/* Global Auto-Pilot Switch */}
        <div className="flex items-center gap-3 bg-surface-container border border-white/10 px-4 py-2.5 rounded-xl shrink-0">
          <Zap className={`w-5 h-5 ${autoPilot ? 'text-tertiary fill-tertiary' : 'text-on-surface-variant'}`} />
          <div className="flex flex-col">
            <span className="font-label-md text-xs font-semibold text-on-surface">Global Auto-Pilot</span>
            <span className="font-label-sm text-[10px] text-on-surface-variant">
              {autoPilot ? 'Automations active' : 'Automations paused'}
            </span>
          </div>

          <button
            onClick={onToggleAutoPilot}
            className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ml-2 ${
              autoPilot ? 'bg-tertiary' : 'bg-surface-variant'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-transform duration-200 ${
                autoPilot ? 'translate-x-6' : 'translate-x-0.5'
              }`}
            />
          </button>
        </div>
      </section>

      {/* Action Toolbar */}
      <div className="flex justify-between items-center">
        <span className="font-label-md text-xs text-on-surface-variant font-mono uppercase tracking-wider">
          Active Pipelines ({workflows.length})
        </span>

        <button
          onClick={() => setShowAddModal(true)}
          className="bg-primary text-on-primary text-xs font-semibold px-3.5 py-2 rounded-lg flex items-center gap-1.5 hover:bg-primary/90 transition-all cursor-pointer shadow-md"
        >
          <Plus className="w-4 h-4" />
          <span>New Workflow</span>
        </button>
      </div>

      {/* Workflow Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {workflows.map((wf) => (
          <div
            key={wf.id}
            className="bg-surface/60 backdrop-blur-xl border border-white/10 rounded-xl p-5 flex flex-col justify-between gap-4 shadow-lg hover:border-primary/40 transition-all"
          >
            <div className="flex justify-between items-start gap-3">
              <div className="flex flex-col">
                <h3 className="font-body-md text-base font-semibold text-on-surface">{wf.name}</h3>
                <p className="font-body-sm text-xs text-on-surface-variant/80 mt-1 leading-relaxed">
                  {wf.description}
                </p>
              </div>
              {getStatusBadge(wf.status)}
            </div>

            {/* Progress Bar for Running tasks */}
            {wf.status === 'Running' && wf.progress !== undefined && (
              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-on-surface-variant">Pipeline Progress</span>
                  <span className="text-primary font-semibold">{wf.progress}%</span>
                </div>
                <div className="w-full h-2 bg-surface-container-highest rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary rounded-full transition-all duration-500 relative"
                    style={{ width: `${wf.progress}%` }}
                  >
                    <div className="absolute inset-0 bg-white/20 animate-pulse" />
                  </div>
                </div>
              </div>
            )}

            {/* Pipeline Metadata Footer */}
            <div className="flex justify-between items-center pt-3 border-t border-white/5 font-mono text-[11px] text-on-surface-variant">
              <span>
                {wf.model ? `Model: ${wf.model}` : wf.source ? `Source: ${wf.source}` : `Last: ${wf.lastRun || 'N/A'}`}
              </span>

              <button
                onClick={() => onRunWorkflow(wf.id)}
                disabled={wf.status === 'Running'}
                className="text-primary hover:text-primary/80 disabled:opacity-50 flex items-center gap-1 font-sans font-semibold cursor-pointer"
              >
                {wf.status === 'Running' ? (
                  <>
                    <Pause className="w-3.5 h-3.5" />
                    <span>Pause</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5" />
                    <span>Trigger Run</span>
                  </>
                )}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add New Workflow Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-surface-container border border-white/15 rounded-2xl p-6 max-w-md w-full shadow-2xl flex flex-col gap-4">
            <h3 className="text-lg font-bold text-on-surface flex items-center gap-2">
              <Plus className="w-5 h-5 text-primary" />
              Create Custom Pipeline
            </h3>
            <p className="text-xs text-on-surface-variant">
              Define background triggers for content scraping, AI translation, or multi-cloud mirroring.
            </p>

            <input
              type="text"
              value={newWfName}
              onChange={(e) => setNewWfName(e.target.value)}
              placeholder="Workflow Pipeline Name (e.g. Notion Sync)..."
              className="bg-surface-container-highest border border-outline rounded-lg p-3 text-sm text-on-surface focus:outline-none focus:border-primary"
            />

            <div className="flex justify-end gap-2 mt-2">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 text-xs font-semibold text-on-surface-variant hover:text-on-surface cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (newWfName.trim()) {
                    alert(`Created pipeline "${newWfName}". Pipeline initialized on Auto-Pilot schedule.`);
                    setNewWfName('');
                    setShowAddModal(false);
                  }
                }}
                className="bg-primary text-on-primary text-xs font-semibold px-4 py-2 rounded-lg hover:bg-primary/90 cursor-pointer"
              >
                Deploy Pipeline
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
