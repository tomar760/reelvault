import React from 'react';
import { X, Command, Search, PlusCircle, LayoutDashboard, Library, BarChart3, Workflow, Settings, Moon, HelpCircle, Check } from 'lucide-react';

interface KeyboardShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerAction?: (actionId: string) => void;
}

export const KeyboardShortcutsModal: React.FC<KeyboardShortcutsModalProps> = ({
  isOpen,
  onClose,
  onTriggerAction,
}) => {
  if (!isOpen) return null;

  const isMac = typeof navigator !== 'undefined' && /Mac|iPod|iPhone|iPad/.test(navigator.userAgent);
  const modifierKey = isMac ? '⌘' : 'Ctrl';

  const shortcutGroups = [
    {
      title: 'Primary Workflows',
      shortcuts: [
        {
          id: 'search',
          keys: [modifierKey, 'K'],
          label: 'Global Search',
          description: 'Focus global search input anywhere in the vault',
          icon: Search,
        },
        {
          id: 'quick-add',
          keys: [modifierKey, 'N'],
          label: 'Quick Add Entry',
          description: 'Open AI video intake modal to ingest new URL',
          icon: PlusCircle,
        },
        {
          id: 'settings',
          keys: [modifierKey, ','],
          label: 'Vault Settings',
          description: 'Manage auto-pilot, JSON backup & storage',
          icon: Settings,
        },
        {
          id: 'shortcuts',
          keys: ['?'],
          label: 'Shortcuts Help',
          description: 'Toggle this power-user keyboard cheatsheet',
          icon: HelpCircle,
        },
      ],
    },
    {
      title: 'Workspace Navigation',
      shortcuts: [
        {
          id: 'nav-1',
          keys: [modifierKey, '1'],
          label: 'Dashboard',
          description: 'Jump to Executive Dashboard view',
          icon: LayoutDashboard,
        },
        {
          id: 'nav-2',
          keys: [modifierKey, '2'],
          label: 'Vault Library',
          description: 'Open full video library & batch edit',
          icon: Library,
        },
        {
          id: 'nav-3',
          keys: [modifierKey, '3'],
          label: 'Analytics',
          description: 'View metric graphs & category insights',
          icon: BarChart3,
        },
        {
          id: 'nav-4',
          keys: [modifierKey, '4'],
          label: 'Workflows',
          description: 'Run background batch automation pipelines',
          icon: Workflow,
        },
      ],
    },
    {
      title: 'Quick Actions & Controls',
      shortcuts: [
        {
          id: 'slash-search',
          keys: ['/'],
          label: 'Instant Focus',
          description: 'Focus search bar without modifier key',
          icon: Search,
        },
        {
          id: 'theme',
          keys: [modifierKey, 'Shift', 'T'],
          label: 'Toggle Theme',
          description: 'Switch between Dark and Light mode',
          icon: Moon,
        },
        {
          id: 'close',
          keys: ['Esc'],
          label: 'Dismiss Overlay',
          description: 'Close active popovers, search, or dialogs',
          icon: X,
        },
      ],
    },
  ];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      {/* Backdrop click */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Modal Card */}
      <div className="relative w-full max-w-2xl bg-surface-container-high/95 backdrop-blur-2xl border border-white/20 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Glow accent */}
        <div className="absolute -top-16 -right-16 w-48 h-48 bg-tertiary/20 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 relative z-10">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-tertiary/20 text-tertiary border border-tertiary/30 shadow-xs">
              <Command className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-headline-lg-mobile text-lg font-bold text-on-surface">
                  Keyboard Shortcuts
                </h2>
                <span className="bg-tertiary/20 text-tertiary px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border border-tertiary/30">
                  POWER-USER MODE
                </span>
              </div>
              <p className="text-xs text-on-surface-variant font-body-sm mt-0.5">
                Speed up video ingestion & navigation using global key bindings
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-on-surface-variant hover:text-on-surface hover:bg-white/10 transition-colors cursor-pointer"
            title="Close (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body: Shortcut Groups */}
        <div className="p-6 overflow-y-auto flex flex-col gap-6 relative z-10">
          {shortcutGroups.map((group, groupIdx) => (
            <div key={groupIdx} className="flex flex-col gap-3">
              <h3 className="text-xs font-mono font-bold text-tertiary uppercase tracking-wider flex items-center gap-2">
                <span>{group.title}</span>
                <span className="flex-1 h-px bg-white/10" />
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                {group.shortcuts.map((sc) => {
                  const IconComp = sc.icon;
                  return (
                    <div
                      key={sc.id}
                      onClick={() => {
                        if (onTriggerAction) onTriggerAction(sc.id);
                      }}
                      className="p-3 rounded-xl bg-surface-container-low/80 hover:bg-surface-container-high border border-white/10 hover:border-tertiary/50 transition-all flex items-center justify-between gap-3 group cursor-pointer shadow-xs"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="p-2 rounded-lg bg-surface text-on-surface-variant group-hover:text-tertiary transition-colors border border-white/10">
                          <IconComp className="w-4 h-4" />
                        </div>
                        <div className="flex flex-col min-w-0">
                          <span className="text-xs font-semibold text-on-surface group-hover:text-tertiary transition-colors truncate">
                            {sc.label}
                          </span>
                          <span className="text-[10px] text-on-surface-variant/80 font-body-sm truncate">
                            {sc.description}
                          </span>
                        </div>
                      </div>

                      {/* KBD Key Caps */}
                      <div className="flex items-center gap-1 shrink-0">
                        {sc.keys.map((k, kIdx) => (
                          <kbd
                            key={kIdx}
                            className="px-2 py-1 bg-surface border border-white/20 text-tertiary font-mono text-[11px] font-bold rounded-md shadow-inner min-w-[24px] text-center"
                          >
                            {k}
                          </kbd>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-surface-container-low/90 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 relative z-10 text-xs font-mono text-on-surface-variant">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Active listener enabled across all views</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-tertiary text-black font-bold text-xs hover:bg-tertiary/90 transition-all cursor-pointer shadow-md"
          >
            Got it (Esc)
          </button>
        </div>
      </div>
    </div>
  );
};
