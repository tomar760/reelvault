import React, { useState } from 'react';
import {
  ArrowLeft,
  Play,
  Star,
  Sparkles,
  CheckSquare,
  Square,
  Tag,
  ExternalLink,
  HardDrive,
  FileSpreadsheet,
  RefreshCw,
  Heart,
  Trash2,
  Edit2,
  Video,
  Tv,
  X,
  ImagePlus,
  Sliders,
  Upload,
  Check,
  Wand2,
  Film,
  Image as ImageIcon,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  AlertCircle,
  Bookmark,
  Compass,
  Layers,
} from 'lucide-react';
import { VaultItem } from '../types';

interface VaultItemDetailViewProps {
  item: VaultItem;
  onBack: () => void;
  onUpdateItem: (updated: VaultItem) => void;
  onDeleteItem: (id: string) => void;
  onExportCSV: () => void;
}

const getVideoPlatformInfo = (url: string) => {
  if (!url) return { type: 'unsupported' as const, label: 'External Stream' };

  // YouTube
  const ytMatch = url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?|shorts)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i);
  if (ytMatch && ytMatch[1]) {
    return {
      type: 'youtube' as const,
      label: 'YouTube Embed',
      embedUrl: `https://www.youtube-nocookie.com/embed/${ytMatch[1]}?autoplay=1&rel=0`
    };
  }

  // Vimeo
  const vimeoMatch = url.match(/vimeo\.com\/(?:channels\/(?:\w+\/)?|groups\/[^\/]*\/videos\/|album\/\d+\/video\/|video\/|)(\d+)/i);
  if (vimeoMatch && vimeoMatch[1]) {
    return {
      type: 'vimeo' as const,
      label: 'Vimeo Player',
      embedUrl: `https://player.vimeo.com/video/${vimeoMatch[1]}?autoplay=1`
    };
  }

  // Loom
  const loomMatch = url.match(/loom\.com\/(?:share|embed)\/([a-f0-9]+)/i);
  if (loomMatch && loomMatch[1]) {
    return {
      type: 'loom' as const,
      label: 'Loom Player',
      embedUrl: `https://www.loom.com/embed/${loomMatch[1]}?autoplay=1`
    };
  }

  // Direct HTML5 Video
  if (/\.(mp4|webm|ogg|m3u8)(\?.*)?$/i.test(url)) {
    return {
      type: 'direct' as const,
      label: 'HTML5 Video',
      embedUrl: url
    };
  }

  return {
    type: 'unsupported' as const,
    label: 'External Stream'
  };
};

export const VaultItemDetailView: React.FC<VaultItemDetailViewProps> = ({
  item,
  onBack,
  onUpdateItem,
  onDeleteItem,
  onExportCSV,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [videoLoadError, setVideoLoadError] = useState(false);
  const [isSimulatedPlaying, setIsSimulatedPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [simulatedTime, setSimulatedTime] = useState(25); // percentage
  const [activeChapterIndex, setActiveChapterIndex] = useState<number | null>(null);
  const [completedTakeaways, setCompletedTakeaways] = useState<Record<number, boolean>>({});
  const [newTagInput, setNewTagInput] = useState('');
  const [isEditingRemarks, setIsEditingRemarks] = useState(false);
  const [remarksText, setRemarksText] = useState(item.remarks || '');
  const [isRegenerating, setIsRegenerating] = useState(false);

  // Thumbnail Customization State
  const [isThumbnailModalOpen, setIsThumbnailModalOpen] = useState(false);
  const [thumbnailTab, setThumbnailTab] = useState<'frames' | 'ai' | 'upload'>('frames');
  const [selectedCandidateUrl, setSelectedCandidateUrl] = useState<string>(item.thumbnailUrl);
  const [scrubberPosition, setScrubberPosition] = useState(30); // percentage
  const [aiPrompt, setAiPrompt] = useState(`${item.title} - ${item.category} high tech masterclass cover`);
  const [aiStyle, setAiStyle] = useState<'cinematic' | 'neon' | 'minimalist' | 'glass' | 'code'>('cinematic');
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [customUrlInput, setCustomUrlInput] = useState('');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const platform = getVideoPlatformInfo(item.url);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  // Sample Frame Snapshots calculated from video ID & duration
  const candidateFrames = [
    {
      timestamp: '00:15',
      label: 'Intro Frame',
      url: `https://picsum.photos/seed/${item.id}-frame1/800/450`,
    },
    {
      timestamp: '02:45',
      label: 'Key Slide',
      url: `https://picsum.photos/seed/${item.id}-frame2/800/450`,
    },
    {
      timestamp: '05:30',
      label: 'Demo / Code',
      url: `https://picsum.photos/seed/${item.id}-frame3/800/450`,
    },
    {
      timestamp: '08:15',
      label: 'Diagram / Arch',
      url: `https://picsum.photos/seed/${item.id}-frame4/800/450`,
    },
    {
      timestamp: '11:00',
      label: 'Summary',
      url: `https://picsum.photos/seed/${item.id}-frame5/800/450`,
    },
  ];

  // AI Preset Styles
  const aiPresets = [
    { id: 'cinematic' as const, label: 'Cinematic Dark', seed: 'cinematic-dark-glow' },
    { id: 'neon' as const, label: 'Neon Cyberpunk', seed: 'neon-cyber-tech' },
    { id: 'minimalist' as const, label: 'Minimalist Vector', seed: 'minimalist-vector-flat' },
    { id: 'glass' as const, label: '3D Glassmorphism', seed: '3d-glass-abstract' },
    { id: 'code' as const, label: 'Code & IDE Focus', seed: 'code-editor-dark' },
  ];

  const handleGenerateAiThumbnail = () => {
    setIsGeneratingAI(true);
    setTimeout(() => {
      const generatedUrl = `https://picsum.photos/seed/${encodeURIComponent(aiStyle + '-' + item.title + '-' + Date.now())}/800/450`;
      setSelectedCandidateUrl(generatedUrl);
      setIsGeneratingAI(false);
      showToast('Generated AI Thumbnail preview successfully!');
    }, 1100);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setSelectedCandidateUrl(reader.result);
          showToast('Uploaded custom image!');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleApplyThumbnail = () => {
    if (!selectedCandidateUrl) return;
    onUpdateItem({ ...item, thumbnailUrl: selectedCandidateUrl });
    setIsThumbnailModalOpen(false);
    showToast('Video thumbnail updated!');
  };

  const toggleTakeaway = (index: number) => {
    setCompletedTakeaways((prev) => ({
      ...prev,
      [index]: !prev[index],
    }));
  };

  const handleAddTag = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTagInput.trim()) return;
    const tag = newTagInput.trim();
    if (!item.tags.includes(tag)) {
      const updated = { ...item, tags: [...item.tags, tag] };
      onUpdateItem(updated);
    }
    setNewTagInput('');
  };

  const handleRemoveTag = (tagToRemove: string) => {
    const updated = { ...item, tags: item.tags.filter((t) => t !== tagToRemove) };
    onUpdateItem(updated);
  };

  const handleSaveRemarks = () => {
    const updated = { ...item, remarks: remarksText };
    onUpdateItem(updated);
    setIsEditingRemarks(false);
  };

  const handleRegenerateAI = async () => {
    setIsRegenerating(true);
    setTimeout(() => {
      const updated = {
        ...item,
        summary: item.summary + ' Updated with latest Gemini model insights.',
        sentimentTag: 'Verified Masterclass',
      };
      onUpdateItem(updated);
      setIsRegenerating(false);
      alert('AI Metadata regenerated successfully using Gemini 3.6 Flash!');
    }, 1200);
  };

  return (
    <div className="flex flex-col gap-6 max-w-5xl mx-auto w-full pb-20">
      {/* Top Back Navigation Bar */}
      <div className="flex justify-between items-center">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm font-semibold text-on-surface-variant hover:text-on-surface hover:bg-white/5 px-3 py-2 rounded-lg transition-all cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Library</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              const updated = { ...item, favorite: !item.favorite };
              onUpdateItem(updated);
            }}
            className={`p-2 rounded-lg border border-white/10 transition-all cursor-pointer ${
              item.favorite ? 'bg-rose-500/20 text-rose-400 border-rose-500/30' : 'bg-surface-container text-on-surface-variant hover:text-on-surface'
            }`}
            title="Toggle Favorite"
          >
            <Heart className={`w-4 h-4 ${item.favorite ? 'fill-rose-500' : ''}`} />
          </button>

          <button
            onClick={() => {
              if (confirm('Are you sure you want to delete this video from your vault?')) {
                onDeleteItem(item.id);
                onBack();
              }
            }}
            className="p-2 rounded-lg bg-surface-container border border-white/10 text-rose-400 hover:bg-rose-500/20 transition-all cursor-pointer"
            title="Delete Video"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Video Preview Player Container */}
      <div className="relative w-full aspect-video rounded-2xl bg-black overflow-hidden border border-white/15 shadow-2xl group">
        {!isPlaying ? (
          <div className="relative w-full h-full flex items-center justify-center">
            {/* Thumbnail Background */}
            <img
              src={item.thumbnailUrl}
              alt={item.title}
              className="w-full h-full object-cover opacity-85 group-hover:scale-105 transition-all duration-500"
            />
            
            {/* Dark Overlay Gradient */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/60" />

            {/* Click to Play Center Overlay */}
            <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center z-10">
              <button
                onClick={() => setIsPlaying(true)}
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-primary text-on-primary flex items-center justify-center shadow-[0_0_40px_rgba(173,198,255,0.7)] hover:scale-110 active:scale-95 transition-all cursor-pointer border-2 border-white/30 group-hover:bg-primary/90"
                title="Play Video Preview"
              >
                <Play className="w-8 h-8 sm:w-10 sm:h-10 fill-on-primary ml-1" />
              </button>
              
              <span className="font-label-md text-xs sm:text-sm text-white/90 mt-3.5 font-bold tracking-wider uppercase font-mono bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                Click to Play ({platform.label})
              </span>
            </div>

            {/* Platform Badge Top Left */}
            <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-md border border-white/15 px-3 py-1 rounded-lg text-xs font-mono text-primary flex items-center gap-1.5 z-10">
              <Tv className="w-3.5 h-3.5" />
              <span>{platform.label}</span>
            </div>

            {/* Customize Thumbnail Button Top Right */}
            <button
              onClick={() => setIsThumbnailModalOpen(true)}
              className="absolute top-3 right-3 bg-black/80 hover:bg-black text-white/90 hover:text-white backdrop-blur-md border border-white/20 px-3 py-1 rounded-lg text-xs font-mono flex items-center gap-1.5 z-10 transition-all cursor-pointer shadow-lg hover:border-primary"
              title="Change Video Thumbnail"
            >
              <ImagePlus className="w-3.5 h-3.5 text-primary" />
              <span>Change Thumbnail</span>
            </button>

            {/* Duration Badge Bottom Right */}
            <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur-md border border-white/10 px-2.5 py-1 rounded-md text-xs font-mono text-white z-10">
              {item.duration}
            </div>
          </div>
        ) : (
          /* Active Embed / Player State */
          <div className="relative w-full h-full bg-black flex flex-col items-center justify-center">
            {/* Close / Return Button */}
            <button
              onClick={() => setIsPlaying(false)}
              className="absolute top-3 right-3 z-30 p-2 rounded-xl bg-black/80 hover:bg-black text-white/80 hover:text-white border border-white/20 backdrop-blur-md transition-all cursor-pointer flex items-center gap-1.5 text-xs font-mono"
              title="Close Player"
            >
              <X className="w-4 h-4" />
              <span>Close Player</span>
            </button>

            {platform.type === 'youtube' || platform.type === 'vimeo' || platform.type === 'loom' ? (
              <iframe
                src={platform.embedUrl}
                title={item.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                className="w-full h-full border-0 relative z-10"
              />
            ) : platform.type === 'direct' && !videoLoadError ? (
              <video
                src={platform.embedUrl}
                controls
                autoPlay
                onError={() => setVideoLoadError(true)}
                className="w-full h-full object-contain relative z-10"
              />
            ) : (
              /* Enhanced Video Player Placeholder using thumbnailUrl */
              <div className="relative w-full h-full flex flex-col justify-between p-4 sm:p-6 bg-black/95 select-none overflow-hidden">
                {/* Poster Background with Blur & Ambient Glow */}
                <img
                  src={item.thumbnailUrl || 'https://picsum.photos/seed/vaultplayer/1280/720'}
                  alt={item.title}
                  className="absolute inset-0 w-full h-full object-cover opacity-35 filter blur-xs group-hover:blur-none transition-all duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/80" />

                {/* Top Overlay Bar */}
                <div className="relative z-20 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-md bg-tertiary/20 text-tertiary border border-tertiary/40 text-[10px] font-mono font-bold flex items-center gap-1.5 backdrop-blur-md">
                      <Film className="w-3.5 h-3.5" />
                      <span>Thumbnail Player Placeholder</span>
                    </span>
                    <span className="px-2.5 py-1 rounded-md bg-white/10 text-white/80 border border-white/10 text-[10px] font-mono hidden sm:inline-block backdrop-blur-md">
                      {platform.label}
                    </span>
                  </div>

                  <button
                    onClick={() => setIsThumbnailModalOpen(true)}
                    className="px-2.5 py-1 rounded-md bg-surface-container-high/90 hover:bg-surface-container-highest border border-white/20 text-white text-xs font-mono flex items-center gap-1.5 backdrop-blur-md transition-all cursor-pointer shadow-md"
                    title="Change Poster Thumbnail"
                  >
                    <ImagePlus className="w-3.5 h-3.5 text-primary" />
                    <span className="hidden xs:inline">Edit Cover</span>
                  </button>
                </div>

                {/* Center Discovery & Stream Launch Info */}
                <div className="relative z-20 flex flex-col items-center justify-center my-auto text-center px-4 max-w-xl mx-auto">
                  <div className="relative mb-3">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-primary/30 to-tertiary/30 border border-white/20 flex items-center justify-center backdrop-blur-md shadow-2xl">
                      {isSimulatedPlaying ? (
                        <div className="flex items-center gap-1">
                          <span className="w-1.5 h-6 bg-tertiary rounded-full animate-pulse" />
                          <span className="w-1.5 h-8 bg-primary rounded-full animate-pulse delay-75" />
                          <span className="w-1.5 h-4 bg-secondary rounded-full animate-pulse delay-150" />
                        </div>
                      ) : (
                        <Video className="w-8 h-8 sm:w-10 sm:h-10 text-tertiary" />
                      )}
                    </div>
                    {videoLoadError && (
                      <span className="absolute -top-1 -right-1 p-1 rounded-full bg-rose-500 text-white text-[10px] font-bold shadow-lg" title="Direct Video Stream Failed to Load">
                        <AlertCircle className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </div>

                  <h3 className="font-bold text-sm sm:text-base text-white mb-1 line-clamp-2 leading-snug">
                    {item.title}
                  </h3>

                  <p className="text-xs text-on-surface-variant/90 font-mono mb-4 max-w-md line-clamp-2">
                    {videoLoadError
                      ? 'Direct video file failed to stream. Displaying interactive Thumbnail Canvas placeholder.'
                      : `Full video stream is hosted externally on ${item.url.slice(0, 40)}...`}
                  </p>

                  <div className="flex items-center gap-2.5 flex-wrap justify-center">
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-primary hover:bg-primary/90 text-on-primary font-semibold px-4 py-2 rounded-xl text-xs flex items-center gap-2 transition-all shadow-lg cursor-pointer"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Launch External Stream</span>
                    </a>

                    <button
                      type="button"
                      onClick={() => setIsSimulatedPlaying(!isSimulatedPlaying)}
                      className="bg-surface-container-high/90 hover:bg-surface-container-highest text-white border border-white/20 font-semibold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 backdrop-blur-md transition-all cursor-pointer"
                    >
                      {isSimulatedPlaying ? (
                        <>
                          <Pause className="w-3.5 h-3.5 text-tertiary" />
                          <span>Pause Preview</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-3.5 h-3.5 text-tertiary fill-current" />
                          <span>Simulate Preview</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Bottom Interactive Control Bar with Scrubber & Chapter Markers */}
                <div className="relative z-20 flex flex-col gap-2 bg-black/80 backdrop-blur-md border border-white/10 rounded-xl p-2.5 sm:p-3 shadow-2xl">
                  {/* Timeline Scrubber with Key Takeaway Chapter Markers */}
                  <div className="relative w-full h-3 bg-white/15 rounded-full cursor-pointer flex items-center group/scrubber"
                    onClick={(e) => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      const pos = Math.max(0, Math.min(100, Math.round(((e.clientX - rect.left) / rect.width) * 100)));
                      setSimulatedTime(pos);
                    }}
                  >
                    {/* Filled Progress Bar */}
                    <div
                      className="h-full bg-gradient-to-r from-primary to-tertiary rounded-full relative transition-all duration-150"
                      style={{ width: `${simulatedTime}%` }}
                    >
                      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3.5 h-3.5 bg-white rounded-full shadow-md border-2 border-primary scale-90 group-hover/scrubber:scale-110 transition-transform" />
                    </div>

                    {/* Key Takeaways Chapter Nodes on Timeline */}
                    {item.keyTakeaways && item.keyTakeaways.length > 0 && item.keyTakeaways.map((takeaway, idx) => {
                      const nodePos = Math.round(((idx + 1) / (item.keyTakeaways.length + 1)) * 100);
                      const isHoveredOrActive = activeChapterIndex === idx;

                      return (
                        <div
                          key={idx}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSimulatedTime(nodePos);
                            setActiveChapterIndex(idx);
                          }}
                          className={`absolute top-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full border border-black cursor-pointer transition-all z-20 ${
                            isHoveredOrActive ? 'bg-amber-400 scale-125 ring-2 ring-amber-400/50' : 'bg-tertiary hover:scale-125'
                          }`}
                          style={{ left: `${nodePos}%` }}
                          title={`Chapter #${idx + 1}: ${takeaway}`}
                        />
                      );
                    })}
                  </div>

                  {/* Active Chapter Label Bar */}
                  {activeChapterIndex !== null && item.keyTakeaways[activeChapterIndex] && (
                    <div className="text-[11px] text-tertiary font-mono flex items-center justify-between gap-2 px-1 animate-fadeIn">
                      <span className="truncate">
                        📍 Chapter #{activeChapterIndex + 1}: {item.keyTakeaways[activeChapterIndex]}
                      </span>
                      <button
                        onClick={() => setActiveChapterIndex(null)}
                        className="text-[10px] text-on-surface-variant hover:text-white cursor-pointer"
                      >
                        Dismiss
                      </button>
                    </div>
                  )}

                  {/* Player Controls Strip */}
                  <div className="flex items-center justify-between text-xs font-mono text-white/90">
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => setIsSimulatedPlaying(!isSimulatedPlaying)}
                        className="p-1 rounded hover:bg-white/10 text-white cursor-pointer transition-colors"
                        title={isSimulatedPlaying ? 'Pause' : 'Play'}
                      >
                        {isSimulatedPlaying ? (
                          <Pause className="w-4 h-4 text-tertiary" />
                        ) : (
                          <Play className="w-4 h-4 fill-current text-primary" />
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => setIsMuted(!isMuted)}
                        className="p-1 rounded hover:bg-white/10 text-white/80 hover:text-white cursor-pointer transition-colors"
                        title={isMuted ? 'Unmute' : 'Mute'}
                      >
                        {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
                      </button>

                      <span className="text-[11px] text-on-surface-variant font-mono">
                        {Math.floor((simulatedTime / 100) * 10)}:15 / {item.duration || '10:00'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="px-1.5 py-0.5 rounded bg-white/10 text-[9px] font-bold text-white border border-white/15">
                        1080p HD
                      </span>
                      <span className="px-1.5 py-0.5 rounded bg-tertiary/20 text-tertiary text-[9px] font-bold border border-tertiary/30">
                        POSTER MODE
                      </span>
                      <button
                        type="button"
                        onClick={() => setIsThumbnailModalOpen(true)}
                        className="p-1 rounded hover:bg-white/10 text-white/80 hover:text-white cursor-pointer"
                        title="Full View / Custom Poster"
                      >
                        <Maximize2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Title & Metadata Badges */}
      <div className="flex flex-col gap-2">
        <div className="flex flex-wrap items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-mono bg-tertiary/15 text-tertiary border border-tertiary/30 font-semibold">
            {item.rating}
          </span>
          <span className="px-2.5 py-0.5 rounded-full text-xs font-mono bg-primary/15 text-primary border border-primary/30">
            {item.category}
          </span>
          {typeof item.watchProgress === 'number' && (
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-mono border ${
              item.watchProgress >= 100
                ? 'bg-tertiary/20 text-tertiary border-tertiary/40 font-semibold'
                : 'bg-primary/20 text-primary border-primary/40'
            }`}>
              {item.watchProgress}% Watched
            </span>
          )}
          <span className="text-xs font-mono text-on-surface-variant">Added: {item.date}</span>
        </div>

        <h1 className="font-headline-lg text-xl sm:text-2xl font-bold text-on-surface mt-1 leading-snug">
          {item.title}
        </h1>
      </div>

      {/* Interactive Watch Progress Control */}
      <div className="bg-surface/60 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <div className={`w-2.5 h-2.5 rounded-full ${(item.watchProgress ?? 0) >= 100 ? 'bg-tertiary shadow-[0_0_8px_rgba(107,222,128,0.8)]' : 'bg-primary animate-pulse'}`} />
            <span className="font-label-md text-xs uppercase tracking-wider text-on-surface-variant font-semibold">
              Watch Progress Metadata
            </span>
          </div>
          <span className="font-headline-md text-lg font-bold text-on-surface font-mono">
            {item.watchProgress ?? 0}% viewed
          </span>
        </div>

        <div className="flex flex-col sm:items-end gap-2 shrink-0">
          <div className="flex items-center gap-2 w-full sm:w-64">
            <input
              type="range"
              min="0"
              max="100"
              step="5"
              value={item.watchProgress ?? 0}
              onChange={(e) => {
                const val = Number(e.target.value);
                onUpdateItem({ ...item, watchProgress: val });
              }}
              className="w-full accent-primary h-2 bg-surface-container-highest rounded-lg cursor-pointer"
            />
            <span className="text-xs font-mono font-semibold text-primary w-10 text-right">
              {item.watchProgress ?? 0}%
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-[11px] font-mono">
            <button
              type="button"
              onClick={() => onUpdateItem({ ...item, watchProgress: 0 })}
              className="px-2 py-0.5 rounded bg-surface-container-high hover:bg-white/10 text-on-surface-variant border border-white/5 cursor-pointer"
            >
              Reset (0%)
            </button>
            <button
              type="button"
              onClick={() => onUpdateItem({ ...item, watchProgress: 50 })}
              className="px-2 py-0.5 rounded bg-surface-container-high hover:bg-white/10 text-on-surface-variant border border-white/5 cursor-pointer"
            >
              50%
            </button>
            <button
              type="button"
              onClick={() => onUpdateItem({ ...item, watchProgress: 100 })}
              className="px-2 py-0.5 rounded bg-tertiary/20 text-tertiary hover:bg-tertiary/30 border border-tertiary/30 font-semibold cursor-pointer"
            >
              Mark Watched (100%)
            </button>
          </div>
        </div>
      </div>

      {/* AI Analysis Card */}
      <section className="bg-surface/80 backdrop-blur-2xl border border-white/10 rounded-2xl p-5 sm:p-6 flex flex-col gap-5 shadow-xl relative overflow-hidden">
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-tertiary" />
            <h2 className="font-headline-md text-base sm:text-lg font-bold text-on-surface">
              AI Analysis Complete
            </h2>
          </div>

          <span className="font-mono text-xs text-secondary-container bg-secondary/15 px-2.5 py-1 rounded-full border border-secondary/30">
            {item.sentimentTag}
          </span>
        </div>

        {/* Summary */}
        <div className="flex flex-col gap-1.5">
          <h3 className="font-label-md text-xs text-on-surface-variant uppercase font-semibold">Technical Executive Summary</h3>
          <p className="font-body-md text-sm text-on-surface/90 leading-relaxed bg-surface-container-low p-4 rounded-xl border border-white/5">
            {item.summary}
          </p>
        </div>

        {/* Key Takeaways */}
        <div className="flex flex-col gap-2.5">
          <h3 className="font-label-md text-xs text-on-surface-variant uppercase font-semibold">Key Actionable Takeaways</h3>
          <div className="flex flex-col gap-2">
            {item.keyTakeaways.map((takeaway, idx) => {
              const isChecked = !!completedTakeaways[idx];
              return (
                <div
                  key={idx}
                  onClick={() => toggleTakeaway(idx)}
                  className={`p-3 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                    isChecked
                      ? 'bg-tertiary/10 border-tertiary/30 text-tertiary/80 line-through'
                      : 'bg-surface-container-low border-white/5 text-on-surface hover:border-white/20'
                  }`}
                >
                  <button className="mt-0.5 text-tertiary cursor-pointer shrink-0">
                    {isChecked ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4 text-on-surface-variant" />}
                  </button>
                  <span className="font-body-sm text-xs sm:text-sm">{takeaway}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Tags Editor */}
        <div className="flex flex-col gap-2 pt-2 border-t border-white/5">
          <h3 className="font-label-md text-xs text-on-surface-variant uppercase font-semibold flex items-center gap-1.5">
            <Tag className="w-3.5 h-3.5 text-primary" />
            Auto-Generated Tags
          </h3>

          <div className="flex flex-wrap items-center gap-2">
            {item.tags.map((tag) => (
              <span
                key={tag}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-mono bg-surface-container-highest border border-white/10 text-on-surface"
              >
                #{tag}
                <button
                  onClick={() => handleRemoveTag(tag)}
                  className="hover:text-rose-400 text-on-surface-variant cursor-pointer"
                >
                  ×
                </button>
              </span>
            ))}

            <form onSubmit={handleAddTag} className="flex items-center gap-1">
              <input
                type="text"
                value={newTagInput}
                onChange={(e) => setNewTagInput(e.target.value)}
                placeholder="+ Add tag..."
                className="bg-surface-container border border-outline-variant rounded-lg px-2.5 py-1 text-xs text-on-surface placeholder:text-on-surface-variant/50 focus:outline-none focus:border-primary w-24"
              />
            </form>
          </div>
        </div>

        {/* Detected Links */}
        {item.detectedLinks && item.detectedLinks.length > 0 && (
          <div className="flex flex-col gap-2 pt-2 border-t border-white/5">
            <h3 className="font-label-md text-xs text-on-surface-variant uppercase font-semibold">Detected Resource Links</h3>
            <div className="flex flex-wrap gap-2">
              {item.detectedLinks.map((link, idx) => (
                <a
                  key={idx}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-surface-container border border-white/10 hover:border-primary px-3 py-1.5 rounded-lg text-xs font-mono text-primary flex items-center gap-1.5 transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>{link.label}</span>
                </a>
              ))}
            </div>
          </div>
        )}

        {/* Remarks Section */}
        <div className="flex flex-col gap-2 pt-2 border-t border-white/5">
          <div className="flex justify-between items-center">
            <h3 className="font-label-md text-xs text-on-surface-variant uppercase font-semibold">Review Remarks</h3>
            <button
              onClick={() => setIsEditingRemarks(!isEditingRemarks)}
              className="text-xs text-primary hover:underline flex items-center gap-1 cursor-pointer"
            >
              <Edit2 className="w-3 h-3" />
              <span>{isEditingRemarks ? 'Cancel' : 'Edit Remarks'}</span>
            </button>
          </div>

          {isEditingRemarks ? (
            <div className="flex flex-col gap-2">
              <textarea
                value={remarksText}
                onChange={(e) => setRemarksText(e.target.value)}
                className="bg-surface-container-highest border border-outline rounded-lg p-3 text-xs text-on-surface h-20"
              />
              <button
                onClick={handleSaveRemarks}
                className="bg-primary text-on-primary font-semibold text-xs py-1.5 px-3 rounded-lg self-end"
              >
                Save Remarks
              </button>
            </div>
          ) : (
            <p className="font-body-sm text-xs text-on-surface-variant bg-surface-container-low p-3 rounded-lg border border-white/5 italic">
              "{item.remarks}"
            </p>
          )}
        </div>
      </section>

      {/* Toast Feedback Notification Banner */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 z-50 bg-surface-container-highest border border-primary/40 text-on-surface px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 text-xs font-mono animate-fadeIn">
          <div className="p-1 rounded-full bg-primary/20 text-primary">
            <Check className="w-4 h-4" />
          </div>
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Thumbnail Customization Modal */}
      {isThumbnailModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-surface-container-high border border-white/15 rounded-2xl max-w-2xl w-full p-6 shadow-2xl flex flex-col gap-5 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                <ImagePlus className="w-5 h-5 text-primary" />
                <h3 className="font-semibold text-lg text-on-surface">Customize Video Thumbnail</h3>
              </div>
              <button
                onClick={() => setIsThumbnailModalOpen(false)}
                className="text-on-surface-variant hover:text-on-surface p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Current vs Selected Live Preview Banner */}
            <div className="bg-surface-container/80 border border-white/10 rounded-xl p-3.5 flex flex-col sm:flex-row items-center gap-4">
              <div className="relative w-full sm:w-48 aspect-video rounded-lg overflow-hidden border border-primary/40 shrink-0">
                <img
                  src={selectedCandidateUrl}
                  alt="Thumbnail Preview"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute bottom-1 left-1 bg-black/80 text-[10px] font-mono text-primary px-1.5 py-0.5 rounded border border-primary/30">
                  New Thumbnail
                </span>
              </div>
              <div className="flex flex-col gap-1 text-xs text-on-surface-variant flex-1">
                <span className="font-semibold text-on-surface text-sm line-clamp-1">{item.title}</span>
                <p>Pick a custom video frame snapshot or generate/upload an AI image thumbnail to re-cover this video.</p>
              </div>
            </div>

            {/* Tab Navigation */}
            <div className="flex bg-surface-container p-1 rounded-xl border border-white/10">
              <button
                type="button"
                onClick={() => setThumbnailTab('frames')}
                className={`flex-1 py-2 text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  thumbnailTab === 'frames'
                    ? 'bg-primary text-on-primary shadow-sm'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                <Film className="w-4 h-4" />
                <span>Pick Video Frame ({candidateFrames.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setThumbnailTab('ai')}
                className={`flex-1 py-2 text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  thumbnailTab === 'ai'
                    ? 'bg-primary text-on-primary shadow-sm'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                <Wand2 className="w-4 h-4" />
                <span>AI Thumbnail Generator</span>
              </button>

              <button
                type="button"
                onClick={() => setThumbnailTab('upload')}
                className={`flex-1 py-2 text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  thumbnailTab === 'upload'
                    ? 'bg-primary text-on-primary shadow-sm'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                <Upload className="w-4 h-4" />
                <span>Upload / URL</span>
              </button>
            </div>

            {/* Tab 1: Video Frames Picker */}
            {thumbnailTab === 'frames' && (
              <div className="flex flex-col gap-4">
                <div className="flex items-center justify-between text-xs text-on-surface-variant font-mono">
                  <span>Candidate frames extracted from video timeline:</span>
                  <span>Click frame to set preview</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {candidateFrames.map((frame, idx) => {
                    const isSelected = selectedCandidateUrl === frame.url;
                    return (
                      <div
                        key={idx}
                        onClick={() => setSelectedCandidateUrl(frame.url)}
                        className={`relative rounded-xl overflow-hidden border-2 cursor-pointer transition-all aspect-video group ${
                          isSelected
                            ? 'border-primary ring-2 ring-primary/40 scale-102 shadow-lg'
                            : 'border-white/10 hover:border-white/30 opacity-80 hover:opacity-100'
                        }`}
                      >
                        <img
                          src={frame.url}
                          alt={frame.label}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                        
                        <div className="absolute top-1.5 left-1.5 bg-black/80 text-[10px] font-mono px-1.5 py-0.5 rounded border border-white/10 text-white">
                          {frame.timestamp}
                        </div>

                        <div className="absolute bottom-1.5 left-1.5 right-1.5 flex items-center justify-between text-[11px] font-semibold text-white truncate">
                          <span>{frame.label}</span>
                          {isSelected && (
                            <span className="p-0.5 rounded-full bg-primary text-on-primary">
                              <Check className="w-3 h-3" />
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Timeline Frame Scrubber Slider */}
                <div className="bg-surface-container p-3.5 rounded-xl border border-white/10 flex flex-col gap-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-on-surface-variant flex items-center gap-1">
                      <Sliders className="w-3.5 h-3.5 text-primary" /> Timeline Scrubber:
                    </span>
                    <span className="text-primary font-bold">{scrubberPosition}% ({item.duration})</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={scrubberPosition}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setScrubberPosition(val);
                      const scrubSeed = `${item.id}-scrub-${val}`;
                      setSelectedCandidateUrl(`https://picsum.photos/seed/${scrubSeed}/800/450`);
                    }}
                    className="w-full accent-primary h-2 bg-surface-container-highest rounded-lg cursor-pointer"
                  />
                </div>
              </div>
            )}

            {/* Tab 2: AI Thumbnail Generator */}
            {thumbnailTab === 'ai' && (
              <div className="flex flex-col gap-4">
                <div className="flex flex-col gap-2">
                  <label className="text-xs font-mono text-on-surface-variant">AI Image Prompt:</label>
                  <input
                    type="text"
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    className="bg-surface-container border border-outline-variant rounded-xl px-3.5 py-2.5 text-xs text-on-surface focus:outline-none focus:border-primary font-mono"
                    placeholder="Enter AI image prompt..."
                  />
                </div>

                <div className="flex flex-col gap-2">
                  <label className="text-xs font-mono text-on-surface-variant">Select AI Visual Style Preset:</label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {aiPresets.map((preset) => (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => setAiStyle(preset.id)}
                        className={`p-2.5 rounded-xl border text-xs text-left font-medium transition-all cursor-pointer flex items-center justify-between ${
                          aiStyle === preset.id
                            ? 'bg-primary/20 text-primary border-primary font-semibold shadow-xs'
                            : 'bg-surface-container border-white/5 text-on-surface-variant hover:text-on-surface hover:bg-white/5'
                        }`}
                      >
                        <span>{preset.label}</span>
                        {aiStyle === preset.id && <Check className="w-3.5 h-3.5 text-primary shrink-0" />}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleGenerateAiThumbnail}
                  disabled={isGeneratingAI}
                  className="w-full py-3 bg-gradient-to-r from-primary to-secondary text-on-primary rounded-xl text-xs font-semibold flex items-center justify-center gap-2 hover:opacity-95 cursor-pointer disabled:opacity-50 shadow-lg"
                >
                  <Wand2 className={`w-4 h-4 ${isGeneratingAI ? 'animate-spin' : ''}`} />
                  <span>{isGeneratingAI ? 'Synthesizing AI Image...' : 'Generate AI Image Thumbnail'}</span>
                </button>
              </div>
            )}

            {/* Tab 3: Upload Local File or Custom URL */}
            {thumbnailTab === 'upload' && (
              <div className="flex flex-col gap-4">
                <div className="flex flex-col gap-2">
                  <label className="text-xs font-mono text-on-surface-variant">Upload Image File from Device:</label>
                  <label className="border-2 border-dashed border-white/20 hover:border-primary/50 bg-surface-container p-6 rounded-2xl flex flex-col items-center justify-center gap-2 cursor-pointer transition-all hover:bg-surface-container-high">
                    <Upload className="w-8 h-8 text-primary" />
                    <span className="text-xs font-semibold text-on-surface">Click or Drag & Drop Image File</span>
                    <span className="text-[10px] text-on-surface-variant font-mono">Supports PNG, JPG, WEBP</span>
                    <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                  </label>
                </div>

                <div className="flex flex-col gap-2">
                  <label className="text-xs font-mono text-on-surface-variant">Or Paste Custom Image URL:</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={customUrlInput}
                      onChange={(e) => setCustomUrlInput(e.target.value)}
                      placeholder="https://images.unsplash.com/photo-..."
                      className="bg-surface-container border border-outline-variant rounded-xl px-3.5 py-2 text-xs text-on-surface flex-1 font-mono focus:outline-none focus:border-primary"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (customUrlInput.trim()) {
                          setSelectedCandidateUrl(customUrlInput.trim());
                          showToast('Loaded image from URL!');
                        }
                      }}
                      className="px-4 py-2 bg-surface-container-high border border-white/10 hover:border-primary text-xs font-semibold text-on-surface rounded-xl cursor-pointer"
                    >
                      Load
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Modal Actions Footer */}
            <div className="flex items-center justify-between border-t border-white/10 pt-4 mt-2">
              <button
                onClick={() => setIsThumbnailModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-on-surface-variant hover:text-on-surface cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleApplyThumbnail}
                className="px-6 py-2 bg-primary text-on-primary rounded-xl text-xs font-semibold hover:bg-primary/90 cursor-pointer shadow-md flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Save as Video Thumbnail</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
