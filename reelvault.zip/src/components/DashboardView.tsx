import React, { useMemo } from 'react';
import { Video, Calendar, Diamond, AlertTriangle, RefreshCw, HardDrive, History, ArrowRight, Activity, CheckCircle2, ArrowUpRight, Clock, PlayCircle, Play, RotateCcw, ChevronRight, Eye, Sun, Moon, LayoutDashboard, Sparkles } from 'lucide-react';
import { VaultItem, RatingType, CategoryType, ThemeMode } from '../types';
import { QuickAddPanel } from './QuickAddPanel';

interface DashboardViewProps {
  vaultItems: VaultItem[];
  onProcessVideo: (url: string, rating: RatingType, category?: CategoryType, tags?: string[]) => void;
  onSelectItem: (item: VaultItem) => void;
  onNavigateToLibrary: () => void;
  isProcessing?: boolean;
  recentlyViewedIds?: string[];
  onClearRecentlyViewed?: () => void;
  theme?: ThemeMode;
  onToggleTheme?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  vaultItems,
  onProcessVideo,
  onSelectItem,
  onNavigateToLibrary,
  isProcessing = false,
  recentlyViewedIds,
  onClearRecentlyViewed,
  theme = 'dark',
  onToggleTheme,
}) => {
  const totalVideos = vaultItems.length;
  const highValueCount = vaultItems.filter((i) => i.rating === 'Bahut Kaam Ki' || i.rating === 'Kaam Ki').length;
  const recentItems = vaultItems.slice(0, 4);

  // Resolve last 5 accessed items for quick return-to-work flow
  const resolvedRecentlyViewed: VaultItem[] = useMemo(() => {
    if (!recentlyViewedIds || recentlyViewedIds.length === 0) {
      return vaultItems.slice(0, 5);
    }
    const itemMap = new Map<string, VaultItem>(vaultItems.map((item) => [item.id, item]));
    const matched: VaultItem[] = [];
    for (const rawId of recentlyViewedIds) {
      const id = typeof rawId === 'string' ? rawId : (rawId as unknown as VaultItem).id;
      if (id) {
        const item = itemMap.get(id);
        if (item) {
          matched.push(item);
        }
      }
      if (matched.length >= 5) break;
    }
    if (matched.length < 5) {
      const existingIds = new Set(matched.map((m) => m.id));
      for (const item of vaultItems) {
        if (!existingIds.has(item.id)) {
          matched.push(item);
          if (matched.length >= 5) break;
        }
      }
    }
    return matched;
  }, [recentlyViewedIds, vaultItems]);

  return (
    <div className="flex flex-col gap-6 max-w-7xl mx-auto w-full pb-12">
      {/* Dashboard Top Header Banner with Floating Theme Quick-Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-surface/80 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-5 shadow-xl relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex items-center gap-3 relative z-10">
          <div className="p-3 rounded-2xl bg-gradient-to-tr from-primary/20 via-tertiary/20 to-secondary/20 border border-primary/30 text-primary shadow-inner">
            <LayoutDashboard className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-headline-lg-mobile text-lg sm:text-xl font-bold text-on-surface tracking-tight">
                Executive Dashboard
              </h1>
              <span className="bg-primary/15 text-primary text-[10px] font-mono px-2 py-0.5 rounded-full border border-primary/30 font-bold">
                LIVE VAULT
              </span>
            </div>
            <p className="text-xs text-on-surface-variant font-body-sm mt-0.5">
              Overview, rapid video intake & real-time vault metrics
            </p>
          </div>
        </div>

        {/* Floating Dark/Light Mode Quick-Toggle Switch */}
        {onToggleTheme && (
          <div className="flex items-center gap-3 self-start sm:self-auto shrink-0 bg-surface-container-low/90 border border-white/15 p-1.5 rounded-2xl shadow-lg relative z-10">
            <div className="flex items-center gap-1.5 px-2">
              <Sparkles className="w-3.5 h-3.5 text-tertiary animate-pulse" />
              <span className="text-[11px] font-mono text-on-surface-variant font-semibold hidden md:inline">
                Quick Theme
              </span>
            </div>

            <button
              type="button"
              onClick={onToggleTheme}
              className={`relative flex items-center gap-2.5 px-3.5 py-2 rounded-xl font-mono text-xs font-bold transition-all duration-300 cursor-pointer select-none shadow-md ${
                theme === 'dark'
                  ? 'bg-gradient-to-r from-indigo-950/90 to-purple-950/90 text-indigo-200 border border-indigo-500/40 hover:border-indigo-400'
                  : 'bg-gradient-to-r from-amber-100 to-yellow-100 text-amber-950 border border-amber-300 hover:border-amber-400 shadow-amber-500/10'
              }`}
              title={`Switch theme (Currently ${theme === 'dark' ? 'Dark' : 'Light'} Mode)`}
            >
              <div
                className={`p-1.5 rounded-lg transition-transform duration-300 ${
                  theme === 'dark' ? 'bg-indigo-900/90 text-amber-300' : 'bg-amber-400 text-amber-950'
                }`}
              >
                {theme === 'dark' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
              </div>

              <div className="flex flex-col items-start leading-none">
                <span className="text-[11px] uppercase tracking-wider font-extrabold">
                  {theme === 'dark' ? 'Dark' : 'Light'} Mode
                </span>
                <span className="text-[9px] font-mono opacity-70 mt-0.5">
                  Click to switch
                </span>
              </div>

              {/* Toggle Slider Track */}
              <div
                className={`w-9 h-5 rounded-full p-0.5 transition-colors duration-300 flex items-center ${
                  theme === 'dark' ? 'bg-indigo-600 justify-end' : 'bg-amber-400 justify-start'
                }`}
              >
                <div className="w-4 h-4 rounded-full bg-white shadow-md transform transition-transform duration-300 flex items-center justify-center">
                  {theme === 'dark' ? (
                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-600" />
                  ) : (
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  )}
                </div>
              </div>
            </button>
          </div>
        )}
      </div>

      {/* M2: Quick Add Panel */}
      <QuickAddPanel onProcessVideo={onProcessVideo} isProcessing={isProcessing} />

      {/* M1: Overview Stats (2x2 Grid) */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        {/* Stat 1: Total Videos */}
        <div className="bg-surface/60 backdrop-blur-xl border border-white/10 rounded-xl p-4 flex flex-col gap-1 relative overflow-hidden group shadow-lg">
          <div className="absolute -right-4 -top-4 w-16 h-16 bg-primary/10 rounded-full blur-xl group-hover:bg-primary/20 transition-colors" />
          <span className="font-label-sm text-xs text-on-surface-variant flex items-center gap-1.5">
            <Video className="w-3.5 h-3.5 text-primary" />
            Total Videos
          </span>
          <span className="font-headline-lg-mobile text-2xl md:text-3xl text-on-surface font-bold tracking-tight mt-1">
            {totalVideos.toLocaleString()}
          </span>
        </div>

        {/* Stat 2: This Week */}
        <div className="bg-surface/60 backdrop-blur-xl border border-white/10 rounded-xl p-4 flex flex-col gap-1 relative overflow-hidden group shadow-lg">
          <div className="absolute -right-4 -top-4 w-16 h-16 bg-tertiary/10 rounded-full blur-xl group-hover:bg-tertiary/20 transition-colors" />
          <span className="font-label-sm text-xs text-on-surface-variant flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-tertiary" />
            This Week
          </span>
          <span className="font-headline-lg-mobile text-2xl md:text-3xl text-tertiary font-bold tracking-tight mt-1">
            +42
          </span>
        </div>

        {/* Stat 3: High Value */}
        <div className="bg-surface/60 backdrop-blur-xl border border-white/10 rounded-xl p-4 flex flex-col gap-1 relative overflow-hidden group shadow-lg">
          <div className="absolute -right-4 -top-4 w-16 h-16 bg-secondary/10 rounded-full blur-xl group-hover:bg-secondary/20 transition-colors" />
          <span className="font-label-sm text-xs text-on-surface-variant flex items-center gap-1.5">
            <Diamond className="w-3.5 h-3.5 text-secondary" />
            High Value
          </span>
          <span className="font-headline-lg-mobile text-2xl md:text-3xl text-secondary font-bold tracking-tight mt-1">
            {highValueCount}
          </span>
        </div>

        {/* Stat 4: Failed/Pending */}
        <div className="bg-surface/60 backdrop-blur-xl border border-white/10 rounded-xl p-4 flex flex-col gap-1 relative overflow-hidden group shadow-lg">
          <div className="absolute -right-4 -top-4 w-16 h-16 bg-error/10 rounded-full blur-xl group-hover:bg-error/20 transition-colors" />
          <span className="font-label-sm text-xs text-on-surface-variant flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5 text-error" />
            Failed/Pending
          </span>
          <span className="font-headline-lg-mobile text-2xl md:text-3xl text-error font-bold tracking-tight mt-1">
            0
          </span>
        </div>
      </section>

      {/* Recently Viewed - Return to Work Flow */}
      <section className="bg-surface/70 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-5 flex flex-col gap-4 shadow-xl relative overflow-hidden">
        {/* Glow Accent */}
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-tertiary/10 rounded-full blur-3xl pointer-events-none" />

        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-3.5 relative z-10">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-tertiary/20 to-primary/20 text-tertiary border border-tertiary/30 shadow-xs">
              <Clock className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-label-md text-sm text-on-surface uppercase tracking-wider font-bold">
                  Recently Viewed
                </h3>
                <span className="bg-tertiary/20 text-tertiary px-2 py-0.5 rounded-full text-[10px] font-mono font-semibold border border-tertiary/30 flex items-center gap-1">
                  <PlayCircle className="w-3 h-3 text-tertiary" />
                  RETURN TO WORK
                </span>
              </div>
              <p className="text-xs text-on-surface-variant font-body-sm mt-0.5">
                Quick return-to-work flow for your last 5 accessed videos & research notes
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
            {onClearRecentlyViewed && recentlyViewedIds && recentlyViewedIds.length > 0 && (
              <button
                type="button"
                onClick={onClearRecentlyViewed}
                className="px-2.5 py-1.5 rounded-lg bg-surface-container-high hover:bg-surface-container-highest border border-white/10 text-on-surface-variant hover:text-on-surface text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Clear recently viewed list"
              >
                <RotateCcw className="w-3.5 h-3.5 text-on-surface-variant" />
                <span className="hidden xs:inline">Clear History</span>
              </button>
            )}
            <button
              type="button"
              onClick={onNavigateToLibrary}
              className="px-3 py-1.5 rounded-lg bg-primary/10 hover:bg-primary/20 text-primary border border-primary/20 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
            >
              <span>Vault Library</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 5-Card Return-to-Work Grid */}
        {resolvedRecentlyViewed.length === 0 ? (
          <div className="py-8 flex flex-col items-center justify-center text-center gap-2">
            <Eye className="w-8 h-8 text-on-surface-variant/50" />
            <span className="text-xs text-on-surface-variant font-mono">No recently viewed videos recorded yet.</span>
            <button
              onClick={onNavigateToLibrary}
              className="mt-1 text-xs text-primary underline font-semibold cursor-pointer"
            >
              Browse Library to Start
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 relative z-10">
            {resolvedRecentlyViewed.map((item, index) => {
              const progress = typeof item.watchProgress === 'number' ? item.watchProgress : (45 + (index * 17)) % 100;

              return (
                <div
                  key={item.id}
                  onClick={() => onSelectItem(item)}
                  className="bg-surface-container-low/90 hover:bg-surface-container-high/90 border border-white/10 hover:border-tertiary/50 transition-all duration-200 rounded-xl p-3 flex flex-col justify-between cursor-pointer group shadow-sm hover:shadow-lg hover:-translate-y-0.5 relative overflow-hidden"
                >
                  {/* Thumbnail & Quick Play Overlay */}
                  <div className="aspect-video w-full rounded-lg overflow-hidden relative border border-white/10 bg-surface shrink-0">
                    <img
                      src={item.thumbnailUrl || 'https://picsum.photos/seed/recent/300/180'}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-90 group-hover:opacity-100"
                      referrerPolicy="no-referrer"
                    />

                    {/* Resume Play Hover Overlay */}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-xs">
                      <span className="px-3 py-1.5 rounded-full bg-tertiary text-black text-xs font-bold font-mono shadow-md flex items-center gap-1.5 transform scale-90 group-hover:scale-100 transition-transform">
                        <Play className="w-3.5 h-3.5 fill-current" />
                        Resume
                      </span>
                    </div>

                    {/* Duration badge */}
                    <div className="absolute bottom-1.5 right-1.5 bg-black/80 backdrop-blur-xs px-1.5 py-0.5 rounded text-[10px] font-mono text-white z-10">
                      {item.duration || '10:00'}
                    </div>

                    {/* Return step badge (#1 to #5) */}
                    <div className="absolute top-1.5 left-1.5 bg-black/80 text-tertiary border border-tertiary/40 px-1.5 py-0.5 rounded-md text-[9px] font-mono font-bold z-10">
                      #{index + 1} Recent
                    </div>

                    {/* Watch Progress Bar */}
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/80 overflow-hidden z-10">
                      <div
                        className={`h-full ${progress >= 100 ? 'bg-tertiary' : 'bg-primary'}`}
                        style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
                      />
                    </div>
                  </div>

                  {/* Title & Category Info */}
                  <div className="flex flex-col gap-1.5 mt-2.5 flex-1 justify-between">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center justify-between gap-1 text-[10px] font-mono text-on-surface-variant">
                        <span className="text-primary font-semibold truncate">{item.category}</span>
                        <span className="shrink-0 text-tertiary font-medium">{progress}%</span>
                      </div>

                      <h4 className="font-semibold text-xs text-on-surface line-clamp-2 leading-snug group-hover:text-tertiary transition-colors">
                        {item.title}
                      </h4>
                    </div>

                    {/* Footer return action */}
                    <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-on-surface-variant group-hover:text-on-surface transition-colors mt-1">
                      <span className="text-[10px] text-on-surface-variant/80 truncate">
                        {item.rating}
                      </span>
                      <span className="text-tertiary font-bold flex items-center gap-0.5 text-[10px] group-hover:translate-x-0.5 transition-transform">
                        Return
                        <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* M3: Live Active Operations */}
      <section className="bg-surface/60 backdrop-blur-xl border border-white/10 rounded-xl p-4 flex flex-col gap-3 shadow-lg">
        <h3 className="font-label-md text-xs text-on-surface-variant uppercase tracking-wider flex items-center gap-2 font-semibold">
          <span className="w-2 h-2 rounded-full bg-tertiary animate-pulse shadow-[0_0_8px_rgba(107,222,128,0.8)]" />
          Active Operations
        </h3>
        <div className="bg-surface-container-low rounded-lg p-3.5 border border-white/5 flex flex-col gap-2">
          <div className="flex justify-between items-start">
            <div className="flex gap-2 items-center min-w-0">
              <RefreshCw className="w-4 h-4 text-primary animate-spin shrink-0" />
              <span className="font-body-sm text-sm text-on-surface truncate font-medium">
                UX Audit Masterclass & Component Inspection...
              </span>
            </div>
            <span className="font-label-sm text-xs text-primary font-mono ml-2 font-semibold">68%</span>
          </div>
          <div className="h-1.5 w-full bg-surface-container-highest rounded-full overflow-hidden">
            <div className="h-full bg-primary rounded-full relative transition-all duration-500" style={{ width: '68%' }}>
              <div className="absolute right-0 top-0 bottom-0 w-4 bg-white/50 blur-[2px]" />
            </div>
          </div>
          <div className="flex justify-between items-center mt-0.5">
            <span className="font-label-sm text-[10px] text-on-surface-variant font-mono">Downloading 1080p stream</span>
            <span className="font-label-sm text-[10px] text-on-surface-variant font-mono">2.4 MB/s</span>
          </div>
        </div>
      </section>

      {/* Storage Capacity */}
      <section className="bg-surface/60 backdrop-blur-xl border border-white/10 rounded-xl p-4 md:p-5 flex items-center justify-between shadow-lg">
        <div className="flex flex-col">
          <span className="font-label-sm text-xs text-on-surface-variant uppercase tracking-wider">Storage Capacity</span>
          <span className="font-headline-md text-2xl md:text-3xl text-on-surface font-bold mt-1">
            84% <span className="text-sm font-normal text-on-surface-variant">Used</span>
          </span>
          <span className="font-label-sm text-xs text-on-surface-variant font-mono mt-1">1.8 TB / 2.0 TB</span>
        </div>

        <div className="relative w-16 h-16 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
            <path
              className="text-surface-container-highest"
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              fill="none"
              stroke="currentColor"
              strokeDasharray="100, 100"
              strokeWidth="3.5"
            />
            <path
              className="text-tertiary"
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              fill="none"
              stroke="currentColor"
              strokeDasharray="84, 100"
              strokeWidth="3.5"
            />
          </svg>
          <HardDrive className="absolute w-5 h-5 text-tertiary" />
        </div>
      </section>

      {/* Recent Activity Log Widget */}
      <section className="bg-surface/60 backdrop-blur-xl rounded-xl p-4 md:p-5 border border-white/10 shadow-xl flex flex-col gap-3">
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <Activity className="w-4.5 h-4.5 text-secondary" />
            <h3 className="font-label-md text-xs text-on-surface uppercase tracking-wider font-semibold">
              Recent Activity Log
            </h3>
          </div>
          <span className="text-[11px] font-mono text-on-surface-variant/80 bg-surface-container-high px-2.5 py-1 rounded-full border border-white/5">
            Last 5 Vault Entries
          </span>
        </div>

        <div className="flex flex-col gap-2">
          {vaultItems.slice(0, 5).map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectItem(item)}
              className="flex items-center justify-between p-3 rounded-xl bg-surface-container-low/80 hover:bg-white/5 border border-white/5 hover:border-secondary/30 transition-all cursor-pointer group gap-3"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-lg bg-surface-container-highest overflow-hidden relative shrink-0 border border-white/10">
                  <img src={item.thumbnailUrl} alt={item.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors" />
                  {/* Watch Progress Bar */}
                  {typeof item.watchProgress === 'number' && (
                    <div
                      className="absolute bottom-0 left-0 right-0 h-1 bg-black/80 overflow-hidden z-10"
                      title={`Watch Progress: ${item.watchProgress}%`}
                    >
                      <div
                        className={`h-full ${item.watchProgress >= 100 ? 'bg-tertiary' : 'bg-primary'}`}
                        style={{ width: `${Math.min(100, Math.max(0, item.watchProgress))}%` }}
                      />
                    </div>
                  )}
                </div>

                <div className="flex flex-col min-w-0">
                  <span className="font-body-sm text-sm font-semibold text-on-surface truncate group-hover:text-secondary transition-colors">
                    {item.title}
                  </span>
                  <div className="flex items-center gap-2 text-xs text-on-surface-variant font-mono mt-0.5">
                    <span className="flex items-center gap-1 text-[11px] text-tertiary font-medium">
                      <CheckCircle2 className="w-3 h-3 text-tertiary" />
                      Processed
                    </span>
                    <span>•</span>
                    <span className="text-[11px] text-primary">{item.category}</span>
                    <span>•</span>
                    <span className="text-[11px] text-on-surface-variant">{item.date}</span>
                    {typeof item.watchProgress === 'number' && (
                      <>
                        <span>•</span>
                        <span className="text-[11px] text-secondary font-semibold">
                          {item.watchProgress}% watched
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="hidden sm:inline-flex px-2 py-0.5 rounded text-[10px] font-mono bg-secondary/10 text-secondary border border-secondary/20 font-semibold">
                  {item.rating}
                </span>
                <ArrowUpRight className="w-4 h-4 text-on-surface-variant group-hover:text-secondary group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* M4: Recent Vaults */}
      <section className="bg-surface/60 backdrop-blur-xl rounded-xl overflow-hidden flex flex-col border border-white/10 shadow-xl">
        <div className="p-4 border-b border-white/10 flex justify-between items-center bg-surface-container-low/50">
          <h3 className="font-label-md text-xs text-on-surface uppercase tracking-wider flex items-center gap-2 font-semibold">
            <History className="w-4 h-4 text-primary" />
            Recent Vaults
          </h3>
          <button
            onClick={onNavigateToLibrary}
            className="text-primary font-label-sm text-xs hover:underline flex items-center gap-1 cursor-pointer font-semibold"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="divide-y divide-white/5">
          {recentItems.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectItem(item)}
              className="flex gap-3.5 p-3 sm:p-4 hover:bg-white/5 transition-colors cursor-pointer group items-center"
            >
              {/* Thumbnail */}
              <div className="w-24 sm:w-28 h-16 rounded-lg bg-surface-container-highest overflow-hidden relative flex-shrink-0 border border-white/10">
                <img
                  src={item.thumbnailUrl}
                  alt={item.title}
                  className="w-full h-full object-cover opacity-85 group-hover:opacity-100 group-hover:scale-105 transition-all duration-300"
                />
                <div className="absolute bottom-1.5 right-1 bg-black/80 backdrop-blur-xs px-1.5 py-0.5 rounded text-[10px] font-mono text-white z-10">
                  {item.duration}
                </div>
                {/* Watch Progress Bar */}
                {typeof item.watchProgress === 'number' && (
                  <div
                    className="absolute bottom-0 left-0 right-0 h-1 bg-black/80 overflow-hidden z-10"
                    title={`Watch Progress: ${item.watchProgress}%`}
                  >
                    <div
                      className={`h-full ${item.watchProgress >= 100 ? 'bg-tertiary shadow-[0_0_8px_rgba(107,222,128,0.8)]' : 'bg-primary'}`}
                      style={{ width: `${Math.min(100, Math.max(0, item.watchProgress))}%` }}
                    />
                  </div>
                )}
              </div>

              {/* Title & Metadata */}
              <div className="flex flex-col justify-between flex-grow min-w-0 py-0.5">
                <h4 className="font-body-sm text-sm text-on-surface font-semibold truncate leading-tight group-hover:text-primary transition-colors">
                  {item.title}
                </h4>
                <p className="text-xs text-on-surface-variant/80 line-clamp-1 mt-1 font-body-sm">
                  {item.summary}
                </p>
                <div className="flex flex-wrap gap-1.5 mt-2">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono border ${
                    item.rating === 'Bahut Kaam Ki'
                      ? 'bg-tertiary/15 text-tertiary border-tertiary/30'
                      : item.rating === 'Kaam Ki'
                      ? 'bg-primary/15 text-primary border-primary/30'
                      : 'bg-surface-variant text-on-surface-variant border-outline-variant'
                  }`}>
                    {item.rating}
                  </span>
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono bg-surface-variant/80 text-on-surface-variant border border-outline-variant">
                    {item.category}
                  </span>
                  {typeof item.watchProgress === 'number' && (
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono border ${
                      item.watchProgress >= 100
                        ? 'bg-tertiary/20 text-tertiary border-tertiary/40 font-semibold'
                        : 'bg-primary/10 text-primary border-primary/20'
                    }`}>
                      {item.watchProgress}% watched
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
