import React, { useState, useRef, useEffect } from 'react';
import { Download, Bell, Settings, Moon, Sun, WifiOff, Search, X, Tag, Folder, ArrowRight, Video, Command, Keyboard } from 'lucide-react';
import { ThemeMode, VaultItem } from '../types';

interface HeaderProps {
  vaultItems?: VaultItem[];
  onSelectItem?: (item: VaultItem) => void;
  onNavigateToLibrary?: () => void;
  onExportCSV: () => void;
  onOpenSettings: () => void;
  onOpenNotifications: () => void;
  onOpenShortcuts?: () => void;
  theme: ThemeMode;
  onToggleTheme: () => void;
  isOffline: boolean;
  unreadNotificationsCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  vaultItems = [],
  onSelectItem,
  onNavigateToLibrary,
  onExportCSV,
  onOpenSettings,
  onOpenNotifications,
  onOpenShortcuts,
  theme,
  onToggleTheme,
  isOffline,
  unreadNotificationsCount = 2,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Keyboard shortcut Ctrl+K or / to focus search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.key === '/' || (e.key === 'k' && (e.metaKey || e.ctrlKey))) && document.activeElement !== inputRef.current) {
        e.preventDefault();
        inputRef.current?.focus();
        setIsOpen(true);
      } else if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Real-time filtering matching title, category, or tags
  const queryTrim = searchQuery.trim().toLowerCase();
  const matchingItems = queryTrim
    ? vaultItems.filter((item) => {
        const titleMatch = item.title.toLowerCase().includes(queryTrim);
        const categoryMatch = item.category.toLowerCase().includes(queryTrim);
        const tagsMatch = item.tags.some((tag) => tag.toLowerCase().includes(queryTrim));
        const remarksMatch = item.remarks?.toLowerCase().includes(queryTrim);
        return titleMatch || categoryMatch || tagsMatch || remarksMatch;
      })
    : [];

  // Helper function to highlight matching text substrings
  const highlightMatch = (text: string, query: string) => {
    if (!query.trim() || !text) return text;
    const esc = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${esc})`, 'gi');
    const parts = text.split(regex);
    return (
      <>
        {parts.map((part, i) =>
          regex.test(part) ? (
            <mark key={i} className="bg-primary/30 text-primary font-bold px-0.5 rounded border-b border-primary/50">
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </>
    );
  };

  return (
    <header className="bg-surface/80 dark:bg-surface/80 backdrop-blur-xl border-b border-white/10 shadow-xl fixed top-0 w-full z-50 flex justify-between items-center px-3 sm:px-6 md:px-8 py-2.5 gap-2 sm:gap-4">
      {/* Brand & Offline Indicator */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        <div className="flex items-center gap-2">
          <span className="font-headline-lg-mobile text-xl sm:text-2xl font-black tracking-tighter text-primary uppercase">
            REELVAULT
          </span>
          <span className="hidden lg:inline-block font-label-sm text-[10px] text-primary/80 bg-primary/10 border border-primary/20 px-2 py-0.5 rounded-full">
            v2.4
          </span>
        </div>

        {isOffline && (
          <div className="flex items-center gap-1.5 bg-amber-500/15 border border-amber-500/30 text-amber-400 px-2.5 py-1 rounded-full text-xs font-medium animate-pulse">
            <WifiOff className="w-3.5 h-3.5" />
            <span className="hidden xl:inline">Offline Mode</span>
          </div>
        )}
      </div>

      {/* Global Search Bar */}
      <div ref={searchRef} className="relative flex-1 max-w-sm lg:max-w-md mx-2">
        <div className="relative flex items-center">
          <Search className="w-4 h-4 absolute left-3 text-on-surface-variant pointer-events-none" />
          <input
            ref={inputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setIsOpen(true);
            }}
            onFocus={() => setIsOpen(true)}
            placeholder="Global Search (title, tags, category)..."
            className="w-full bg-surface-container-low/90 border border-white/10 focus:border-primary/60 rounded-xl pl-9 pr-8 py-1.5 text-xs sm:text-sm text-on-surface placeholder:text-on-surface-variant/60 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all shadow-inner"
          />
          {searchQuery ? (
            <button
              onClick={() => {
                setSearchQuery('');
                setIsOpen(false);
              }}
              className="absolute right-2.5 text-on-surface-variant hover:text-on-surface p-0.5 rounded-full cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          ) : (
            <div className="hidden sm:flex items-center gap-1 absolute right-2 pointer-events-none">
              <kbd className="text-[10px] font-mono text-tertiary font-bold bg-tertiary/10 px-1.5 py-0.5 rounded border border-tertiary/20 shadow-xs">
                ⌘K
              </kbd>
            </div>
          )}
        </div>

        {/* Global Search Filtered Results Popover */}
        {isOpen && searchQuery.trim().length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-surface-container-high/95 backdrop-blur-2xl border border-white/15 rounded-2xl shadow-2xl z-50 max-h-96 overflow-y-auto p-2 flex flex-col gap-2">
            <div className="flex items-center justify-between px-2 py-1.5 border-b border-white/10 text-xs">
              <span className="text-on-surface-variant font-mono">
                Matching Results ({matchingItems.length})
              </span>
              <span className="text-[10px] text-primary bg-primary/10 px-2 py-0.5 rounded-full border border-primary/20 font-mono">
                Real-Time Filter
              </span>
            </div>

            {matchingItems.length === 0 ? (
              <div className="p-6 text-center text-xs text-on-surface-variant flex flex-col items-center gap-2">
                <Video className="w-8 h-8 opacity-40 text-on-surface-variant" />
                <span>No vault entries found matching "{searchQuery}"</span>
              </div>
            ) : (
              <div className="flex flex-col gap-1.5">
                {matchingItems.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => {
                      if (onSelectItem) onSelectItem(item);
                      setIsOpen(false);
                    }}
                    className="p-2.5 rounded-xl bg-surface-container-low/70 hover:bg-white/10 border border-white/5 hover:border-primary/40 transition-all cursor-pointer flex items-center justify-between gap-3 group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-12 h-8 rounded bg-surface-container-highest overflow-hidden shrink-0 border border-white/10 relative">
                        <img src={item.thumbnailUrl} alt={item.title} className="w-full h-full object-cover" />
                        {typeof item.watchProgress === 'number' && (
                          <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/80">
                            <div
                              className={`h-full ${item.watchProgress >= 100 ? 'bg-tertiary' : 'bg-primary'}`}
                              style={{ width: `${item.watchProgress}%` }}
                            />
                          </div>
                        )}
                      </div>

                      <div className="flex flex-col min-w-0">
                        <span className="text-xs font-semibold text-on-surface truncate group-hover:text-primary transition-colors">
                          {highlightMatch(item.title, searchQuery)}
                        </span>
                        <div className="flex items-center gap-2 text-[11px] text-on-surface-variant mt-0.5 font-mono">
                          <span className="flex items-center gap-1 text-secondary">
                            <Folder className="w-3 h-3" />
                            {highlightMatch(item.category, searchQuery)}
                          </span>
                          <span>•</span>
                          <span className="truncate max-w-[140px] text-on-surface-variant/80">
                            {item.tags.map((tag, idx) => (
                              <span key={idx} className="mr-1">
                                #{highlightMatch(tag, searchQuery)}
                              </span>
                            ))}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center gap-1">
                      <span className="text-[10px] font-mono text-tertiary bg-tertiary/10 px-1.5 py-0.5 rounded border border-tertiary/20">
                        {item.rating}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5 text-on-surface-variant group-hover:text-primary transition-transform group-hover:translate-x-0.5" />
                    </div>
                  </div>
                ))}

                {onNavigateToLibrary && (
                  <button
                    onClick={() => {
                      onNavigateToLibrary();
                      setIsOpen(false);
                    }}
                    className="mt-1 w-full text-center text-xs text-primary font-semibold py-2 rounded-xl bg-primary/10 hover:bg-primary/20 border border-primary/20 transition-all flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <span>View all matching results in Library</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Action Controls */}
      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
        {/* Excel Download Button */}
        <button
          onClick={onExportCSV}
          title="Export Vault to Excel CSV"
          className="bg-secondary-container hover:bg-secondary-container/90 text-on-secondary-container font-label-md text-xs sm:text-sm px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-lg flex items-center gap-1.5 transition-all active:scale-95 duration-200 shadow-[0_0_15px_rgba(88,28,180,0.4)] border border-white/10 cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span className="hidden sm:inline font-semibold">Excel Download</span>
        </button>

        {/* Theme Toggle Button */}
        <button
          onClick={onToggleTheme}
          title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} Mode`}
          className="p-1.5 sm:p-2 text-on-surface-variant hover:bg-white/10 hover:text-on-surface transition-colors rounded-full active:scale-95 duration-200 cursor-pointer"
        >
          {theme === 'dark' ? <Sun className="w-4 h-4 sm:w-5 sm:h-5 text-amber-300" /> : <Moon className="w-4 h-4 sm:w-5 sm:h-5 text-indigo-400" />}
        </button>

        {/* Notifications Button */}
        <button
          onClick={onOpenNotifications}
          title="Notifications"
          className="p-1.5 sm:p-2 text-on-surface-variant hover:bg-white/10 hover:text-on-surface transition-colors rounded-full active:scale-95 duration-200 relative cursor-pointer"
        >
          <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
          {unreadNotificationsCount > 0 && (
            <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-tertiary rounded-full ring-2 ring-background animate-pulse" />
          )}
        </button>

        {/* Keyboard Shortcuts Cheatsheet Button */}
        {onOpenShortcuts && (
          <button
            onClick={onOpenShortcuts}
            title="Keyboard Shortcuts Cheat Sheet (Press ? or ⌘/)"
            className="p-1.5 sm:p-2 text-on-surface-variant hover:bg-white/10 hover:text-tertiary transition-colors rounded-full active:scale-95 duration-200 cursor-pointer relative group"
          >
            <Keyboard className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="absolute top-full right-0 mt-1 hidden group-hover:flex items-center gap-1 px-2 py-1 rounded-md bg-black/90 text-[10px] font-mono text-tertiary border border-white/15 whitespace-nowrap z-50 shadow-xl">
              <span>Shortcuts</span>
              <kbd className="bg-white/10 px-1 rounded">?</kbd>
            </span>
          </button>
        )}

        {/* Settings Button */}
        <button
          onClick={onOpenSettings}
          title="Settings & Storage"
          className="p-1.5 sm:p-2 text-on-surface-variant hover:bg-white/10 hover:text-on-surface transition-colors rounded-full active:scale-95 duration-200 cursor-pointer"
        >
          <Settings className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>

        {/* User Profile Avatar */}
        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-surface-variant overflow-hidden border border-white/20 flex-shrink-0 ml-0.5">
          <img
            alt="User profile"
            className="w-full h-full object-cover"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuDRwO1frrvm1Oj7H8dXJpWrzAs4KYyj0v-eazixuqRe6TzR4iw2IKrvOe7Pufu2xDnzm41LoDoFNk2WQ5w4vZO75QtTEGYVzAp4EgL9wbppxvZeI_CXAHf-mT_1aXOSz6ifajpghb49F-3zhaLZ1DbYaI4f1h1dKtMq0ddGLrAMzOF7ouJjOYEhdTTuKa6MSc8vjauvbOyMLxhF_4uJlloZv28qn8ubmhjEjNyrWlMtLpsiAM__peTK6g"
          />
        </div>
      </div>
    </header>
  );
};

