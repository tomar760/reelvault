import React from 'react';
import { LayoutDashboard, Film, BarChart3, GitFork, Plus } from 'lucide-react';
import { NavigationTab } from '../types';

interface BottomNavProps {
  activeTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  onOpenQuickAdd: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
  onOpenQuickAdd,
}) => {
  const tabs = [
    { id: 'dashboard' as NavigationTab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'library' as NavigationTab, label: 'Library', icon: Film },
    { id: 'analytics' as NavigationTab, label: 'Analytics', icon: BarChart3 },
    { id: 'workflows' as NavigationTab, label: 'Workflows', icon: GitFork },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 w-full bg-surface-container dark:bg-surface-container border-t border-white/10 shadow-[0_-10px_40px_rgba(0,0,0,0.5)] z-40 pb-safe">
      <div className="flex justify-around items-center h-16 px-2 relative">
        {tabs.map((tab, idx) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          // Insert Quick Add floating action button between Library and Analytics on mobile if desired
          return (
            <React.Fragment key={tab.id}>
              {idx === 2 && (
                <div className="relative -top-4">
                  <button
                    onClick={onOpenQuickAdd}
                    className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-on-primary shadow-[0_0_20px_rgba(173,198,255,0.4)] border-2 border-surface active:scale-95 duration-200 transition-transform cursor-pointer"
                    title="Quick Add Video"
                  >
                    <Plus className="w-6 h-6" />
                  </button>
                </div>
              )}

              <button
                onClick={() => onTabChange(tab.id)}
                className={`flex flex-col items-center justify-center gap-1 p-1.5 rounded-lg active:scale-95 transition-all w-16 cursor-pointer ${
                  isActive
                    ? 'bg-secondary-container text-on-secondary-container font-bold shadow-[0_0_12px_rgba(88,28,180,0.4)]'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-label-sm text-[10px] tracking-tight">{tab.label}</span>
              </button>
            </React.Fragment>
          );
        })}
      </div>
    </nav>
  );
};
