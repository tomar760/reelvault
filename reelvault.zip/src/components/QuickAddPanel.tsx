import React, { useState, useEffect, useRef } from 'react';
import { PlusCircle, Clipboard, Star, ThumbsUp, Minus, Rocket, Sparkles, Tag, Folder, X, RefreshCw, Wand2 } from 'lucide-react';
import { RatingType, CategoryType, AISuggestionResult } from '../types';

interface QuickAddPanelProps {
  onProcessVideo: (url: string, rating: RatingType, category?: CategoryType, tags?: string[]) => void;
  isProcessing?: boolean;
}

const CATEGORY_OPTIONS: CategoryType[] = [
  'UI/UX',
  'Backend',
  'AI/ML',
  'Frontend',
  'DevOps',
  'System Design',
  'Tech Tips',
  'Tutorials',
  'Inspiration',
  'General',
];

export const QuickAddPanel: React.FC<QuickAddPanelProps> = ({
  onProcessVideo,
  isProcessing = false,
}) => {
  const [url, setUrl] = useState('');
  const [rating, setRating] = useState<RatingType>('Kaam Ki');
  
  // Gemini AI Category & Tags auto-suggestion states
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState<AISuggestionResult | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('Tech Tips');
  const [tags, setTags] = useState<string[]>([]);
  const [newTagInput, setNewTagInput] = useState('');
  const [hasUserEditedCategory, setHasUserEditedCategory] = useState(false);

  const debounceTimeout = useRef<NodeJS.Timeout | null>(null);

  // Auto-trigger Gemini AI suggestion when URL changes and looks like a valid link
  useEffect(() => {
    if (debounceTimeout.current) {
      clearTimeout(debounceTimeout.current);
    }

    const trimmed = url.trim();
    if (!trimmed || (!trimmed.startsWith('http://') && !trimmed.startsWith('https://') && trimmed.length < 8)) {
      setAiSuggestion(null);
      setIsSuggesting(false);
      return;
    }

    setIsSuggesting(true);
    debounceTimeout.current = setTimeout(async () => {
      try {
        const res = await fetch('/api/suggest-category-tags', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: trimmed }),
        });

        if (res.ok) {
          const data: AISuggestionResult = await res.json();
          setAiSuggestion(data);
          if (!hasUserEditedCategory && data.category) {
            setSelectedCategory(data.category);
          }
          if (data.tags && data.tags.length > 0) {
            setTags(data.tags);
          }
        }
      } catch (err) {
        console.error('Failed to fetch Gemini AI suggestions:', err);
      } finally {
        setIsSuggesting(false);
      }
    }, 600);

    return () => {
      if (debounceTimeout.current) clearTimeout(debounceTimeout.current);
    };
  }, [url]);

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setUrl(text);
      }
    } catch (e) {
      console.log('Clipboard permission not granted or available', e);
    }
  };

  const handleManualSuggestTrigger = async () => {
    if (!url.trim()) return;
    setIsSuggesting(true);
    try {
      const res = await fetch('/api/suggest-category-tags', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: url.trim() }),
      });
      if (res.ok) {
        const data: AISuggestionResult = await res.json();
        setAiSuggestion(data);
        if (data.category) setSelectedCategory(data.category);
        if (data.tags) setTags(data.tags);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSuggesting(false);
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags((prev) => prev.filter((t) => t !== tagToRemove));
  };

  const handleAddTag = (e: React.KeyboardEvent | React.MouseEvent) => {
    if ('key' in e && e.key !== 'Enter') return;
    e.preventDefault();
    const trimmed = newTagInput.trim();
    if (trimmed && !tags.includes(trimmed)) {
      setTags((prev) => [...prev, trimmed]);
      setNewTagInput('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;
    onProcessVideo(url.trim(), rating, selectedCategory, tags);
  };

  return (
    <section className="bg-surface/60 backdrop-blur-xl border border-white/10 rounded-xl p-4 md:p-6 flex flex-col gap-4 relative overflow-hidden group shadow-xl">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-secondary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
      
      {/* Header */}
      <div className="flex justify-between items-center z-10">
        <h2 className="font-headline-md text-lg md:text-xl text-on-surface flex items-center gap-2 font-semibold">
          <PlusCircle className="w-5 h-5 text-primary" />
          Quick Add
        </h2>
        <div className="flex items-center gap-2">
          <span className="font-label-sm text-xs text-secondary bg-secondary-container/20 border border-secondary/30 px-2.5 py-1 rounded-full flex items-center gap-1.5 font-medium">
            <Sparkles className="w-3.5 h-3.5 text-secondary animate-pulse" />
            Gemini AI Auto-Classification
          </span>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="flex flex-col gap-3.5 z-10">
        {/* Input Field */}
        <div className="relative">
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Paste video URL (YouTube, Vimeo, Figma, Loom, etc.)..."
            className="w-full bg-surface-container-highest border border-outline-variant focus:border-primary focus:ring-1 focus:ring-primary rounded-lg px-4 py-3 font-label-md text-sm text-on-surface placeholder:text-on-surface-variant/50 transition-all shadow-inner outline-none pr-12"
            required
          />
          <button
            type="button"
            onClick={handlePaste}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-on-surface-variant hover:text-primary transition-colors cursor-pointer rounded-lg hover:bg-white/5"
            title="Paste from Clipboard"
          >
            <Clipboard className="w-4 h-4" />
          </button>
        </div>

        {/* Gemini AI Suggestions Live Container */}
        {(isSuggesting || aiSuggestion || url.trim().length > 8) && (
          <div className="bg-surface-container-low/90 border border-secondary/20 rounded-xl p-3.5 flex flex-col gap-3 transition-all animate-fadeIn shadow-inner">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-secondary flex items-center gap-1.5 uppercase tracking-wider font-mono">
                <Wand2 className="w-3.5 h-3.5 text-secondary" />
                Gemini AI Suggestions
              </span>
              {isSuggesting ? (
                <span className="text-[11px] text-primary flex items-center gap-1 font-mono">
                  <RefreshCw className="w-3 h-3 animate-spin" />
                  Analyzing URL Content...
                </span>
              ) : (
                <button
                  type="button"
                  onClick={handleManualSuggestTrigger}
                  className="text-[11px] text-on-surface-variant hover:text-secondary flex items-center gap-1 font-mono cursor-pointer transition-colors"
                >
                  <RefreshCw className="w-3 h-3" />
                  Re-analyze
                </button>
              )}
            </div>

            {/* AI Suggested Category Selection */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-on-surface-variant flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <Folder className="w-3.5 h-3.5 text-primary" /> Auto-Suggested Category
                </span>
                {aiSuggestion?.category && (
                  <span className="text-[10px] text-tertiary bg-tertiary/10 border border-tertiary/20 px-1.5 py-0.5 rounded font-mono">
                    Gemini Matched: {aiSuggestion.category}
                  </span>
                )}
              </label>
              <div className="flex flex-wrap gap-1.5">
                {CATEGORY_OPTIONS.map((cat) => {
                  const isSelected = selectedCategory === cat;
                  const isAiRecommended = aiSuggestion?.category === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => {
                        setSelectedCategory(cat);
                        setHasUserEditedCategory(true);
                      }}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer border flex items-center gap-1 ${
                        isSelected
                          ? 'bg-primary text-on-primary border-primary font-bold shadow-sm'
                          : isAiRecommended
                          ? 'bg-secondary/20 text-secondary border-secondary/40 font-semibold'
                          : 'bg-surface-container border-outline-variant hover:border-white/20 text-on-surface-variant'
                      }`}
                    >
                      {isAiRecommended && <Sparkles className="w-3 h-3 text-secondary" />}
                      <span>{cat}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* AI Suggested Tags */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-on-surface-variant flex items-center gap-1">
                <Tag className="w-3.5 h-3.5 text-secondary" /> Auto-Suggested Tags
              </label>
              <div className="flex flex-wrap items-center gap-1.5 bg-surface-container-highest/60 p-2 rounded-lg border border-outline-variant/60">
                {tags.map((t) => (
                  <span
                    key={t}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-mono bg-secondary/15 text-secondary border border-secondary/30 shadow-xs"
                  >
                    #{t}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(t)}
                      className="hover:text-error transition-colors cursor-pointer ml-0.5"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
                
                {/* Input for adding custom tag */}
                <input
                  type="text"
                  value={newTagInput}
                  onChange={(e) => setNewTagInput(e.target.value)}
                  onKeyDown={handleAddTag}
                  placeholder="+ Add tag..."
                  className="bg-transparent text-xs font-mono text-on-surface placeholder:text-on-surface-variant/40 outline-none px-2 py-0.5 min-w-[80px]"
                />
              </div>
            </div>

            {/* Gemini AI Reasoning */}
            {aiSuggestion?.reasoning && (
              <p className="text-[11px] text-on-surface-variant/80 italic font-mono flex items-start gap-1">
                <Sparkles className="w-3 h-3 text-secondary shrink-0 mt-0.5" />
                <span>{aiSuggestion.reasoning}</span>
              </p>
            )}
          </div>
        )}

        {/* Rating selection buttons */}
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => setRating('Bahut Kaam Ki')}
            className={`py-2 rounded-lg transition-all active:scale-95 flex flex-col items-center gap-1 cursor-pointer font-label-sm text-xs border ${
              rating === 'Bahut Kaam Ki'
                ? 'bg-tertiary-container/30 border-tertiary text-tertiary font-bold shadow-[0_0_10px_rgba(107,222,128,0.2)]'
                : 'bg-surface-container border-outline-variant hover:border-tertiary/50 text-on-surface'
            }`}
          >
            <Star className={`w-4 h-4 ${rating === 'Bahut Kaam Ki' ? 'fill-tertiary text-tertiary' : 'text-tertiary'}`} />
            <span>Bahut Kaam Ki</span>
          </button>

          <button
            type="button"
            onClick={() => setRating('Kaam Ki')}
            className={`py-2 rounded-lg transition-all active:scale-95 flex flex-col items-center gap-1 cursor-pointer font-label-sm text-xs border ${
              rating === 'Kaam Ki'
                ? 'bg-primary-container/30 border-primary text-primary font-bold shadow-[0_0_10px_rgba(173,198,255,0.2)]'
                : 'bg-surface-container border-outline-variant hover:border-primary/50 text-on-surface'
            }`}
          >
            <ThumbsUp className={`w-4 h-4 ${rating === 'Kaam Ki' ? 'fill-primary text-primary' : 'text-primary'}`} />
            <span>Kaam Ki</span>
          </button>

          <button
            type="button"
            onClick={() => setRating('Theek-Thaak')}
            className={`py-2 rounded-lg transition-all active:scale-95 flex flex-col items-center gap-1 cursor-pointer font-label-sm text-xs border text-center ${
              rating === 'Theek-Thaak'
                ? 'bg-surface-variant/80 border-outline text-on-surface font-bold'
                : 'bg-surface-container border-outline-variant hover:border-outline text-on-surface-variant'
            }`}
          >
            <Minus className="w-4 h-4 text-on-surface-variant" />
            <span>Theek-Thaak</span>
          </button>
        </div>

        {/* Process CTA Button */}
        <button
          type="submit"
          disabled={isProcessing || !url.trim()}
          className="w-full bg-primary text-on-primary font-semibold text-sm py-3 rounded-lg flex items-center justify-center gap-2 hover:bg-primary/90 transition-all shadow-[0_4px_15px_rgba(173,198,255,0.2)] active:scale-95 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed mt-1"
        >
          <Rocket className="w-4 h-4 fill-on-primary" />
          <span>{isProcessing ? 'Processing with Gemini AI...' : 'Process & Save Video'}</span>
        </button>
      </form>
    </section>
  );
};

