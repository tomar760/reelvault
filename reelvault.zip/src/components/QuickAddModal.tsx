import React from 'react';
import { Sparkles, RefreshCw, CheckCircle, Video } from 'lucide-react';
import { VaultItem } from '../types';

interface QuickAddModalProps {
  isOpen: boolean;
  isProcessing: boolean;
  processedItem: VaultItem | null;
  onConfirmAdd: () => void;
  onCancel: () => void;
}

export const QuickAddModal: React.FC<QuickAddModalProps> = ({
  isOpen,
  isProcessing,
  processedItem,
  onConfirmAdd,
  onCancel,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xl flex items-center justify-center p-4">
      <div className="bg-surface-container border border-white/15 rounded-2xl p-6 max-w-lg w-full shadow-2xl flex flex-col gap-5 relative overflow-hidden">
        {/* Top Glow Bar */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-secondary to-tertiary" />

        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-tertiary animate-pulse" />
            <h2 className="font-headline-md text-lg font-bold text-on-surface">
              {isProcessing ? 'Gemini AI Processing Video' : 'AI Analysis Ready'}
            </h2>
          </div>
          {!isProcessing && (
            <button onClick={onCancel} className="text-on-surface-variant hover:text-on-surface cursor-pointer text-lg font-bold">
              ×
            </button>
          )}
        </div>

        {isProcessing ? (
          <div className="flex flex-col items-center justify-center py-10 gap-4">
            <div className="relative">
              <div className="w-16 h-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
              <Video className="w-6 h-6 text-primary absolute inset-0 m-auto" />
            </div>
            <div className="text-center flex flex-col gap-1">
              <p className="font-semibold text-sm text-on-surface">Parsing Content & Audio Stream...</p>
              <p className="text-xs text-on-surface-variant font-mono">Extracting key takeaways, summary, tags & links</p>
            </div>
          </div>
        ) : processedItem ? (
          <div className="flex flex-col gap-4">
            <div className="flex gap-3 bg-surface-container-low p-3 rounded-xl border border-white/5">
              <img
                src={processedItem.thumbnailUrl}
                alt={processedItem.title}
                className="w-24 aspect-video rounded-lg object-cover shrink-0 border border-white/10"
              />
              <div className="flex flex-col justify-center min-w-0">
                <h4 className="font-semibold text-sm text-on-surface line-clamp-1">{processedItem.title}</h4>
                <div className="flex flex-wrap items-center gap-1.5 mt-1 font-mono text-[10px]">
                  <span className="px-2 py-0.5 rounded bg-tertiary/20 text-tertiary font-semibold">{processedItem.rating}</span>
                  <span className="px-2 py-0.5 rounded bg-primary/20 text-primary border border-primary/30 flex items-center gap-1">
                    <Sparkles className="w-2.5 h-2.5 text-primary" />
                    {processedItem.category}
                  </span>
                </div>
              </div>
            </div>

            {/* AI Auto-Suggested Category & Tags Preview */}
            <div className="bg-surface-container-low/80 p-3.5 rounded-xl border border-secondary/20 flex flex-col gap-2">
              <span className="text-[11px] font-semibold text-secondary flex items-center gap-1 uppercase tracking-wider font-mono">
                <Sparkles className="w-3 h-3 text-secondary" /> Gemini AI Auto-Classified Category & Tags
              </span>
              <div className="flex flex-wrap items-center gap-1.5 mt-1">
                <span className="px-2.5 py-1 rounded-md text-xs font-semibold bg-primary/15 text-primary border border-primary/30 font-mono">
                  Category: {processedItem.category}
                </span>
                {processedItem.tags?.map((tag) => (
                  <span key={tag} className="px-2 py-0.5 rounded-md text-[11px] font-mono bg-secondary/15 text-secondary border border-secondary/30">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-1.5 bg-surface-container-low p-3.5 rounded-xl border border-white/5 text-xs">
              <span className="font-semibold text-on-surface flex items-center gap-1.5 text-tertiary">
                <CheckCircle className="w-3.5 h-3.5" /> Key Takeaway
              </span>
              <p className="text-on-surface-variant line-clamp-2">{processedItem.keyTakeaways[0]}</p>
            </div>

            <div className="flex justify-end gap-2 mt-2">
              <button
                onClick={onCancel}
                className="px-4 py-2 text-xs font-semibold text-on-surface-variant hover:text-on-surface cursor-pointer"
              >
                Discard
              </button>
              <button
                onClick={onConfirmAdd}
                className="bg-primary text-on-primary font-semibold text-xs px-5 py-2.5 rounded-xl hover:bg-primary/90 shadow-lg active:scale-95 cursor-pointer"
              >
                Save to Vault
              </button>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
};
