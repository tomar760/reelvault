import React from 'react';
import { LayoutDashboard, Film, BarChart3, GitFork, Plus, Terminal, HelpCircle, Flame } from 'lucide-react';
import { NavigationTab } from '../types';

interface SidebarProps {
  activeTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  onOpenQuickAdd: () => void;
  vaultCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  onOpenQuickAdd,
  vaultCount,
}) => {
  const navItems = [
    { id: 'dashboard' as NavigationTab, label: 'Dashboard', icon: LayoutDashboard, shortcut: '⌘1' },
    { id: 'library' as NavigationTab, label: 'Library', icon: Film, badge: vaultCount, shortcut: '⌘2' },
    { id: 'analytics' as NavigationTab, label: 'Analytics', icon: BarChart3, shortcut: '⌘3' },
    { id: 'workflows' as NavigationTab, label: 'Workflows', icon: GitFork, shortcut: '⌘4' },
  ];

  return (
    <aside className="hidden md:flex flex-col h-full p-4 gap-2 bg-surface-container dark:bg-surface-container border-r border-white/10 shadow-2xl fixed left-0 top-0 h-full w-64 z-40 pt-20">
      {/* Brand Header */}
      <div className="mb-4 px-3">
        <div className="flex items-center gap-2">
          <h2 className="font-headline-md text-xl font-bold text-primary">ReelVault</h2>
          <span className="flex items-center gap-1 text-[10px] font-mono text-tertiary bg-tertiary/10 border border-tertiary/20 px-1.5 py-0.5 rounded">
            <Flame className="w-3 h-3" /> SECURE
          </span>
        </div>
        <p className="font-label-sm text-xs text-on-surface-variant opacity-70">
          Iron Silk Security
        </p>
      </div>

      {/* Quick Add CTA */}
      <button
        onClick={onOpenQuickAdd}
        title="Quick Add Link (Press ⌘N)"
        className="mb-4 bg-primary text-on-primary font-label-md text-sm font-semibold py-2.5 px-4 rounded-lg flex items-center justify-between gap-2 hover:bg-primary/90 transition-all shadow-lg active:scale-95 cursor-pointer group"
      >
        <div className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          <span>Quick Add Link</span>
        </div>
        <kbd className="text-[10px] font-mono font-bold bg-black/30 text-white/90 px-1.5 py-0.5 rounded border border-white/20">
          ⌘N
        </kbd>
      </button>

      {/* Main Navigation Links */}
      <nav className="flex-grow flex flex-col gap-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full text-left rounded-lg font-medium flex items-center justify-between px-3 py-2.5 transition-all duration-200 cursor-pointer ${
                isActive
                  ? 'bg-secondary-container text-on-secondary-container font-bold shadow-[0_0_15px_rgba(88,28,180,0.3)]'
                  : 'text-on-surface-variant hover:text-on-surface hover:bg-surface-variant/50 hover:translate-x-1'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className="w-5 h-5" />
                <span className="font-label-md text-sm">{item.label}</span>
              </div>
              <div className="flex items-center gap-1.5">
                {item.badge !== undefined && (
                  <span className={`text-xs px-2 py-0.5 rounded-full font-mono ${
                    isActive ? 'bg-white/20 text-white' : 'bg-surface-variant text-on-surface-variant'
                  }`}>
                    {item.badge}
                  </span>
                )}
                <span className="text-[10px] font-mono opacity-50 font-semibold hidden lg:inline">
                  {item.shortcut}
                </span>
              </div>
            </button>
          );
        })}
      </nav>

      {/* Footer System Links */}
      <div className="mt-auto flex flex-col gap-1 border-t border-white/10 pt-4">
        <button
          onClick={() => alert('System Engine: Version 2.4.1 (Clean Build). Storage Encryption Active.')}
          className="w-full text-left text-on-surface-variant hover:text-on-surface hover:bg-surface-variant/50 transition-all hover:translate-x-1 duration-200 rounded-lg flex items-center gap-3 px-3 py-2 text-xs font-mono cursor-pointer"
        >
          <Terminal className="w-4 h-4" />
          <span>System Info</span>
        </button>
        <button
          onClick={() => alert('ReelVault Help & Support: Contact user settings for documentation.')}
          className="w-full text-left text-on-surface-variant hover:text-on-surface hover:bg-surface-variant/50 transition-all hover:translate-x-1 duration-200 rounded-lg flex items-center gap-3 px-3 py-2 text-xs font-mono cursor-pointer"
        >
          <HelpCircle className="w-4 h-4" />
          <span>Support & Docs</span>
        </button>
      </div>
    </aside>
  );
};
