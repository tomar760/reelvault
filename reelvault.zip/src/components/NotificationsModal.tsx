import React from 'react';
import { Bell, Sparkles, CheckCircle2, Download, Clock } from 'lucide-react';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const notifications = [
    {
      id: '1',
      title: 'AI Meta-Tagging Pipeline Complete',
      time: '12 mins ago',
      desc: 'Parsed "Advanced Figma Prototyping Tricks 2024" with 3 key takeaways.',
      type: 'ai',
    },
    {
      id: '2',
      title: 'Excel Backup Sheet Ready',
      time: '1 hour ago',
      desc: 'ReelVault_Export.csv generated and stored in offline cache.',
      type: 'export',
    },
    {
      id: '3',
      title: 'Offline Storage Synced',
      time: '3 hours ago',
      desc: '1,204 video entries updated in local IndexedDB vault cache.',
      type: 'sync',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xl flex items-center justify-center p-4">
      <div className="bg-surface-container border border-white/15 rounded-2xl p-6 max-w-md w-full shadow-2xl flex flex-col gap-4">
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-primary" />
            <h2 className="font-headline-md text-lg font-bold text-on-surface">Recent Activity</h2>
          </div>
          <button onClick={onClose} className="text-on-surface-variant hover:text-on-surface text-xl font-bold cursor-pointer">
            ×
          </button>
        </div>

        <div className="flex flex-col gap-3 max-h-[60vh] overflow-y-auto">
          {notifications.map((n) => (
            <div key={n.id} className="bg-surface-container-low p-3.5 rounded-xl border border-white/5 flex gap-3 items-start">
              <div className="p-2 rounded-lg bg-primary/10 text-primary shrink-0 mt-0.5">
                {n.type === 'ai' ? <Sparkles className="w-4 h-4 text-tertiary" /> : n.type === 'export' ? <Download className="w-4 h-4 text-secondary" /> : <Clock className="w-4 h-4 text-primary" />}
              </div>
              <div className="flex flex-col min-w-0">
                <div className="flex justify-between items-center gap-2">
                  <h4 className="font-semibold text-xs text-on-surface truncate">{n.title}</h4>
                  <span className="text-[10px] font-mono text-on-surface-variant shrink-0">{n.time}</span>
                </div>
                <p className="text-xs text-on-surface-variant mt-0.5">{n.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={onClose}
          className="w-full bg-surface-container-high hover:bg-surface-container-highest text-on-surface font-semibold text-xs py-2.5 rounded-xl border border-white/10 transition-colors cursor-pointer"
        >
          Dismiss All
        </button>
      </div>
    </div>
  );
};
