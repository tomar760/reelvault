import React from 'react';
import { Settings, Moon, Sun, HardDrive, RefreshCw, Download, Trash2, ShieldCheck, Wifi } from 'lucide-react';
import { AppSettings, VaultItem } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  vaultItems: VaultItem[];
  onExportBackupJSON: () => void;
  onResetVaultData: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  vaultItems,
  onExportBackupJSON,
  onResetVaultData,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xl flex items-center justify-center p-4">
      <div className="bg-surface-container border border-white/15 rounded-2xl p-6 max-w-lg w-full shadow-2xl flex flex-col gap-5 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-primary" />
            <h2 className="font-headline-md text-lg font-bold text-on-surface">Vault Settings & Storage</h2>
          </div>
          <button onClick={onClose} className="text-on-surface-variant hover:text-on-surface text-xl font-bold cursor-pointer">
            ×
          </button>
        </div>

        {/* Theme Settings */}
        <div className="flex justify-between items-center bg-surface-container-low p-3.5 rounded-xl border border-white/5">
          <div className="flex items-center gap-3">
            {settings.theme === 'dark' ? <Moon className="w-5 h-5 text-indigo-400" /> : <Sun className="w-5 h-5 text-amber-400" />}
            <div>
              <p className="font-semibold text-xs text-on-surface">Interface Appearance</p>
              <p className="text-[11px] text-on-surface-variant">
                {settings.theme === 'dark' ? 'Dark Mode (Stitch High-Tech)' : 'Light Mode (Clean Precision)'}
              </p>
            </div>
          </div>
          <button
            onClick={() => onUpdateSettings({ ...settings, theme: settings.theme === 'dark' ? 'light' : 'dark' })}
            className="px-3 py-1.5 bg-primary/10 border border-primary/20 text-primary rounded-lg text-xs font-semibold cursor-pointer"
          >
            Switch Mode
          </button>
        </div>

        {/* Offline Cache & Service Worker */}
        <div className="flex flex-col gap-2 bg-surface-container-low p-3.5 rounded-xl border border-white/5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Wifi className="w-4 h-4 text-tertiary" />
              <p className="font-semibold text-xs text-on-surface">PWA Offline Caching</p>
            </div>
            <span className="text-[10px] font-mono text-tertiary bg-tertiary/15 px-2 py-0.5 rounded">Active</span>
          </div>
          <p className="text-[11px] text-on-surface-variant">
            Videos, metadata, and analytics are cached locally in your browser so ReelVault operates seamlessly without internet connection.
          </p>
        </div>

        {/* Backup & Restore */}
        <div className="flex flex-col gap-2">
          <p className="font-label-md text-xs text-on-surface-variant font-mono uppercase">Backup & Data Recovery</p>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={onExportBackupJSON}
              className="bg-surface-container-high border border-white/10 hover:border-primary text-on-surface p-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4 text-primary" />
              <span>Export JSON Backup</span>
            </button>

            <button
              onClick={() => {
                if (confirm('Reset ReelVault to default initial demo dataset?')) {
                  onResetVaultData();
                  onClose();
                }
              }}
              className="bg-rose-500/10 border border-rose-500/30 hover:bg-rose-500/20 text-rose-400 p-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>Reset Demo Data</span>
            </button>
          </div>
        </div>

        <div className="text-center pt-2 border-t border-white/5">
          <span className="text-[10px] font-mono text-on-surface-variant/60">
            ReelVault Engine v2.4.1 • Chrome PWA Ready
          </span>
        </div>
      </div>
    </div>
  );
};
