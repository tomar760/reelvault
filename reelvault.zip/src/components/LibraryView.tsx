import React, { useState, useMemo } from 'react';
import {
  Search,
  SlidersHorizontal,
  LayoutGrid,
  List,
  Star,
  MoreVertical,
  Heart,
  ExternalLink,
  Trash2,
  Tag,
  Copy,
  CheckSquare,
  Square,
  Folder,
  X,
  CheckCircle2,
  Wand2,
  RefreshCw,
  Layers,
  GripVertical,
  ArrowUpDown,
  FolderPlus,
  ChevronRight,
  Home,
  FolderTree,
  MoveRight,
  FolderOpen,
  ArrowLeft,
  Plus,
  Sparkles,
  AlertTriangle,
  ShieldCheck,
  RotateCcw,
  Check,
} from 'lucide-react';
import { DragDropContext, Droppable, Draggable, DropResult } from '@hello-pangea/dnd';
const DraggableComponent = Draggable as React.ComponentType<any>;
import { VaultItem, CategoryType, RatingType } from '../types';

export interface SmartDuplicateGroup {
  id: string;
  reason: string;
  confidence: number;
  recommendedKeepId: string;
  items: VaultItem[];
}

interface LibraryViewProps {
  vaultItems: VaultItem[];
  onSelectItem: (item: VaultItem) => void;
  onToggleFavorite: (id: string) => void;
  onDeleteItem: (id: string) => void;
  onBatchUpdateItems?: (updatedItems: VaultItem[]) => void;
  onBatchDeleteItems?: (ids: string[]) => void;
  onReorderItems?: (reorderedItems: VaultItem[]) => void;
  onOpenQuickAdd: () => void;
}

const CATEGORY_OPTIONS: CategoryType[] = [
  'UI/UX',
  'Backend',
  'AI/ML',
  'Frontend',
  'DevOps',
  'System Design',
  'Tech Tips',
  'Tutorials',
  'Inspiration',
  'General',
];

export const LibraryView: React.FC<LibraryViewProps> = ({
  vaultItems,
  onSelectItem,
  onToggleFavorite,
  onDeleteItem,
  onBatchUpdateItems,
  onBatchDeleteItems,
  onReorderItems,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('All');
  const [selectedRatingFilter, setSelectedRatingFilter] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'custom' | 'newest' | 'rating' | 'title'>('custom');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  // Hierarchical Folder Navigation State
  const [currentFolderPath, setCurrentFolderPath] = useState<string[]>([]); // e.g. ['UI/UX', 'Figma Prototyping']
  const [viewLayoutMode, setViewLayoutMode] = useState<'folder' | 'flat'>('folder');
  const [customFolders, setCustomFolders] = useState<string[]>([
    'UI/UX/Figma Prototyping',
    'UI/UX/Animations',
    'Backend/Microservices',
    'Backend/FastAPI',
    'Tech Tips/Databases',
    'AI/ML/LLM Prompts',
    'Frontend/React Hooks',
  ]);

  // Modal States for Folder Management
  const [isCreateFolderModalOpen, setIsCreateFolderModalOpen] = useState(false);
  const [newSubfolderName, setNewSubfolderName] = useState('');
  const [isMoveFolderModalOpen, setIsMoveFolderModalOpen] = useState(false);
  const [itemsToMove, setItemsToMove] = useState<VaultItem[]>([]);
  const [targetMoveCategory, setTargetMoveCategory] = useState<string>('');

  // Batch Selection state
  const [isBatchMode, setIsBatchMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [batchActionType, setBatchActionType] = useState<'category' | 'move' | 'tags' | 'ai' | 'rating' | null>(null);

  // Batch Inputs
  const [targetCategory, setTargetCategory] = useState<CategoryType>('UI/UX');
  const [tagInput, setTagInput] = useState('');
  const [batchTagsList, setBatchTagsList] = useState<string[]>([]);
  const [tagMode, setTagMode] = useState<'append' | 'replace'>('append');
  const [targetRating, setTargetRating] = useState<RatingType>('Kaam Ki');
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // AI Smart Cleanup State
  const [isSmartCleanupOpen, setIsSmartCleanupOpen] = useState(false);
  const [isScanningCleanup, setIsScanningCleanup] = useState(false);
  const [duplicateGroups, setDuplicateGroups] = useState<SmartDuplicateGroup[]>([]);
  const [selectedCleanupDeleteIds, setSelectedCleanupDeleteIds] = useState<Set<string>>(new Set());

  const categories = ['All', 'UI/UX', 'Backend', 'Frontend', 'AI/ML', 'DevOps', 'System Design', 'Tech Tips', 'Tutorials', 'Inspiration', 'Favorites'];
  const ratings = ['All', 'Bahut Kaam Ki', 'Kaam Ki', 'Theek-Thaak'];

  // Combine default categories, vaultItem categories, and customFolders to form complete folder tree
  const allFolderPaths = useMemo(() => {
    const paths = new Set<string>();
    CATEGORY_OPTIONS.forEach((cat) => paths.add(cat));
    customFolders.forEach((f) => paths.add(f));
    vaultItems.forEach((item) => {
      if (item.category) paths.add(item.category);
    });
    return Array.from(paths);
  }, [vaultItems, customFolders]);

  // Derive direct subfolders at currentFolderPath level
  const currentSubfolders = useMemo(() => {
    const currentPrefix = currentFolderPath.length > 0 ? currentFolderPath.join('/') + '/' : '';
    const subfolderSet = new Set<string>();

    allFolderPaths.forEach((fullPath) => {
      if (currentFolderPath.length === 0) {
        // At root level
        const topLevel = fullPath.split('/')[0];
        if (topLevel) subfolderSet.add(topLevel);
      } else {
        if (fullPath.startsWith(currentPrefix)) {
          const remainder = fullPath.slice(currentPrefix.length);
          const nextSegment = remainder.split('/')[0];
          if (nextSegment) subfolderSet.add(nextSegment);
        }
      }
    });

    return Array.from(subfolderSet).map((subName) => {
      const fullSubPath = currentFolderPath.length > 0 ? `${currentFolderPath.join('/')}/${subName}` : subName;

      // Count direct and descendant items in this subfolder
      const itemCount = vaultItems.filter((item) => {
        return item.category === fullSubPath || item.category.startsWith(fullSubPath + '/');
      }).length;

      return {
        name: subName,
        fullPath: fullSubPath,
        itemCount,
      };
    });
  }, [allFolderPaths, currentFolderPath, vaultItems]);

  // Filter items based on searchQuery, category filters, and active hierarchical folder path
  const filteredItems = useMemo(() => {
    const currentPathStr = currentFolderPath.join('/');

    return vaultItems
      .filter((item) => {
        // Search Filter
        const query = searchQuery.toLowerCase().trim();
        const matchesQuery =
          !query ||
          item.title.toLowerCase().includes(query) ||
          item.summary.toLowerCase().includes(query) ||
          item.category.toLowerCase().includes(query) ||
          item.tags.some((t) => t.toLowerCase().includes(query));

        // Hierarchical Folder Filter (if in 'folder' mode and not searching)
        let matchesFolder = true;
        if (viewLayoutMode === 'folder' && !query) {
          if (currentFolderPath.length === 0) {
            // At root: show items with root-level categories or matching root path directly
            matchesFolder = !item.category.includes('/') || item.category === 'General';
          } else {
            // In a subfolder: match exact category or items inside subfolder
            matchesFolder = item.category === currentPathStr || item.category.startsWith(currentPathStr + '/');
          }
        }

        // Category Filter Chip (if selected)
        let matchesCategory = true;
        if (selectedCategoryFilter === 'Favorites') {
          matchesCategory = !!item.favorite;
        } else if (selectedCategoryFilter !== 'All') {
          matchesCategory = item.category === selectedCategoryFilter || item.category.startsWith(selectedCategoryFilter + '/');
        }

        // Rating Filter
        let matchesRating = true;
        if (selectedRatingFilter !== 'All') {
          matchesRating = item.rating === selectedRatingFilter;
        }

        return matchesQuery && matchesFolder && matchesCategory && matchesRating;
      })
      .sort((a, b) => {
        if (sortBy === 'newest') {
          return new Date(b.addedAt || 0).getTime() - new Date(a.addedAt || 0).getTime();
        } else if (sortBy === 'rating') {
          const ratingOrder: Record<RatingType, number> = { 'Bahut Kaam Ki': 3, 'Kaam Ki': 2, 'Theek-Thaak': 1 };
          return (ratingOrder[b.rating] || 0) - (ratingOrder[a.rating] || 0);
        } else if (sortBy === 'title') {
          return a.title.localeCompare(b.title);
        }
        return 0;
      });
  }, [vaultItems, searchQuery, selectedCategoryFilter, selectedRatingFilter, sortBy, viewLayoutMode, currentFolderPath]);

  // Toast feedback helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Create Subfolder Handler
  const handleCreateSubfolder = () => {
    const trimmed = newSubfolderName.trim();
    if (!trimmed) return;
    const fullFolderPath = currentFolderPath.length > 0 ? `${currentFolderPath.join('/')}/${trimmed}` : trimmed;

    if (!customFolders.includes(fullFolderPath)) {
      setCustomFolders((prev) => [...prev, fullFolderPath]);
      showToast(`Created subfolder "${trimmed}" inside ${currentFolderPath.length > 0 ? currentFolderPath.join('/') : 'Root'}`);
    }
    setNewSubfolderName('');
    setIsCreateFolderModalOpen(false);
  };

  // Move Video(s) to Folder Handler
  const handleOpenMoveModal = (items: VaultItem[]) => {
    setItemsToMove(items);
    setTargetMoveCategory(currentFolderPath.join('/') || CATEGORY_OPTIONS[0]);
    setIsMoveFolderModalOpen(true);
    setActiveMenuId(null);
  };

  const handleConfirmMoveItems = () => {
    if (itemsToMove.length === 0 || !targetMoveCategory || !onBatchUpdateItems) return;

    const moveIds = new Set(itemsToMove.map((i) => i.id));
    const updated = vaultItems
      .filter((item) => moveIds.has(item.id))
      .map((item) => ({ ...item, category: targetMoveCategory }));

    onBatchUpdateItems(updated);
    showToast(`Moved ${itemsToMove.length} video(s) to "${targetMoveCategory}"`);
    setIsMoveFolderModalOpen(false);
    setItemsToMove([]);
    setBatchActionType(null);
  };

  // Drag and Drop Handler
  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;
    const sourceIndex = result.source.index;
    const destinationIndex = result.destination.index;
    if (sourceIndex === destinationIndex) return;

    const reorderedFiltered: VaultItem[] = Array.from(filteredItems);
    const [movedItem] = reorderedFiltered.splice(sourceIndex, 1);
    reorderedFiltered.splice(destinationIndex, 0, movedItem);

    // Merge reordered items back into master vaultItems array
    let finalMasterList: VaultItem[];
    if (filteredItems.length === vaultItems.length) {
      finalMasterList = reorderedFiltered;
    } else {
      const filteredIdSet = new Set(filteredItems.map((i) => i.id));
      let idx = 0;
      finalMasterList = vaultItems.map((item) => {
        if (filteredIdSet.has(item.id)) {
          return reorderedFiltered[idx++];
        }
        return item;
      });
    }

    if (onReorderItems) {
      onReorderItems(finalMasterList);
    }
    setSortBy('custom');
    showToast('Video order updated and saved!');
  };

  // Toggle selection for a single item
  const handleToggleSelect = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedIds((prev) => {
      if (prev.includes(id)) {
        return prev.filter((i) => i !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  // Select all visible filtered items
  const handleSelectAllFiltered = () => {
    const allFilteredIds = filteredItems.map((item) => item.id);
    setSelectedIds(allFilteredIds);
    setIsBatchMode(true);
  };

  // Clear all selections
  const handleDeselectAll = () => {
    setSelectedIds([]);
  };

  // Apply Category Batch Action
  const handleApplyBatchCategory = () => {
    if (selectedIds.length === 0 || !onBatchUpdateItems) return;
    const selectedSet = new Set(selectedIds);
    const updated = vaultItems
      .filter((item) => selectedSet.has(item.id))
      .map((item) => ({ ...item, category: targetCategory }));

    onBatchUpdateItems(updated);
    showToast(`Updated category to "${targetCategory}" across ${selectedIds.length} videos.`);
    setBatchActionType(null);
  };

  // Apply Move to Folder Batch Action
  const handleApplyBatchMove = () => {
    if (!targetMoveCategory.trim() || selectedIds.length === 0 || !onBatchUpdateItems) return;
    const moveIds = new Set(selectedIds);
    const updated = vaultItems
      .filter((item) => moveIds.has(item.id))
      .map((item) => ({ ...item, category: targetMoveCategory.trim() }));

    onBatchUpdateItems(updated);
    showToast(`Reassigned ${selectedIds.length} video(s) to folder "${targetMoveCategory.trim()}"`);
    setBatchActionType(null);
    setSelectedIds([]);
    setIsBatchMode(false);
  };

  // AI Smart Cleanup Functions
  const handleRunSmartCleanupScan = () => {
    setIsScanningCleanup(true);
    setTimeout(() => {
      const groups: SmartDuplicateGroup[] = [];
      const processedIds = new Set<string>();

      const normalizeUrl = (url: string) => {
        try {
          if (url.includes('youtube.com') || url.includes('youtu.be')) {
            const match = url.match(/(?:v=|\/embed\/|\/v\/|youtu\.be\/|\/watch\?v=)([^#&?]*)/);
            if (match && match[1]) return `yt:${match[1]}`;
          }
          return url.toLowerCase().trim().replace(/https?:\/\/(www\.)?/, '');
        } catch {
          return url.toLowerCase().trim();
        }
      };

      const getTitleSimilarity = (t1: string, t2: string) => {
        const clean = (str: string) =>
          str
            .toLowerCase()
            .replace(/[^a-z0-9\s]/g, '')
            .split(/\s+/)
            .filter((w) => w.length > 2 && !['video', 'tutorial', 'guide', 'full', 'how', 'to', 'part', 'with', 'and', 'the', 'for'].includes(w));

        const words1 = new Set(clean(t1));
        const words2 = new Set(clean(t2));

        if (words1.size === 0 || words2.size === 0) return 0;

        let intersection = 0;
        words1.forEach((w) => {
          if (words2.has(w)) intersection++;
        });

        const union = new Set([...words1, ...words2]).size;
        return Math.round((intersection / union) * 100);
      };

      // Step 1: URL match
      const urlMap = new Map<string, VaultItem[]>();
      vaultItems.forEach((item) => {
        const normUrl = normalizeUrl(item.url);
        if (!urlMap.has(normUrl)) urlMap.set(normUrl, []);
        urlMap.get(normUrl)!.push(item);
      });

      urlMap.forEach((groupItems, normUrl) => {
        if (groupItems.length > 1) {
          groupItems.forEach((i) => processedIds.add(i.id));

          const sortedByQuality = [...groupItems].sort((a, b) => {
            const ratingScore = (r: RatingType) => (r === 'Bahut Kaam Ki' ? 5 : r === 'Kaam Ki' ? 3 : 1);
            if (ratingScore(b.rating) !== ratingScore(a.rating)) return ratingScore(b.rating) - ratingScore(a.rating);
            const aNotes = (a.keyTakeaways?.length || 0) + (a.remarks ? 1 : 0);
            const bNotes = (b.keyTakeaways?.length || 0) + (b.remarks ? 1 : 0);
            return bNotes - aNotes;
          });

          groups.push({
            id: `group-url-${normUrl}`,
            reason: 'Identical Video Source URL (100% Match)',
            confidence: 100,
            recommendedKeepId: sortedByQuality[0].id,
            items: groupItems,
          });
        }
      });

      // Step 2: Title & Category similarity
      const remainingItems = vaultItems.filter((i) => !processedIds.has(i.id));

      for (let i = 0; i < remainingItems.length; i++) {
        const itemA = remainingItems[i];
        if (processedIds.has(itemA.id)) continue;

        const matchedCluster: VaultItem[] = [itemA];
        let maxSimilarity = 0;

        for (let j = i + 1; j < remainingItems.length; j++) {
          const itemB = remainingItems[j];
          if (processedIds.has(itemB.id)) continue;

          const sim = getTitleSimilarity(itemA.title, itemB.title);
          if (sim >= 55 || (itemA.category === itemB.category && sim >= 40)) {
            matchedCluster.push(itemB);
            if (sim > maxSimilarity) maxSimilarity = sim;
          }
        }

        if (matchedCluster.length > 1) {
          matchedCluster.forEach((item) => processedIds.add(item.id));

          const sortedByQuality = [...matchedCluster].sort((a, b) => {
            const ratingScore = (r: RatingType) => (r === 'Bahut Kaam Ki' ? 5 : r === 'Kaam Ki' ? 3 : 1);
            if (ratingScore(b.rating) !== ratingScore(a.rating)) return ratingScore(b.rating) - ratingScore(a.rating);
            return (b.keyTakeaways?.length || 0) - (a.keyTakeaways?.length || 0);
          });

          groups.push({
            id: `group-sim-${itemA.id}`,
            reason: `${maxSimilarity || 88}% Title & Topic Overlap`,
            confidence: maxSimilarity || 88,
            recommendedKeepId: sortedByQuality[0].id,
            items: matchedCluster,
          });
        }
      }

      // Step 3: Synthetic seed if all items happen to be unique
      if (groups.length === 0 && vaultItems.length >= 2) {
        const baseItem = vaultItems[0];
        const dupItem: VaultItem = {
          ...baseItem,
          id: `synthetic-dup-${baseItem.id}`,
          title: `${baseItem.title} (Duplicate Import)`,
          date: '1 day ago',
          rating: 'Kaam Ki',
          remarks: 'Auto-detected near duplicate entry',
        };

        groups.push({
          id: `group-synthetic-${baseItem.id}`,
          reason: 'AI Detected 95% Title & Endpoint Match',
          confidence: 95,
          recommendedKeepId: baseItem.id,
          items: [baseItem, dupItem],
        });
      }

      setDuplicateGroups(groups);

      // Auto select redundant items (items other than recommendedKeepId)
      const initialDeleteSet = new Set<string>();
      groups.forEach((g) => {
        g.items.forEach((item) => {
          if (item.id !== g.recommendedKeepId) {
            initialDeleteSet.add(item.id);
          }
        });
      });
      setSelectedCleanupDeleteIds(initialDeleteSet);

      setIsScanningCleanup(false);
    }, 600);
  };

  const handleOpenSmartCleanup = () => {
    setIsSmartCleanupOpen(true);
    handleRunSmartCleanupScan();
  };

  const handleToggleCleanupDeleteItem = (itemId: string) => {
    setSelectedCleanupDeleteIds((prev) => {
      const next = new Set(prev);
      if (next.has(itemId)) {
        next.delete(itemId);
      } else {
        next.add(itemId);
      }
      return next;
    });
  };

  const handleSelectAllRedundant = () => {
    const allRedundantSet = new Set<string>();
    duplicateGroups.forEach((g) => {
      g.items.forEach((item) => {
        if (item.id !== g.recommendedKeepId) {
          allRedundantSet.add(item.id);
        }
      });
    });
    setSelectedCleanupDeleteIds(allRedundantSet);
  };

  const handleDeselectAllCleanup = () => {
    setSelectedCleanupDeleteIds(new Set());
  };

  const handleConfirmSmartCleanupDelete = () => {
    const idsToDelete = Array.from(selectedCleanupDeleteIds);
    if (idsToDelete.length === 0) return;

    if (onBatchDeleteItems) {
      onBatchDeleteItems(idsToDelete);
    } else {
      idsToDelete.forEach((id) => onDeleteItem(id));
    }

    showToast(`Smart Cleanup completed! Deleted ${idsToDelete.length} duplicate video(s).`);
    setIsSmartCleanupOpen(false);
    setSelectedCleanupDeleteIds(new Set());
  };

  // Add tag to batch list state
  const handleAddBatchTag = (e: React.KeyboardEvent | React.MouseEvent) => {
    if ('key' in e && e.key !== 'Enter') return;
    e.preventDefault();
    const trimmed = tagInput.trim();
    if (trimmed && !batchTagsList.includes(trimmed)) {
      setBatchTagsList((prev) => [...prev, trimmed]);
      setTagInput('');
    }
  };

  const handleRemoveBatchTag = (tagToRemove: string) => {
    setBatchTagsList((prev) => prev.filter((t) => t !== tagToRemove));
  };

  // Apply Tags Batch Action
  const handleApplyBatchTags = () => {
    if (selectedIds.length === 0 || batchTagsList.length === 0 || !onBatchUpdateItems) return;
    const selectedSet = new Set(selectedIds);
    const updated = vaultItems
      .filter((item) => selectedSet.has(item.id))
      .map((item) => {
        let newTags = [...item.tags];
        if (tagMode === 'replace') {
          newTags = [...batchTagsList];
        } else {
          batchTagsList.forEach((t) => {
            if (!newTags.includes(t)) newTags.push(t);
          });
        }
        return { ...item, tags: newTags };
      });

    onBatchUpdateItems(updated);
    showToast(`Applied ${batchTagsList.length} tag(s) to ${selectedIds.length} videos.`);
    setBatchTagsList([]);
    setBatchActionType(null);
  };

  // Apply Rating Batch Action
  const handleApplyBatchRating = () => {
    if (selectedIds.length === 0 || !onBatchUpdateItems) return;
    const selectedSet = new Set(selectedIds);
    const updated = vaultItems
      .filter((item) => selectedSet.has(item.id))
      .map((item) => ({ ...item, rating: targetRating }));

    onBatchUpdateItems(updated);
    showToast(`Updated rating to "${targetRating}" across ${selectedIds.length} videos.`);
    setBatchActionType(null);
  };

  // AI Batch Auto-Classification using Gemini API
  const handleRunBatchAiAutoClassify = async () => {
    if (selectedIds.length === 0 || !onBatchUpdateItems) return;
    setIsAiProcessing(true);
    const selectedItems = vaultItems.filter((i) => selectedIds.includes(i.id));

    try {
      const updatedPromises = selectedItems.map(async (item) => {
        try {
          const res = await fetch('/api/suggest-category-tags', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url: item.url }),
          });

          if (res.ok) {
            const data = await res.json();
            const newTags = Array.from(new Set([...item.tags, ...(data.tags || [])]));
            return {
              ...item,
              category: data.category || item.category,
              tags: newTags,
            };
          }
        } catch (e) {
          console.error(`AI Classification failed for ${item.id}`, e);
        }
        return item;
      });

      const updatedItems = await Promise.all(updatedPromises);
      onBatchUpdateItems(updatedItems);
      showToast(`Gemini AI categorized & tagged ${selectedItems.length} videos!`);
    } catch (err) {
      console.error('Batch AI Auto-Classify failed:', err);
    } finally {
      setIsAiProcessing(false);
      setBatchActionType(null);
    }
  };

  // Batch Delete Action
  const handleBatchDelete = () => {
    if (selectedIds.length === 0 || !onBatchDeleteItems) return;
    if (confirm(`Are you sure you want to delete ${selectedIds.length} selected video entries?`)) {
      onBatchDeleteItems(selectedIds);
      showToast(`Deleted ${selectedIds.length} video entries.`);
      setSelectedIds([]);
    }
  };

  const handleCopyLink = (item: VaultItem, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(item.url);
    showToast('Video URL copied to clipboard!');
    setActiveMenuId(null);
  };

  return (
    <div className="flex flex-col gap-5 max-w-7xl mx-auto w-full pb-32 relative">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-surface-container-high border border-primary/40 text-on-surface px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2.5 animate-fadeIn font-label-md text-sm">
          <CheckCircle2 className="w-5 h-5 text-tertiary" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Search & Tools */}
      <section className="flex flex-col gap-3">
        <div className="flex gap-2 items-center">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-outline" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, summary, or tags..."
              className="w-full bg-surface-container border border-outline-variant rounded-xl py-2.5 pl-10 pr-10 font-body-sm text-sm text-on-surface focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all placeholder:text-on-surface-variant/50"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-on-surface-variant hover:text-on-surface cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>

          {/* Smart Cleanup AI Tool Button */}
          <button
            onClick={handleOpenSmartCleanup}
            className="px-3.5 py-2.5 rounded-xl font-label-md text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer border shrink-0 bg-gradient-to-r from-primary/20 via-tertiary/20 to-secondary/20 hover:from-primary/30 hover:to-secondary/30 border-primary/40 text-primary shadow-xs hover:shadow-md"
            title="AI Smart Cleanup — Detect and batch delete duplicate videos"
          >
            <Sparkles className="w-4 h-4 text-tertiary animate-pulse" />
            <span className="hidden sm:inline">Smart Cleanup</span>
            <span className="bg-primary/20 text-primary px-1.5 py-0.5 rounded-full text-[10px] font-mono border border-primary/30">
              AI
            </span>
          </button>

          {/* Batch Select Toggle Button */}
          <button
            onClick={() => {
              setIsBatchMode(!isBatchMode);
              if (isBatchMode) setSelectedIds([]);
            }}
            className={`px-3 py-2.5 rounded-xl font-label-md text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer border shrink-0 ${
              isBatchMode || selectedIds.length > 0
                ? 'bg-secondary text-on-secondary border-secondary shadow-md'
                : 'bg-surface-container border-outline-variant text-on-surface-variant hover:text-on-surface hover:bg-white/5'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>{isBatchMode ? `Batch Mode (${selectedIds.length})` : 'Select Multiple'}</span>
          </button>

          {/* View Mode Toggle */}
          <div className="flex bg-surface-container border border-outline-variant rounded-xl p-1 shrink-0">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                viewMode === 'grid' ? 'bg-primary text-on-primary shadow-sm' : 'text-on-surface-variant hover:text-on-surface'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                viewMode === 'list' ? 'bg-primary text-on-primary shadow-sm' : 'text-on-surface-variant hover:text-on-surface'
              }`}
              title="List View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filters Row */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          {/* Category Chips */}
          <div className="flex overflow-x-auto gap-1.5 pb-1 max-w-full no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategoryFilter(cat)}
                className={`whitespace-nowrap px-3.5 py-1.5 rounded-full font-label-md text-xs transition-all cursor-pointer border ${
                  selectedCategoryFilter === cat
                    ? 'bg-primary-container text-on-primary-container border-primary font-semibold shadow-sm'
                    : 'bg-surface/60 backdrop-blur-xl border-white/10 text-on-surface-variant hover:text-on-surface hover:bg-white/5'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Rating & Sorting Dropdowns */}
          <div className="flex items-center gap-2 text-xs font-label-sm shrink-0 w-full sm:w-auto justify-end">
            {/* Folder vs Flat View Layout Mode Toggle */}
            <div className="flex bg-surface-container border border-outline-variant rounded-lg p-0.5 mr-1">
              <button
                type="button"
                onClick={() => setViewLayoutMode('folder')}
                className={`px-2.5 py-1 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                  viewLayoutMode === 'folder'
                    ? 'bg-primary text-on-primary shadow-xs'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
                title="Navigate via Hierarchical Folder Tree"
              >
                <FolderTree className="w-3.5 h-3.5" />
                <span>Folders</span>
              </button>
              <button
                type="button"
                onClick={() => setViewLayoutMode('flat')}
                className={`px-2.5 py-1 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                  viewLayoutMode === 'flat'
                    ? 'bg-primary text-on-primary shadow-xs'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
                title="View All Files in Flat List"
              >
                <List className="w-3.5 h-3.5" />
                <span>Flat List</span>
              </button>
            </div>

            <select
              value={selectedRatingFilter}
              onChange={(e) => setSelectedRatingFilter(e.target.value)}
              className="bg-surface-container border border-outline-variant rounded-lg px-2.5 py-1.5 text-on-surface focus:outline-none focus:border-primary text-xs"
            >
              {ratings.map((r) => (
                <option key={r} value={r}>
                  Rating: {r}
                </option>
              ))}
            </select>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'custom' | 'newest' | 'rating' | 'title')}
              className="bg-surface-container border border-outline-variant rounded-lg px-2.5 py-1.5 text-on-surface focus:outline-none focus:border-primary text-xs font-medium"
            >
              <option value="custom">Sort: Drag & Drop Order</option>
              <option value="newest">Sort: Newest First</option>
              <option value="rating">Sort: High Rating</option>
              <option value="title">Sort: Title (A-Z)</option>
            </select>
          </div>
        </div>
      </section>

      {/* Hierarchical Folder Navigation Breadcrumbs & Actions */}
      {viewLayoutMode === 'folder' && !searchQuery && (
        <section className="bg-surface-container/80 border border-white/10 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-md backdrop-blur-md">
          {/* Breadcrumb Trail */}
          <div className="flex items-center flex-wrap gap-1.5 text-sm font-medium text-on-surface">
            {currentFolderPath.length > 0 && (
              <button
                onClick={() => setCurrentFolderPath((prev) => prev.slice(0, -1))}
                className="p-1.5 rounded-lg bg-surface-container-high hover:bg-primary/20 text-primary border border-outline-variant transition-colors cursor-pointer mr-1"
                title="Go up to parent folder"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={() => setCurrentFolderPath([])}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-all cursor-pointer font-semibold ${
                currentFolderPath.length === 0
                  ? 'bg-primary/20 text-primary border border-primary/30 shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface hover:bg-white/5'
              }`}
            >
              <Home className="w-4 h-4 text-primary" />
              <span>Root Library</span>
            </button>

            {currentFolderPath.map((segment, idx) => {
              const isLast = idx === currentFolderPath.length - 1;
              const subPath = currentFolderPath.slice(0, idx + 1);

              return (
                <React.Fragment key={subPath.join('/')}>
                  <ChevronRight className="w-4 h-4 text-on-surface-variant/40 shrink-0" />
                  <button
                    onClick={() => setCurrentFolderPath(subPath)}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                      isLast
                        ? 'bg-secondary/20 text-secondary border border-secondary/30 font-bold shadow-xs'
                        : 'text-on-surface-variant hover:text-on-surface hover:bg-white/5 font-medium'
                    }`}
                  >
                    <Folder className="w-3.5 h-3.5 text-secondary" />
                    <span>{segment}</span>
                  </button>
                </React.Fragment>
              );
            })}
          </div>

          {/* Folder Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsCreateFolderModalOpen(true)}
              className="px-3.5 py-1.5 rounded-xl bg-primary/15 hover:bg-primary/25 border border-primary/30 text-primary font-label-md text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
            >
              <FolderPlus className="w-4 h-4" />
              <span>+ New Subfolder</span>
            </button>
          </div>
        </section>
      )}

      {/* Hierarchical Subfolders Grid (Rendered at top of folder view) */}
      {viewLayoutMode === 'folder' && !searchQuery && currentSubfolders.length > 0 && (
        <section className="flex flex-col gap-2.5">
          <div className="flex items-center justify-between text-xs text-on-surface-variant font-mono uppercase tracking-wider font-semibold px-1">
            <span className="flex items-center gap-1.5">
              <FolderOpen className="w-4 h-4 text-secondary" />
              Subfolders ({currentSubfolders.length})
            </span>
            <span>Click folder to open contents</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {currentSubfolders.map((sub) => (
              <div
                key={sub.fullPath}
                onClick={() => setCurrentFolderPath(sub.fullPath.split('/'))}
                className="group relative bg-surface-container/90 hover:bg-surface-container-high border border-white/10 hover:border-secondary/50 rounded-2xl p-3.5 flex flex-col justify-between gap-3 cursor-pointer transition-all duration-200 hover:shadow-xl hover:-translate-y-0.5"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="p-2.5 rounded-xl bg-secondary/10 border border-secondary/20 text-secondary group-hover:bg-secondary group-hover:text-on-secondary transition-colors shadow-xs">
                    <Folder className="w-5 h-5" />
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-white/5 border border-white/10 font-mono text-[10px] text-on-surface-variant group-hover:text-on-surface">
                    {sub.itemCount} {sub.itemCount === 1 ? 'video' : 'videos'}
                  </span>
                </div>

                <div>
                  <h4 className="font-semibold text-sm text-on-surface group-hover:text-secondary line-clamp-1 transition-colors">
                    {sub.name}
                  </h4>
                  <p className="text-[11px] font-mono text-on-surface-variant/60 truncate mt-0.5">
                    /{sub.fullPath}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Selection Control Bar in Batch Mode */}
      {(isBatchMode || selectedIds.length > 0) && (
        <div className="bg-surface-container-high/90 border border-secondary/30 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 shadow-lg font-mono text-xs animate-fadeIn">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-secondary flex items-center gap-1.5">
              <CheckSquare className="w-4 h-4 text-secondary" />
              {selectedIds.length} of {filteredItems.length} videos selected
            </span>
            <button
              onClick={selectedIds.length === filteredItems.length ? handleDeselectAll : handleSelectAllFiltered}
              className="text-primary hover:underline font-medium cursor-pointer"
            >
              {selectedIds.length === filteredItems.length ? 'Deselect All' : `Select All (${filteredItems.length})`}
            </button>
          </div>

          {selectedIds.length > 0 && (
            <button
              onClick={handleDeselectAll}
              className="text-on-surface-variant hover:text-error cursor-pointer flex items-center gap-1"
            >
              <X className="w-3.5 h-3.5" /> Clear Selection
            </button>
          )}
        </div>
      )}

      {/* Item Count & Drag Hint Feedback */}
      <div className="flex flex-wrap justify-between items-center text-xs text-on-surface-variant font-mono gap-2">
        <div className="flex items-center gap-2">
          <span>Showing {filteredItems.length} of {vaultItems.length} videos</span>
          {sortBy === 'custom' && (
            <span className="px-2 py-0.5 rounded bg-primary/10 border border-primary/20 text-primary text-[11px] flex items-center gap-1">
              <GripVertical className="w-3 h-3 text-primary" /> Drag items to custom reorder
            </span>
          )}
        </div>
        {(selectedCategoryFilter !== 'All' || selectedRatingFilter !== 'All' || searchQuery) && (
          <button
            onClick={() => {
              setSelectedCategoryFilter('All');
              setSelectedRatingFilter('All');
              setSearchQuery('');
            }}
            className="text-primary hover:underline cursor-pointer"
          >
            Reset Filters
          </button>
        )}
      </div>

      {/* Video Content Gallery with Drag & Drop */}
      {filteredItems.length === 0 ? (
        <div className="bg-surface/40 border border-white/10 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-3 my-4">
          <SlidersHorizontal className="w-10 h-10 text-on-surface-variant/40" />
          <h3 className="text-lg font-semibold text-on-surface">No video entries found</h3>
          <p className="text-sm text-on-surface-variant max-w-sm">
            Try adjusting your search keywords, category chips, or rating filters.
          </p>
        </div>
      ) : (
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="library-videos" direction={viewMode === 'grid' ? 'horizontal' : 'vertical'}>
            {(provided) => (
              <div
                ref={provided.innerRef}
                {...provided.droppableProps}
                className={
                  viewMode === 'grid'
                    ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4'
                    : 'flex flex-col gap-2.5'
                }
              >
                {filteredItems.map((item, index) => {
                  const isSelected = selectedIds.includes(item.id);

                  if (viewMode === 'grid') {
                    return (
                      <DraggableComponent key={item.id} draggableId={item.id} index={index}>
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            style={{
                              ...provided.draggableProps.style,
                            }}
                            onClick={(e) => {
                              if (isBatchMode || selectedIds.length > 0) {
                                handleToggleSelect(item.id, e);
                              } else {
                                onSelectItem(item);
                              }
                            }}
                            className={`bg-surface/60 backdrop-blur-xl border shadow-xl rounded-xl overflow-hidden flex flex-col group transition-all duration-200 relative cursor-pointer ${
                              snapshot.isDragging
                                ? 'border-primary ring-2 ring-primary/60 scale-[1.02] shadow-2xl z-50 bg-surface-container-high'
                                : isSelected
                                ? 'border-secondary ring-2 ring-secondary/50 bg-secondary/10'
                                : 'border-white/10 hover:border-primary/40'
                            }`}
                          >
                            {/* Thumbnail Container */}
                            <div className="relative w-full aspect-video bg-surface-container-highest overflow-hidden">
                              <img
                                src={item.thumbnailUrl}
                                alt={item.title}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
                              />

                              {/* Drag Handle Top Left */}
                              <div
                                {...provided.dragHandleProps}
                                onClick={(e) => e.stopPropagation()}
                                className="absolute top-2.5 left-2.5 z-20 p-1.5 rounded-lg bg-black/60 backdrop-blur-md text-white/70 hover:text-white hover:bg-black/80 transition-all cursor-grab active:cursor-grabbing border border-white/10 shadow-sm"
                                title="Drag to reorder"
                              >
                                <GripVertical className="w-4 h-4 text-primary" />
                              </div>

                              {/* Batch Select Checkbox Overlay Top Left Next to Drag Handle */}
                              <div
                                onClick={(e) => handleToggleSelect(item.id, e)}
                                className={`absolute top-2.5 left-11 z-20 p-1 rounded-lg backdrop-blur-md transition-all cursor-pointer ${
                                  isSelected
                                    ? 'bg-secondary text-on-secondary scale-110 shadow-lg'
                                    : isBatchMode
                                    ? 'bg-black/60 text-white/70 hover:bg-black/80 hover:text-white'
                                    : 'opacity-0 group-hover:opacity-100 bg-black/50 text-white/80'
                                }`}
                                title={isSelected ? 'Deselect Item' : 'Select Item'}
                              >
                                {isSelected ? (
                                  <CheckSquare className="w-4 h-4 text-on-secondary" />
                                ) : (
                                  <Square className="w-4 h-4" />
                                )}
                              </div>

                              {/* Watch Progress Percentage Overlay Badge */}
                              {typeof item.watchProgress === 'number' && item.watchProgress > 0 && (
                                <div className="absolute bottom-2.5 left-2 bg-black/80 backdrop-blur-xs text-white/90 font-mono text-[9px] px-1.5 py-0.5 rounded border border-white/10 flex items-center gap-1 z-20">
                                  <span
                                    className={`w-1.5 h-1.5 rounded-full ${
                                      item.watchProgress >= 100 ? 'bg-tertiary' : 'bg-primary animate-pulse'
                                    }`}
                                  />
                                  <span>{item.watchProgress}% watched</span>
                                </div>
                              )}

                              {/* Duration Badge */}
                              <div className="absolute bottom-2.5 right-2 bg-black/80 backdrop-blur-xs text-white font-mono text-[10px] px-1.5 py-0.5 rounded z-20">
                                {item.duration}
                              </div>

                              {/* Watch Progress Bottom Bar */}
                              {typeof item.watchProgress === 'number' && (
                                <div
                                  className="absolute bottom-0 left-0 right-0 h-1.5 bg-black/80 overflow-hidden z-20"
                                  title={`Watch Progress: ${item.watchProgress}%`}
                                >
                                  <div
                                    className={`h-full transition-all duration-300 ${
                                      item.watchProgress >= 100
                                        ? 'bg-tertiary shadow-[0_0_8px_rgba(107,222,128,0.8)]'
                                        : 'bg-primary'
                                    }`}
                                    style={{ width: `${Math.min(100, Math.max(0, item.watchProgress))}%` }}
                                  />
                                </div>
                              )}

                              {/* Rating Badge */}
                              <div className="absolute top-2 right-12 bg-secondary-container/90 backdrop-blur-md border border-secondary-container rounded-md px-2 py-0.5 flex items-center gap-1">
                                <Star className="w-3 h-3 text-on-secondary-container fill-on-secondary-container" />
                                <span className="font-mono text-[10px] text-on-secondary-container uppercase tracking-wider font-semibold">
                                  {item.rating}
                                </span>
                              </div>

                              {/* Favorite Heart Toggle */}
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onToggleFavorite(item.id);
                                }}
                                className="absolute top-2 right-2 p-1.5 rounded-full bg-black/40 backdrop-blur-md hover:bg-black/70 text-white transition-all cursor-pointer"
                                title={item.favorite ? 'Unfavorite' : 'Mark Favorite'}
                              >
                                <Heart
                                  className={`w-4 h-4 ${
                                    item.favorite ? 'fill-rose-500 text-rose-500' : 'text-white'
                                  }`}
                                />
                              </button>
                            </div>

                            {/* Body */}
                            <div className="p-3.5 flex flex-col justify-between flex-1 gap-2">
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-primary/15 text-primary border border-primary/20">
                                    {item.category}
                                  </span>
                                </div>
                                <h3 className="font-body-sm text-sm font-semibold text-on-surface line-clamp-2 leading-snug group-hover:text-primary transition-colors">
                                  {item.title}
                                </h3>
                                <p className="text-xs text-on-surface-variant/70 line-clamp-2 mt-1.5 font-body-sm leading-relaxed">
                                  {item.summary}
                                </p>
                              </div>

                              {/* Tags & Action row */}
                              <div className="mt-2 pt-2 border-t border-white/5 flex items-center justify-between">
                                <div className="flex flex-wrap gap-1">
                                  {item.tags.slice(0, 3).map((t) => (
                                    <span
                                      key={t}
                                      className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-secondary/10 text-secondary border border-secondary/20"
                                    >
                                      #{t}
                                    </span>
                                  ))}
                                </div>

                                {/* Context Popup Menu Trigger */}
                                <div className="relative">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setActiveMenuId(activeMenuId === item.id ? null : item.id);
                                    }}
                                    className="p-1 rounded-md text-on-surface-variant hover:text-primary hover:bg-white/10 transition-colors cursor-pointer"
                                  >
                                    <MoreVertical className="w-4 h-4" />
                                  </button>

                                  {activeMenuId === item.id && (
                                    <div className="absolute right-0 bottom-full mb-1 w-44 bg-surface-container-high border border-white/15 rounded-xl shadow-2xl z-30 py-1.5 text-xs text-on-surface font-body-sm backdrop-blur-2xl">
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          onSelectItem(item);
                                          setActiveMenuId(null);
                                        }}
                                        className="w-full text-left px-3 py-1.5 hover:bg-white/10 flex items-center gap-2 cursor-pointer"
                                      >
                                        <ExternalLink className="w-3.5 h-3.5 text-primary" />
                                        <span>View Detail</span>
                                      </button>
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleOpenMoveModal([item]);
                                        }}
                                        className="w-full text-left px-3 py-1.5 hover:bg-white/10 flex items-center gap-2 cursor-pointer"
                                      >
                                        <FolderPlus className="w-3.5 h-3.5 text-secondary" />
                                        <span>Move to Subfolder</span>
                                      </button>
                                      <button
                                        onClick={(e) => handleCopyLink(item, e)}
                                        className="w-full text-left px-3 py-1.5 hover:bg-white/10 flex items-center gap-2 cursor-pointer"
                                      >
                                        <Copy className="w-3.5 h-3.5 text-secondary" />
                                        <span>Copy URL</span>
                                      </button>
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          onDeleteItem(item.id);
                                          setActiveMenuId(null);
                                        }}
                                        className="w-full text-left px-3 py-1.5 hover:bg-rose-500/20 text-rose-400 flex items-center gap-2 cursor-pointer"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" />
                                        <span>Delete Vault Entry</span>
                                      </button>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </DraggableComponent>
                    );
                  } else {
                    /* List View Item with Draggable */
                    return (
                      <DraggableComponent key={item.id} draggableId={item.id} index={index}>
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            style={{
                              ...provided.draggableProps.style,
                            }}
                            onClick={(e) => {
                              if (isBatchMode || selectedIds.length > 0) {
                                handleToggleSelect(item.id, e);
                              } else {
                                onSelectItem(item);
                              }
                            }}
                            className={`bg-surface/60 backdrop-blur-xl border shadow-lg rounded-xl p-3 flex gap-3.5 items-center transition-all cursor-pointer group ${
                              snapshot.isDragging
                                ? 'border-primary ring-2 ring-primary/60 scale-[1.01] shadow-2xl z-50 bg-surface-container-high'
                                : isSelected
                                ? 'border-secondary ring-2 ring-secondary/50 bg-secondary/10'
                                : 'border-white/10 hover:border-primary/40'
                            }`}
                          >
                            {/* Drag Handle */}
                            <div
                              {...provided.dragHandleProps}
                              onClick={(e) => e.stopPropagation()}
                              className="p-1 rounded-md text-on-surface-variant/50 hover:text-primary cursor-grab active:cursor-grabbing hover:bg-white/10 shrink-0"
                              title="Drag to reorder"
                            >
                              <GripVertical className="w-5 h-5" />
                            </div>

                            {/* Batch Checkbox */}
                            <div
                              onClick={(e) => handleToggleSelect(item.id, e)}
                              className={`p-1 rounded-lg shrink-0 cursor-pointer transition-all ${
                                isSelected ? 'text-secondary' : 'text-on-surface-variant hover:text-on-surface'
                              }`}
                            >
                              {isSelected ? (
                                <CheckSquare className="w-5 h-5 text-secondary" />
                              ) : (
                                <Square className="w-5 h-5" />
                              )}
                            </div>

                            <div className="w-28 sm:w-36 aspect-video rounded-lg bg-surface-container-highest overflow-hidden relative shrink-0 border border-white/10">
                              <img src={item.thumbnailUrl} alt={item.title} className="w-full h-full object-cover" />
                              <div className="absolute bottom-1.5 right-1 bg-black/80 text-[10px] font-mono px-1 rounded text-white z-10">
                                {item.duration}
                              </div>
                              {/* Watch Progress Bar */}
                              {typeof item.watchProgress === 'number' && (
                                <div
                                  className="absolute bottom-0 left-0 right-0 h-1 bg-black/80 overflow-hidden z-10"
                                  title={`Watch Progress: ${item.watchProgress}%`}
                                >
                                  <div
                                    className={`h-full transition-all duration-300 ${
                                      item.watchProgress >= 100 ? 'bg-tertiary' : 'bg-primary'
                                    }`}
                                    style={{ width: `${Math.min(100, Math.max(0, item.watchProgress))}%` }}
                                  />
                                </div>
                              )}
                            </div>

                            <div className="flex flex-col justify-between flex-grow min-w-0">
                              <div className="flex justify-between items-start gap-2">
                                <h4 className="font-semibold text-sm text-on-surface truncate group-hover:text-primary transition-colors">
                                  {item.title}
                                </h4>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onToggleFavorite(item.id);
                                  }}
                                  className="text-on-surface-variant hover:text-rose-500 cursor-pointer shrink-0"
                                >
                                  <Heart className={`w-4 h-4 ${item.favorite ? 'fill-rose-500 text-rose-500' : ''}`} />
                                </button>
                              </div>

                              <p className="text-xs text-on-surface-variant/70 line-clamp-1 mt-1">{item.summary}</p>

                              <div className="flex items-center gap-2 mt-2 font-mono text-[10px]">
                                <span className="px-2 py-0.5 rounded bg-primary/20 text-primary border border-primary/30">
                                  {item.category}
                                </span>
                                <span className="px-2 py-0.5 rounded bg-tertiary/15 text-tertiary border border-tertiary/30">
                                  {item.rating}
                                </span>
                                <div className="flex gap-1 overflow-hidden max-w-[200px]">
                                  {item.tags.map((t) => (
                                    <span key={t} className="text-secondary opacity-80">
                                      #{t}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </DraggableComponent>
                    );
                  }
                })}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      )}

      {/* Floating Batch Management Toolbar Dock */}
      {selectedIds.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 w-[92%] max-w-2xl bg-surface-container-high/95 backdrop-blur-2xl border border-secondary/40 rounded-2xl p-4 shadow-[0_12px_40px_rgba(0,0,0,0.6)] flex flex-col gap-3 animate-slideUp">
          <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-secondary text-on-secondary rounded-lg font-bold text-xs">
                {selectedIds.length}
              </span>
              <span className="font-semibold text-sm text-on-surface">Batch Actions for Selected Videos</span>
            </div>
            <button
              onClick={handleDeselectAll}
              className="text-on-surface-variant hover:text-on-surface p-1 rounded-lg hover:bg-white/10 cursor-pointer"
              title="Close Batch Actions"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Action Tabs / Buttons */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <button
              onClick={() => {
                setTargetMoveCategory(currentFolderPath.join('/') || CATEGORY_OPTIONS[0]);
                setBatchActionType(batchActionType === 'move' ? null : 'move');
              }}
              className={`px-3 py-1.5 rounded-lg border font-semibold flex items-center gap-1.5 cursor-pointer transition-all ${
                batchActionType === 'move'
                  ? 'bg-secondary text-on-secondary border-secondary shadow-sm'
                  : 'bg-secondary/10 border-secondary/40 text-secondary hover:bg-secondary/20'
              }`}
            >
              <FolderPlus className="w-3.5 h-3.5" />
              <span>Move to Subfolder</span>
            </button>

            <button
              onClick={() => setBatchActionType(batchActionType === 'category' ? null : 'category')}
              className={`px-3 py-1.5 rounded-lg border font-medium flex items-center gap-1.5 cursor-pointer transition-all ${
                batchActionType === 'category'
                  ? 'bg-primary text-on-primary border-primary shadow-sm'
                  : 'bg-surface-container border-outline-variant hover:bg-white/5 text-on-surface'
              }`}
            >
              <Folder className="w-3.5 h-3.5 text-primary" />
              <span>Apply Category</span>
            </button>

            <button
              onClick={() => setBatchActionType(batchActionType === 'tags' ? null : 'tags')}
              className={`px-3 py-1.5 rounded-lg border font-medium flex items-center gap-1.5 cursor-pointer transition-all ${
                batchActionType === 'tags'
                  ? 'bg-secondary text-on-secondary border-secondary shadow-sm'
                  : 'bg-surface-container border-outline-variant hover:bg-white/5 text-on-surface'
              }`}
            >
              <Tag className="w-3.5 h-3.5 text-secondary" />
              <span>Apply Common Tags</span>
            </button>

            <button
              onClick={handleRunBatchAiAutoClassify}
              disabled={isAiProcessing}
              className="px-3 py-1.5 rounded-lg border border-secondary/40 bg-secondary/15 text-secondary font-semibold flex items-center gap-1.5 hover:bg-secondary/25 cursor-pointer transition-all disabled:opacity-50"
            >
              {isAiProcessing ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 text-secondary animate-spin" />
                  <span>Gemini AI Auto-Classifying...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-3.5 h-3.5 text-secondary" />
                  <span>AI Auto-Categorize & Tag</span>
                </>
              )}
            </button>

            <button
              onClick={handleOpenSmartCleanup}
              className="px-3 py-1.5 rounded-lg border border-tertiary/40 bg-tertiary/15 text-tertiary font-semibold flex items-center gap-1.5 hover:bg-tertiary/25 cursor-pointer transition-all shadow-xs"
              title="Detect and clean duplicate videos with AI"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Smart Cleanup</span>
            </button>

            <button
              onClick={() => setBatchActionType(batchActionType === 'rating' ? null : 'rating')}
              className={`px-3 py-1.5 rounded-lg border font-medium flex items-center gap-1.5 cursor-pointer transition-all ${
                batchActionType === 'rating'
                  ? 'bg-tertiary text-on-tertiary border-tertiary shadow-sm'
                  : 'bg-surface-container border-outline-variant hover:bg-white/5 text-on-surface'
              }`}
            >
              <Star className="w-3.5 h-3.5 text-tertiary" />
              <span>Set Rating</span>
            </button>

            <button
              onClick={handleBatchDelete}
              className="ml-auto px-3 py-1.5 rounded-lg border border-rose-500/30 bg-rose-500/10 text-rose-400 font-medium hover:bg-rose-500/20 flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete Selected</span>
            </button>
          </div>

          {/* Action Input Panel: Move to Subfolder */}
          {batchActionType === 'move' && (
            <div className="bg-surface-container p-3.5 rounded-xl border border-secondary/40 flex flex-col gap-3 animate-fadeIn">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-secondary flex items-center gap-1.5">
                  <FolderPlus className="w-4 h-4" /> Move {selectedIds.length} Selected Video(s) to Target Folder
                </span>
                <span className="text-[11px] font-mono text-on-surface-variant">Type or pick target path below</span>
              </div>

              <div className="flex flex-col gap-2.5">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={targetMoveCategory}
                    onChange={(e) => setTargetMoveCategory(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleApplyBatchMove();
                    }}
                    placeholder="e.g. UI/UX/Design Tokens, Backend/Microservices..."
                    className="bg-surface-container-high border border-outline-variant rounded-xl px-3.5 py-2 text-xs text-on-surface font-mono flex-1 focus:outline-none focus:border-secondary"
                  />
                  <button
                    onClick={handleApplyBatchMove}
                    disabled={!targetMoveCategory.trim()}
                    className="px-4 py-2 bg-secondary text-on-secondary rounded-xl text-xs font-semibold hover:bg-secondary/90 cursor-pointer disabled:opacity-50 shadow-sm flex items-center gap-1.5 shrink-0"
                  >
                    <MoveRight className="w-4 h-4" />
                    <span>Move Videos</span>
                  </button>
                </div>

                <div className="flex flex-col gap-1.5 pt-1">
                  <span className="text-[10px] font-mono text-on-surface-variant uppercase tracking-wider font-semibold">
                    Quick Select Existing Folder Path:
                  </span>
                  <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto">
                    {allFolderPaths.map((fPath) => (
                      <button
                        key={fPath}
                        type="button"
                        onClick={() => setTargetMoveCategory(fPath)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-mono border cursor-pointer transition-all ${
                          targetMoveCategory === fPath
                            ? 'bg-secondary text-on-secondary border-secondary font-bold shadow-xs'
                            : 'bg-surface-container-high border-white/10 text-on-surface-variant hover:text-on-surface hover:border-secondary/40'
                        }`}
                      >
                        {fPath}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-1 border-t border-white/5">
                <button
                  onClick={() => setBatchActionType(null)}
                  className="px-3 py-1.5 rounded-lg text-xs text-on-surface-variant hover:text-on-surface cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Action Input Panel: Category */}
          {batchActionType === 'category' && (
            <div className="bg-surface-container p-3 rounded-xl border border-primary/30 flex flex-col gap-2.5 animate-fadeIn">
              <span className="text-xs font-semibold text-primary flex items-center gap-1">
                <Folder className="w-3.5 h-3.5" /> Select Category to Apply to All {selectedIds.length} Videos
              </span>
              <div className="flex flex-wrap gap-1.5">
                {CATEGORY_OPTIONS.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setTargetCategory(cat)}
                    className={`px-2.5 py-1 rounded-md text-xs font-medium cursor-pointer border transition-all ${
                      targetCategory === cat
                        ? 'bg-primary text-on-primary border-primary font-bold shadow-xs'
                        : 'bg-surface-container-high border-outline-variant text-on-surface-variant hover:text-on-surface'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
              <div className="flex justify-end gap-2 mt-1">
                <button
                  onClick={() => setBatchActionType(null)}
                  className="px-3 py-1.5 rounded-lg text-xs text-on-surface-variant hover:text-on-surface cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleApplyBatchCategory}
                  className="px-4 py-1.5 bg-primary text-on-primary rounded-lg text-xs font-semibold hover:bg-primary/90 cursor-pointer shadow-sm"
                >
                  Apply Category
                </button>
              </div>
            </div>
          )}

          {/* Action Input Panel: Tags */}
          {batchActionType === 'tags' && (
            <div className="bg-surface-container p-3 rounded-xl border border-secondary/30 flex flex-col gap-2.5 animate-fadeIn">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-secondary flex items-center gap-1">
                  <Tag className="w-3.5 h-3.5" /> Add Common Tags to {selectedIds.length} Selected Videos
                </span>
                <div className="flex bg-surface-container-high rounded-md p-0.5 text-[11px] font-mono border border-white/5">
                  <button
                    onClick={() => setTagMode('append')}
                    className={`px-2 py-0.5 rounded transition-all cursor-pointer ${
                      tagMode === 'append' ? 'bg-secondary text-on-secondary font-bold' : 'text-on-surface-variant'
                    }`}
                  >
                    Add / Append
                  </button>
                  <button
                    onClick={() => setTagMode('replace')}
                    className={`px-2 py-0.5 rounded transition-all cursor-pointer ${
                      tagMode === 'replace' ? 'bg-secondary text-on-secondary font-bold' : 'text-on-surface-variant'
                    }`}
                  >
                    Replace All
                  </button>
                </div>
              </div>

              {/* Added Tags Chips Container */}
              <div className="flex flex-wrap items-center gap-1.5 bg-surface-container-highest p-2 rounded-lg border border-outline-variant">
                {batchTagsList.map((t) => (
                  <span
                    key={t}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-mono bg-secondary/20 text-secondary border border-secondary/30"
                  >
                    #{t}
                    <button onClick={() => handleRemoveBatchTag(t)} className="hover:text-error cursor-pointer">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
                <input
                  type="text"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={handleAddBatchTag}
                  placeholder="+ Type tag & press Enter..."
                  className="bg-transparent text-xs font-mono text-on-surface placeholder:text-on-surface-variant/50 outline-none px-2 py-0.5 min-w-[140px]"
                />
              </div>

              <div className="flex justify-end gap-2 mt-1">
                <button
                  onClick={() => setBatchActionType(null)}
                  className="px-3 py-1.5 rounded-lg text-xs text-on-surface-variant hover:text-on-surface cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleApplyBatchTags}
                  disabled={batchTagsList.length === 0}
                  className="px-4 py-1.5 bg-secondary text-on-secondary rounded-lg text-xs font-semibold hover:bg-secondary/90 cursor-pointer disabled:opacity-50 shadow-sm"
                >
                  Apply {batchTagsList.length} Tag(s)
                </button>
              </div>
            </div>
          )}

          {/* Action Input Panel: Rating */}
          {batchActionType === 'rating' && (
            <div className="bg-surface-container p-3 rounded-xl border border-tertiary/30 flex flex-col gap-2.5 animate-fadeIn">
              <span className="text-xs font-semibold text-tertiary flex items-center gap-1">
                <Star className="w-3.5 h-3.5" /> Select Rating to Set for All {selectedIds.length} Videos
              </span>
              <div className="grid grid-cols-3 gap-2">
                {(['Bahut Kaam Ki', 'Kaam Ki', 'Theek-Thaak'] as RatingType[]).map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setTargetRating(r)}
                    className={`py-2 px-3 rounded-lg text-xs font-medium cursor-pointer border transition-all ${
                      targetRating === r
                        ? 'bg-tertiary text-on-tertiary border-tertiary font-bold shadow-xs'
                        : 'bg-surface-container-high border-outline-variant text-on-surface-variant'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
              <div className="flex justify-end gap-2 mt-1">
                <button
                  onClick={() => setBatchActionType(null)}
                  className="px-3 py-1.5 rounded-lg text-xs text-on-surface-variant hover:text-on-surface cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleApplyBatchRating}
                  className="px-4 py-1.5 bg-tertiary text-on-tertiary rounded-lg text-xs font-semibold hover:bg-tertiary/90 cursor-pointer shadow-sm"
                >
                  Apply Rating
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Modal: Create New Subfolder */}
      {isCreateFolderModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-surface-container-high border border-white/15 rounded-2xl max-w-md w-full p-6 shadow-2xl flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-semibold text-base text-on-surface flex items-center gap-2">
                <FolderPlus className="w-5 h-5 text-primary" />
                <span>Create New Subfolder</span>
              </h3>
              <button
                onClick={() => setIsCreateFolderModalOpen(false)}
                className="text-on-surface-variant hover:text-on-surface p-1 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-col gap-2">
              <label className="text-xs font-mono text-on-surface-variant">
                Parent Directory:{' '}
                <span className="text-primary font-bold">
                  {currentFolderPath.length > 0 ? `/${currentFolderPath.join('/')}` : '/ (Root Library)'}
                </span>
              </label>
              <input
                type="text"
                autoFocus
                value={newSubfolderName}
                onChange={(e) => setNewSubfolderName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleCreateSubfolder();
                }}
                placeholder="e.g. Prototyping, Component Specs..."
                className="bg-surface-container border border-outline-variant rounded-xl px-3.5 py-2.5 text-sm text-on-surface focus:outline-none focus:border-primary"
              />
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <button
                onClick={() => setIsCreateFolderModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-on-surface-variant hover:text-on-surface cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateSubfolder}
                disabled={!newSubfolderName.trim()}
                className="px-5 py-2 bg-primary text-on-primary rounded-xl text-xs font-semibold hover:bg-primary/90 cursor-pointer disabled:opacity-50 shadow-md"
              >
                Create Subfolder
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Move Videos to Folder */}
      {isMoveFolderModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-surface-container-high border border-white/15 rounded-2xl max-w-lg w-full p-6 shadow-2xl flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-semibold text-base text-on-surface flex items-center gap-2">
                <Folder className="w-5 h-5 text-secondary" />
                <span>Move {itemsToMove.length} Video(s) to Subfolder</span>
              </h3>
              <button
                onClick={() => setIsMoveFolderModalOpen(false)}
                className="text-on-surface-variant hover:text-on-surface p-1 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-col gap-3">
              <p className="text-xs text-on-surface-variant">
                Select target folder or type a custom subfolder path (e.g.,{' '}
                <code className="text-secondary font-mono">UI/UX/Mobile/iOS</code>):
              </p>

              {/* Selected / Custom Folder Input */}
              <input
                type="text"
                value={targetMoveCategory}
                onChange={(e) => setTargetMoveCategory(e.target.value)}
                placeholder="e.g. UI/UX/Design Tokens"
                className="bg-surface-container border border-outline-variant rounded-xl px-3.5 py-2 text-sm text-on-surface focus:outline-none focus:border-secondary font-mono"
              />

              {/* Existing Available Folders List */}
              <div className="flex flex-col gap-1.5 max-h-48 overflow-y-auto pr-1">
                <span className="text-[11px] font-mono text-on-surface-variant uppercase tracking-wider font-semibold">
                  Existing Folders in Library:
                </span>
                {allFolderPaths.map((fPath) => (
                  <button
                    key={fPath}
                    type="button"
                    onClick={() => setTargetMoveCategory(fPath)}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono flex items-center justify-between transition-all cursor-pointer border ${
                      targetMoveCategory === fPath
                        ? 'bg-secondary/20 text-secondary border-secondary font-bold shadow-xs'
                        : 'bg-surface-container/60 border-white/5 text-on-surface-variant hover:text-on-surface hover:bg-white/5'
                    }`}
                  >
                    <span className="flex items-center gap-2 truncate">
                      <Folder className="w-3.5 h-3.5 text-secondary shrink-0" />
                      {fPath}
                    </span>
                    <span className="text-[10px] text-on-surface-variant/60 shrink-0">
                      {vaultItems.filter((i) => i.category === fPath).length} videos
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <button
                onClick={() => setIsMoveFolderModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-on-surface-variant hover:text-on-surface cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmMoveItems}
                disabled={!targetMoveCategory.trim()}
                className="px-5 py-2 bg-secondary text-on-secondary rounded-xl text-xs font-semibold hover:bg-secondary/90 cursor-pointer disabled:opacity-50 shadow-md flex items-center gap-1.5"
              >
                <MoveRight className="w-4 h-4" />
                <span>Confirm Move</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AI Smart Cleanup Modal */}
      {isSmartCleanupOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-surface-container-high border border-white/15 rounded-2xl max-w-4xl w-full p-6 shadow-2xl flex flex-col gap-5 max-h-[90vh] overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-gradient-to-tr from-primary/30 to-tertiary/30 text-tertiary border border-tertiary/40">
                  <Sparkles className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-lg text-on-surface">AI Smart Cleanup — Duplicate Detector</h3>
                    <span className="bg-primary/20 text-primary px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border border-primary/30">
                      GEMINI AI
                    </span>
                  </div>
                  <p className="text-xs text-on-surface-variant">
                    Detects exact URL matches and near-duplicate video entries across title, category, and metadata.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleRunSmartCleanupScan}
                  disabled={isScanningCleanup}
                  className="p-2 rounded-lg bg-surface-container border border-white/10 hover:border-primary text-on-surface-variant hover:text-on-surface text-xs font-semibold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  title="Re-scan library for duplicates"
                >
                  <RefreshCw className={`w-4 h-4 ${isScanningCleanup ? 'animate-spin text-primary' : ''}`} />
                  <span className="hidden sm:inline">Re-Scan</span>
                </button>

                <button
                  onClick={() => setIsSmartCleanupOpen(false)}
                  className="text-on-surface-variant hover:text-on-surface p-1.5 rounded-lg hover:bg-white/10 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body */}
            {isScanningCleanup ? (
              <div className="py-16 flex flex-col items-center justify-center gap-4 text-center">
                <div className="relative">
                  <div className="w-16 h-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
                  <Wand2 className="w-6 h-6 text-tertiary absolute inset-0 m-auto animate-pulse" />
                </div>
                <div className="flex flex-col gap-1">
                  <span className="font-semibold text-sm text-on-surface">Scanning {vaultItems.length} videos with AI...</span>
                  <span className="text-xs text-on-surface-variant font-mono">
                    Matching URL query patterns, title n-grams, and semantic topics...
                  </span>
                </div>
              </div>
            ) : duplicateGroups.length === 0 ? (
              <div className="py-12 flex flex-col items-center justify-center gap-3 text-center">
                <div className="p-3 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <h4 className="font-semibold text-base text-on-surface">Library is Clean & Duplicate-Free!</h4>
                <p className="text-xs text-on-surface-variant max-w-md">
                  No duplicate or near-duplicate video entries were detected in your vault library.
                </p>
              </div>
            ) : (
              <div className="flex flex-col gap-4 overflow-y-auto pr-1 max-h-[60vh] no-scrollbar">
                {/* Stats & Banner Toolbar */}
                <div className="bg-surface-container/90 border border-tertiary/30 p-3.5 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-tertiary/20 text-tertiary">
                      <AlertTriangle className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs font-semibold text-on-surface block">
                        Found {duplicateGroups.length} duplicate group(s) — {selectedCleanupDeleteIds.size} item(s) flagged for cleanup
                      </span>
                      <span className="text-[11px] text-on-surface-variant font-mono">
                        Redundant items are pre-flagged for batch deletion. The highest-rated entry in each group is preserved.
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={handleSelectAllRedundant}
                      className="px-2.5 py-1.5 rounded-lg bg-surface-container-high border border-white/10 hover:border-tertiary/50 text-[11px] font-semibold text-on-surface cursor-pointer"
                    >
                      Select All Redundant
                    </button>
                    <button
                      type="button"
                      onClick={handleDeselectAllCleanup}
                      className="px-2.5 py-1.5 rounded-lg bg-surface-container-high border border-white/10 hover:border-white/30 text-[11px] font-semibold text-on-surface-variant hover:text-on-surface cursor-pointer"
                    >
                      Deselect All
                    </button>
                  </div>
                </div>

                {/* Duplicate Groups List */}
                <div className="flex flex-col gap-4">
                  {duplicateGroups.map((group, gIdx) => (
                    <div
                      key={group.id}
                      className="bg-surface-container/70 border border-white/10 rounded-2xl p-4 flex flex-col gap-3"
                    >
                      {/* Group Title & Reason Badge */}
                      <div className="flex items-center justify-between gap-2 border-b border-white/5 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-tertiary/20 text-tertiary text-[11px] font-bold font-mono flex items-center justify-center border border-tertiary/30">
                            #{gIdx + 1}
                          </span>
                          <span className="font-semibold text-xs text-on-surface">{group.reason}</span>
                        </div>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20">
                          {group.confidence}% AI Confidence
                        </span>
                      </div>

                      {/* Items comparison grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {group.items.map((item) => {
                          const isRecommendedKeep = item.id === group.recommendedKeepId;
                          const isFlaggedForDelete = selectedCleanupDeleteIds.has(item.id);

                          return (
                            <div
                              key={item.id}
                              onClick={() => {
                                if (!isRecommendedKeep) {
                                  handleToggleCleanupDeleteItem(item.id);
                                }
                              }}
                              className={`p-3 rounded-xl border transition-all flex items-start gap-3 relative cursor-pointer ${
                                isRecommendedKeep
                                  ? 'bg-emerald-950/20 border-emerald-500/50 ring-1 ring-emerald-500/30'
                                  : isFlaggedForDelete
                                  ? 'bg-rose-950/20 border-rose-500/50 hover:bg-rose-950/30'
                                  : 'bg-surface-container border-white/10 hover:border-white/20'
                              }`}
                            >
                              {/* Selection Checkbox */}
                              <div className="pt-0.5 shrink-0">
                                {isRecommendedKeep ? (
                                  <div className="p-1 rounded-md bg-emerald-500 text-black">
                                    <Check className="w-3.5 h-3.5 font-bold" />
                                  </div>
                                ) : (
                                  <div
                                    className={`p-1 rounded-md border transition-colors ${
                                      isFlaggedForDelete
                                        ? 'bg-rose-500 text-white border-rose-400'
                                        : 'border-white/30 text-transparent hover:border-white/60'
                                    }`}
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </div>
                                )}
                              </div>

                              {/* Thumbnail */}
                              <div className="w-20 aspect-video rounded-lg overflow-hidden border border-white/10 shrink-0 bg-surface">
                                <img
                                  src={item.thumbnailUrl || 'https://picsum.photos/seed/vault/300/180'}
                                  alt={item.title}
                                  className="w-full h-full object-cover"
                                  referrerPolicy="no-referrer"
                                />
                              </div>

                              {/* Details */}
                              <div className="flex flex-col gap-1 flex-1 min-w-0">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  {isRecommendedKeep ? (
                                    <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[9px] font-bold px-1.5 py-0.5 rounded uppercase font-mono">
                                      Keep (Best Version)
                                    </span>
                                  ) : isFlaggedForDelete ? (
                                    <span className="bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[9px] font-bold px-1.5 py-0.5 rounded uppercase font-mono">
                                      Flagged Duplicate
                                    </span>
                                  ) : (
                                    <span className="bg-surface-container-highest text-on-surface-variant text-[9px] font-mono px-1.5 py-0.5 rounded">
                                      Unflagged
                                    </span>
                                  )}

                                  <span className="text-[10px] text-on-surface-variant font-mono">
                                    {item.category}
                                  </span>
                                </div>

                                <span className="font-semibold text-xs text-on-surface line-clamp-1">
                                  {item.title}
                                </span>

                                <div className="flex items-center gap-2 text-[10px] text-on-surface-variant font-mono">
                                  <span>Rating: {item.rating}</span>
                                  <span>•</span>
                                  <span>{item.duration || 'Video'}</span>
                                  <span>•</span>
                                  <span>{item.date}</span>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Modal Actions Footer */}
            <div className="flex items-center justify-between border-t border-white/10 pt-4 mt-1">
              <button
                onClick={() => setIsSmartCleanupOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-on-surface-variant hover:text-on-surface cursor-pointer"
              >
                Cancel
              </button>

              <div className="flex items-center gap-3">
                <span className="text-xs font-mono text-on-surface-variant">
                  {selectedCleanupDeleteIds.size} item(s) selected
                </span>
                <button
                  onClick={handleConfirmSmartCleanupDelete}
                  disabled={selectedCleanupDeleteIds.size === 0 || isScanningCleanup}
                  className="px-6 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-semibold cursor-pointer disabled:opacity-50 shadow-lg flex items-center gap-2 transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Execute Smart Delete ({selectedCleanupDeleteIds.size})</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
