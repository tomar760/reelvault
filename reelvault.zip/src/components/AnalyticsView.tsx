import React, { useState } from 'react';
import { TrendingUp, Cpu, ShieldCheck, FileDown, Printer, X, CheckCircle2, FileText, HardDrive, Video, Award, Clock } from 'lucide-react';
import { INITIAL_ANALYTICS } from '../data/initialData';
import { VaultItem } from '../types';
import { D3DailyActivityChart } from './D3DailyActivityChart';

interface AnalyticsViewProps {
  vaultItems?: VaultItem[];
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ vaultItems = [] }) => {
  const [timeframe, setTimeframe] = useState<'weekly' | 'monthly'>('weekly');
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);
  const analytics = INITIAL_ANALYTICS;

  // Calculate dynamic stats from vaultItems
  const totalItems = vaultItems.length;
  const itemsWithProgress = vaultItems.filter((i) => typeof i.watchProgress === 'number');
  const avgWatchProgress = itemsWithProgress.length
    ? Math.round(itemsWithProgress.reduce((acc, curr) => acc + (curr.watchProgress || 0), 0) / itemsWithProgress.length)
    : 0;

  // Category statistics calculation
  const categoryMap: Record<string, number> = {};
  vaultItems.forEach((item) => {
    categoryMap[item.category] = (categoryMap[item.category] || 0) + 1;
  });

  const handlePrintPdf = () => {
    window.print();
  };

  const handleDownloadReportText = () => {
    const reportText = `===================================================
REELVAULT EXECUTIVE ANALYTICS & ACTIVITY REPORT
Generated: ${new Date().toLocaleString()}
Report ID: RV-REP-${Math.floor(1000 + Math.random() * 9000)}
===================================================

[EXECUTIVE SUMMARY]
- Total Vault Items: ${totalItems}
- Avg Watch Progress: ${avgWatchProgress}%
- Storage Health: 84% Used (12.4 GB / 15.0 GB)
- AI Processing Time: ${analytics.avgProcessingTimeSeconds}s
- AI Success Rate: ${analytics.successRatePercent}%

[CONTENT DISTRIBUTION]
${Object.entries(categoryMap)
  .map(([cat, count]) => `- ${cat}: ${count} item(s) (${Math.round((count / (totalItems || 1)) * 100)}%)`)
  .join('\n')}

[VIDEO INVENTORY]
${vaultItems
  .map(
    (item, index) =>
      `${index + 1}. ${item.title}\n   Category: ${item.category} | Rating: ${item.rating} | Duration: ${item.duration} | Progress: ${item.watchProgress ?? 0}%\n   Added: ${item.date}`
  )
  .join('\n\n')}

===================================================
End of Report - ReelVault AI Video Assets Management
`;

    const blob = new Blob([reportText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ReelVault_Analytics_Report_${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col gap-6 max-w-7xl mx-auto w-full pb-16">
      {/* Print Stylesheet injection for clean PDF generation */}
      <style>{`
        @media print {
          body * {
            visibility: hidden !important;
          }
          #printable-pdf-report, #printable-pdf-report * {
            visibility: visible !important;
          }
          #printable-pdf-report {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            background: #ffffff !important;
            color: #111827 !important;
            padding: 24px !important;
            box-shadow: none !important;
            border: none !important;
          }
          #printable-pdf-report button, #printable-pdf-report .no-print {
            display: none !important;
          }
          #printable-pdf-report .print-black-text {
            color: #111827 !important;
          }
          #printable-pdf-report .print-border {
            border-color: #e5e7eb !important;
          }
        }
      `}</style>

      {/* Desktop Page Title & Export Action */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-2">
        <div>
          <h1 className="font-display-lg text-2xl md:text-3xl font-bold text-on-surface">Analytics</h1>
          <p className="font-body-md text-sm text-on-surface-variant mt-1">
            Monitor vault performance, growth trends, storage health, and AI processing metrics.
          </p>
        </div>

        <button
          onClick={() => setIsPdfModalOpen(true)}
          className="bg-primary hover:bg-primary/90 text-on-primary font-label-md text-xs sm:text-sm px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all active:scale-95 shadow-lg shadow-primary/20 border border-white/20 cursor-pointer font-semibold shrink-0"
        >
          <FileDown className="w-4 h-4" />
          <span>Export as PDF</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Vault Growth (SVG Bar/Line Chart) */}
        <section className="lg:col-span-8 bg-surface/80 backdrop-blur-2xl border border-white/10 rounded-xl p-5 md:p-6 flex flex-col shadow-xl">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
              <h2 className="font-headline-md text-lg md:text-xl font-semibold text-on-surface">Vault Growth</h2>
              <p className="font-label-sm text-xs text-on-surface-variant mt-0.5">
                {timeframe === 'weekly' ? 'Content expansion over the last 7 days' : 'Total videos indexed over 30 days'}
              </p>
            </div>

            <div className="flex flex-col items-end gap-2 w-full sm:w-auto">
              <div className="flex bg-surface-container-high rounded-lg p-1 border border-white/5 self-end">
                <button
                  onClick={() => setTimeframe('weekly')}
                  className={`px-3 py-1 rounded-md text-xs font-label-md transition-all cursor-pointer ${
                    timeframe === 'weekly' ? 'bg-primary text-on-primary font-bold shadow-sm' : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  Weekly
                </button>
                <button
                  onClick={() => setTimeframe('monthly')}
                  className={`px-3 py-1 rounded-md text-xs font-label-md transition-all cursor-pointer ${
                    timeframe === 'monthly' ? 'bg-primary text-on-primary font-bold shadow-sm' : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  Monthly
                </button>
              </div>

              <div className="text-right flex items-center gap-2">
                <span className="font-headline-lg text-xl md:text-2xl font-bold text-primary">+42</span>
                <div className="flex items-center gap-1 text-tertiary font-mono text-xs">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>this week</span>
                </div>
              </div>
            </div>
          </div>

          {/* Dynamic D3 Interactive Bar Chart */}
          <div className="relative flex-grow min-h-[220px] w-full mt-2">
            <D3DailyActivityChart vaultItems={vaultItems} />
          </div>
        </section>

        {/* Storage Health (Circular Gauge) */}
        <section className="lg:col-span-4 bg-surface/80 backdrop-blur-2xl border border-white/10 rounded-xl p-5 md:p-6 flex flex-col items-center justify-between relative overflow-hidden shadow-xl">
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-3xl -mr-16 -mt-16" />
          <h2 className="font-headline-md text-lg font-semibold text-on-surface w-full text-left mb-4">
            Storage Health
          </h2>

          {/* Circular SVG */}
          <div className="relative w-44 h-48 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="8" />
              <circle
                cx="50"
                cy="50"
                r="42"
                fill="none"
                stroke="#adc6ff"
                strokeWidth="8"
                strokeDasharray="221"
                strokeDashoffset="35"
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center">
              <span className="font-display-lg text-3xl font-bold text-on-surface leading-none">
                84<span className="text-xl">%</span>
              </span>
              <span className="font-label-sm text-xs text-on-surface-variant mt-1">Used</span>
            </div>
          </div>

          <div className="w-full mt-4 flex flex-col gap-2.5 font-body-sm text-xs">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-sm bg-primary" />
                <span className="text-on-surface font-medium">Videos</span>
              </div>
              <span className="font-mono text-on-surface-variant">65%</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-sm bg-secondary" />
                <span className="text-on-surface font-medium">Images</span>
              </div>
              <span className="font-mono text-on-surface-variant">15%</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-sm bg-surface-bright border border-outline" />
                <span className="text-on-surface font-medium">Metadata</span>
              </div>
              <span className="font-mono text-on-surface-variant">4%</span>
            </div>
          </div>
        </section>

        {/* Content Distribution */}
        <section className="lg:col-span-6 bg-surface/80 backdrop-blur-2xl border border-white/10 rounded-xl p-5 md:p-6 shadow-xl">
          <h2 className="font-headline-md text-lg font-semibold text-on-surface mb-5">Content Distribution</h2>
          <div className="flex flex-col gap-4">
            {analytics.contentDistribution.map((item) => (
              <div key={item.category}>
                <div className="flex justify-between mb-1.5 font-label-sm text-xs">
                  <span className="text-on-surface font-medium">{item.category}</span>
                  <span className="text-on-surface-variant font-mono">{item.count} items</span>
                </div>
                <div className="w-full h-2 bg-surface-container-high rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${item.colorClass}`}
                    style={{ width: `${item.percent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* AI Efficiency Stat Cards */}
        <section className="lg:col-span-6 grid grid-cols-2 gap-4">
          <div className="bg-surface/80 backdrop-blur-2xl border border-white/10 rounded-xl p-5 flex flex-col justify-center relative overflow-hidden group shadow-xl">
            <div className="absolute inset-0 bg-secondary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <Cpu className="w-8 h-8 text-secondary mb-3" />
            <p className="font-label-sm text-xs text-on-surface-variant mb-1">Avg Processing Time</p>
            <p className="font-headline-lg text-2xl md:text-3xl font-bold text-on-surface">
              {analytics.avgProcessingTimeSeconds}<span className="text-base text-on-surface-variant font-normal">s</span>
            </p>
          </div>

          <div className="bg-surface/80 backdrop-blur-2xl border border-white/10 rounded-xl p-5 flex flex-col justify-center relative overflow-hidden group shadow-xl">
            <div className="absolute inset-0 bg-tertiary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <ShieldCheck className="w-8 h-8 text-tertiary mb-3" />
            <p className="font-label-sm text-xs text-on-surface-variant mb-1">Success Rate</p>
            <p className="font-headline-lg text-2xl md:text-3xl font-bold text-on-surface">
              {analytics.successRatePercent}<span className="text-base text-on-surface-variant font-normal">%</span>
            </p>
          </div>
        </section>
      </div>

      {/* Printable Executive PDF Report Modal */}
      {isPdfModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-surface-container-high border border-white/15 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl relative overflow-hidden">
            {/* Modal Control Header (hidden on print) */}
            <div className="p-4 border-b border-white/10 flex items-center justify-between bg-surface-container-low no-print shrink-0">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                <h3 className="font-headline-md text-base font-bold text-on-surface">
                  Executive PDF Report Preview
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleDownloadReportText}
                  className="px-3 py-1.5 rounded-lg bg-surface-container-high hover:bg-white/10 text-xs font-mono text-on-surface-variant hover:text-on-surface border border-white/10 flex items-center gap-1.5 transition-all cursor-pointer"
                  title="Download raw report as text file"
                >
                  <FileDown className="w-3.5 h-3.5 text-secondary" />
                  <span className="hidden sm:inline">Download .TXT</span>
                </button>

                <button
                  onClick={handlePrintPdf}
                  className="px-4 py-1.5 rounded-lg bg-primary hover:bg-primary/90 text-on-primary text-xs font-semibold flex items-center gap-2 shadow-md shadow-primary/20 transition-all cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print / Save as PDF</span>
                </button>

                <button
                  onClick={() => setIsPdfModalOpen(false)}
                  className="p-1.5 text-on-surface-variant hover:text-on-surface hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Report Content Body */}
            <div className="p-6 md:p-8 overflow-y-auto space-y-6 text-on-surface bg-surface" id="printable-pdf-report">
              {/* Report Document Header */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-6 border-b border-white/10 gap-4 print-border">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-black uppercase tracking-tighter text-primary print-black-text">
                      REELVAULT
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-primary/10 text-primary border border-primary/20">
                      OFFICIAL ANALYTICS REPORT
                    </span>
                  </div>
                  <p className="text-xs text-on-surface-variant mt-1 font-mono print-black-text">
                    Personal Video Library Performance & Activity Summary
                  </p>
                </div>

                <div className="text-left sm:text-right font-mono text-xs text-on-surface-variant space-y-1 print-black-text">
                  <p>
                    <span className="text-on-surface font-semibold">Date:</span> {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                  </p>
                  <p>
                    <span className="text-on-surface font-semibold">Report ID:</span> RV-REP-{Math.floor(1000 + Math.random() * 9000)}
                  </p>
                  <p className="text-tertiary flex items-center sm:justify-end gap-1 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5 text-tertiary" />
                    Status: Verified
                  </p>
                </div>
              </div>

              {/* Key Executive Metrics */}
              <div>
                <h4 className="text-xs uppercase font-mono tracking-wider text-on-surface-variant font-bold mb-3 print-black-text">
                  1. Executive Overview & Storage Metrics
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3.5 rounded-xl bg-surface-container-low border border-white/10 print-border">
                    <div className="flex items-center gap-1.5 text-xs text-on-surface-variant font-mono mb-1 print-black-text">
                      <Video className="w-3.5 h-3.5 text-primary" />
                      <span>Total Videos</span>
                    </div>
                    <span className="text-xl font-bold font-mono text-on-surface print-black-text">
                      {totalItems} items
                    </span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-surface-container-low border border-white/10 print-border">
                    <div className="flex items-center gap-1.5 text-xs text-on-surface-variant font-mono mb-1 print-black-text">
                      <Award className="w-3.5 h-3.5 text-secondary" />
                      <span>Avg Watch Progress</span>
                    </div>
                    <span className="text-xl font-bold font-mono text-secondary print-black-text">
                      {avgWatchProgress}%
                    </span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-surface-container-low border border-white/10 print-border">
                    <div className="flex items-center gap-1.5 text-xs text-on-surface-variant font-mono mb-1 print-black-text">
                      <HardDrive className="w-3.5 h-3.5 text-tertiary" />
                      <span>Storage Health</span>
                    </div>
                    <span className="text-xl font-bold font-mono text-on-surface print-black-text">
                      84% (12.4 GB)
                    </span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-surface-container-low border border-white/10 print-border">
                    <div className="flex items-center gap-1.5 text-xs text-on-surface-variant font-mono mb-1 print-black-text">
                      <Clock className="w-3.5 h-3.5 text-primary" />
                      <span>AI Indexing Time</span>
                    </div>
                    <span className="text-xl font-bold font-mono text-on-surface print-black-text">
                      {analytics.avgProcessingTimeSeconds}s / video
                    </span>
                  </div>
                </div>
              </div>

              {/* Category Breakdown Table */}
              <div>
                <h4 className="text-xs uppercase font-mono tracking-wider text-on-surface-variant font-bold mb-3 print-black-text">
                  2. Content Category Distribution
                </h4>
                <div className="border border-white/10 rounded-xl overflow-hidden print-border">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-surface-container-high/80 text-on-surface-variant border-b border-white/10 print-border">
                      <tr>
                        <th className="p-3 font-semibold">Category Name</th>
                        <th className="p-3 font-semibold">Asset Count</th>
                        <th className="p-3 font-semibold">Share (%)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 print-border">
                      {analytics.contentDistribution.map((row) => (
                        <tr key={row.category} className="hover:bg-white/5">
                          <td className="p-3 font-medium text-on-surface print-black-text">{row.category}</td>
                          <td className="p-3 text-on-surface-variant print-black-text">{row.count} videos</td>
                          <td className="p-3 text-primary font-bold print-black-text">{row.percent}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Video Library Activity Table */}
              <div>
                <h4 className="text-xs uppercase font-mono tracking-wider text-on-surface-variant font-bold mb-3 print-black-text">
                  3. Indexed Video Assets Activity Log
                </h4>
                <div className="border border-white/10 rounded-xl overflow-hidden print-border">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-surface-container-high/80 font-mono text-on-surface-variant border-b border-white/10 print-border">
                      <tr>
                        <th className="p-2.5 font-semibold">Title</th>
                        <th className="p-2.5 font-semibold">Category</th>
                        <th className="p-2.5 font-semibold">Rating</th>
                        <th className="p-2.5 font-semibold">Watch Progress</th>
                        <th className="p-2.5 font-semibold">Date Added</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 font-mono print-border">
                      {vaultItems.map((item) => (
                        <tr key={item.id} className="hover:bg-white/5">
                          <td className="p-2.5 font-semibold text-on-surface print-black-text">{item.title}</td>
                          <td className="p-2.5 text-on-surface-variant print-black-text">{item.category}</td>
                          <td className="p-2.5 text-tertiary print-black-text">{item.rating}</td>
                          <td className="p-2.5 text-secondary font-bold print-black-text">
                            {item.watchProgress ?? 0}%
                          </td>
                          <td className="p-2.5 text-on-surface-variant print-black-text">{item.date}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Footer Sign-off */}
              <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row justify-between items-center text-xs font-mono text-on-surface-variant gap-2 print-border print-black-text">
                <span>ReelVault Automated Report Generator • Confidential</span>
                <span>Page 1 of 1</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

