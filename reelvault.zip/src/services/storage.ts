import { VaultItem, WorkflowItem, AppSettings } from '../types';
import { INITIAL_VAULT_ITEMS, INITIAL_WORKFLOWS, DEFAULT_SETTINGS } from '../data/initialData';

const STORAGE_KEYS = {
  VAULT_ITEMS: 'reelvault_items_v1',
  WORKFLOWS: 'reelvault_workflows_v1',
  SETTINGS: 'reelvault_settings_v1',
  RECENTLY_VIEWED: 'reelvault_recently_viewed_v1',
};

export class StorageService {
  static getVaultItems(): VaultItem[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.VAULT_ITEMS);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error('Failed to parse vault items from storage', e);
    }
    this.saveVaultItems(INITIAL_VAULT_ITEMS);
    return INITIAL_VAULT_ITEMS;
  }

  static saveVaultItems(items: VaultItem[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.VAULT_ITEMS, JSON.stringify(items));
    } catch (e) {
      console.error('Failed to save vault items to storage', e);
    }
  }

  static addVaultItem(item: VaultItem): VaultItem[] {
    const current = this.getVaultItems();
    const updated = [item, ...current];
    this.saveVaultItems(updated);
    return updated;
  }

  static updateVaultItem(updatedItem: VaultItem): VaultItem[] {
    const current = this.getVaultItems();
    const index = current.findIndex((i) => i.id === updatedItem.id);
    if (index !== -1) {
      current[index] = updatedItem;
      this.saveVaultItems(current);
    }
    return current;
  }

  static deleteVaultItem(id: string): VaultItem[] {
    const current = this.getVaultItems();
    const filtered = current.filter((i) => i.id !== id);
    this.saveVaultItems(filtered);
    return filtered;
  }

  static getWorkflows(): WorkflowItem[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.WORKFLOWS);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error('Failed to parse workflows from storage', e);
    }
    this.saveWorkflows(INITIAL_WORKFLOWS);
    return INITIAL_WORKFLOWS;
  }

  static saveWorkflows(workflows: WorkflowItem[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.WORKFLOWS, JSON.stringify(workflows));
    } catch (e) {
      console.error('Failed to save workflows to storage', e);
    }
  }

  static getSettings(): AppSettings {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error('Failed to parse settings from storage', e);
    }
    this.saveSettings(DEFAULT_SETTINGS);
    return DEFAULT_SETTINGS;
  }

  static saveSettings(settings: AppSettings): void {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save settings to storage', e);
    }
  }

  static exportToCSV(items: VaultItem[]): void {
    const headers = ['Title', 'Category', 'Rating', 'Duration', 'Date Added', 'URL', 'Tags', 'Summary'];
    const rows = items.map((item) => [
      `"${(item.title || '').replace(/"/g, '""')}"`,
      `"${(item.category || '').replace(/"/g, '""')}"`,
      `"${(item.rating || '').replace(/"/g, '""')}"`,
      `"${(item.duration || '').replace(/"/g, '""')}"`,
      `"${(item.date || '').replace(/"/g, '""')}"`,
      `"${(item.url || '').replace(/"/g, '""')}"`,
      `"${(item.tags ? item.tags.join('; ') : '').replace(/"/g, '""')}"`,
      `"${(item.summary || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `ReelVault_Export_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  static exportBackupJSON(items: VaultItem[]): void {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(items, null, 2));
    const link = document.createElement('a');
    link.href = dataStr;
    link.setAttribute('download', `ReelVault_Backup_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  static resetToDefaults(): void {
    localStorage.removeItem(STORAGE_KEYS.VAULT_ITEMS);
    localStorage.removeItem(STORAGE_KEYS.WORKFLOWS);
    localStorage.removeItem(STORAGE_KEYS.SETTINGS);
    localStorage.removeItem(STORAGE_KEYS.RECENTLY_VIEWED);
  }

  static getRecentlyViewedIds(): string[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.RECENTLY_VIEWED);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error('Failed to parse recently viewed from storage', e);
    }
    return [];
  }

  static recordRecentlyViewed(id: string): string[] {
    try {
      const current = this.getRecentlyViewedIds();
      const filtered = current.filter((item) => item !== id);
      const updated = [id, ...filtered].slice(0, 20);
      localStorage.setItem(STORAGE_KEYS.RECENTLY_VIEWED, JSON.stringify(updated));
      return updated;
    } catch (e) {
      console.error('Failed to record recently viewed', e);
      return [];
    }
  }

  static clearRecentlyViewed(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.RECENTLY_VIEWED);
    } catch (e) {
      console.error('Failed to clear recently viewed', e);
    }
  }
}
