export type RatingType = 'Bahut Kaam Ki' | 'Kaam Ki' | 'Theek-Thaak';

export type CategoryType = 'UI/UX' | 'Backend' | 'AI/ML' | 'Tech Tips' | 'Tutorials' | 'Inspiration' | 'Frontend' | 'DevOps' | 'System Design' | 'General' | string;

export interface AISuggestionResult {
  category: CategoryType;
  tags: string[];
  suggestedTitle?: string;
  confidence?: number;
  reasoning?: string;
}

export interface DetectedLink {
  label: string;
  url: string;
}

export interface VaultItem {
  id: string;
  title: string;
  url: string;
  category: CategoryType;
  rating: RatingType;
  duration: string;
  date: string;
  addedAt: string;
  summary: string;
  keyTakeaways: string[];
  tags: string[];
  sentimentTag: string;
  detectedLinks: DetectedLink[];
  remarks: string;
  thumbnailUrl: string;
  favorite?: boolean;
  watchProgress?: number; // percentage 0-100 indicating viewing progress
}

export type WorkflowStatus = 'Running' | 'Scheduled' | 'Idle' | 'Completed' | 'Error';

export interface WorkflowItem {
  id: string;
  name: string;
  status: WorkflowStatus;
  source?: string;
  target?: string;
  progress?: number;
  nextRun?: string;
  lastRun?: string;
  model?: string;
  description?: string;
}

export interface AnalyticsData {
  totalVideos: number;
  thisWeekAdded: number;
  highValueCount: number;
  pendingFailedCount: number;
  storageUsedPercent: number;
  storageUsedTB: number;
  totalStorageTB: number;
  contentDistribution: {
    category: string;
    count: number;
    percent: number;
    colorClass: string;
  }[];
  avgProcessingTimeSeconds: number;
  successRatePercent: number;
  weeklyGrowth: { day: string; count: number }[];
}

export type NavigationTab = 'dashboard' | 'library' | 'analytics' | 'workflows' | 'detail';

export type ThemeMode = 'dark' | 'light';

export interface AppSettings {
  autoPilot: boolean;
  offlineSync: boolean;
  theme: ThemeMode;
  notificationsEnabled: boolean;
  autoParseActive: boolean;
}
